import os
import json
import uuid
import shutil
from flask import Flask, render_template, request, jsonify, send_from_directory

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, 'data', 'case_data.json')
DEFAULT_BACKUP = os.path.join(BASE_DIR, 'data', 'case_data_backup.json')
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Make backup on first load
if os.path.exists(DATA_FILE) and not os.path.exists(DEFAULT_BACKUP):
    shutil.copyfile(DATA_FILE, DEFAULT_BACKUP)

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, 'templates'),
    static_folder=os.path.join(BASE_DIR, 'static')
)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024 # 16 MB

def load_data():
    if not os.path.exists(DATA_FILE):
        if os.path.exists(DEFAULT_BACKUP):
            shutil.copyfile(DEFAULT_BACKUP, DATA_FILE)
        else:
            return {"case": {}, "clues": [], "connections": [], "deductions": []}
    with open(DATA_FILE, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/case', methods=['GET'])
def get_case():
    return jsonify(load_data())

@app.route('/api/case/era', methods=['POST'])
def switch_era():
    data = load_data()
    req = request.json or {}
    era_id = req.get('era_id')
    for era in data.get('eras', []):
        if era['id'] == era_id:
            data['case']['era'] = era['name']
            break
    save_data(data)
    return jsonify({'success': True, 'era': data['case']['era']})

@app.route('/api/folder/toggle', methods=['POST'])
def toggle_folder_state():
    data = load_data()
    req = request.json or {}
    current_state = data.get('folder', {}).get('isOpen', False)
    new_state = req.get('isOpen', not current_state)
    data.setdefault('folder', {})['isOpen'] = new_state
    if 'x' in req:
        data['folder']['x'] = req['x']
    if 'y' in req:
        data['folder']['y'] = req['y']
    save_data(data)
    return jsonify({'success': True, 'isOpen': new_state, 'folder': data['folder']})

@app.route('/api/folder/position', methods=['POST'])
def folder_position_endpoint():
    data = load_data()
    req = request.json or {}
    if not data.get('folder'):
        data['folder'] = {}
    if 'x' in req:
        data['folder']['x'] = round(req['x'])
    if 'y' in req:
        data['folder']['y'] = round(req['y'])
    save_data(data)
    return jsonify({'success': True, 'folder': data['folder']})

@app.route('/api/id_card', methods=['GET', 'POST', 'DELETE'])
@app.route('/api/id_cards', methods=['GET', 'POST'])
def id_card_endpoint():
    data = load_data()
    if 'idCards' not in data or not isinstance(data['idCards'], list):
        data['idCards'] = [data['idCard']] if data.get('idCard') else []

    if request.method == 'GET':
        return jsonify({
            'success': True,
            'idCards': data['idCards'],
            'idCard': data['idCards'][0] if data['idCards'] else data.get('idCard', {})
        })

    if request.method == 'DELETE':
        req = request.json or {}
        card_id = req.get('id') or request.args.get('id')
        if card_id:
            data['idCards'] = [c for c in data['idCards'] if c.get('id') != card_id]
            data['idCard'] = data['idCards'][0] if data['idCards'] else {}
            clue_id = f"clue-oc-id-{card_id}"
            data['connections'] = [c for c in data.get('connections', []) if c.get('from') != clue_id and c.get('to') != clue_id]
            save_data(data)
        return jsonify({'success': True, 'idCards': data['idCards']})

    if request.method == 'POST':
        if request.content_type and 'multipart/form-data' in request.content_type:
            card_id = request.form.get('id', f"oc-id-{len(data['idCards']) + 1}")
            target_card = next((c for c in data['idCards'] if c.get('id') == card_id), None)
            if not target_card:
                target_card = {'id': card_id}
                data['idCards'].append(target_card)

            target_card['creator'] = request.form.get('creator', target_card.get('creator', 'AGENT TIGER'))
            target_card['name'] = request.form.get('name', target_card.get('name', ''))
            target_card['birthdate'] = request.form.get('birthdate', target_card.get('birthdate', ''))
            target_card['age'] = request.form.get('age', target_card.get('age', ''))
            target_card['nationality'] = request.form.get('nationality', target_card.get('nationality', ''))
            target_card['species'] = request.form.get('species', target_card.get('species', ''))
            target_card['gender'] = request.form.get('gender', target_card.get('gender', 'fem'))
            target_card['height'] = request.form.get('height', target_card.get('height', ''))
            target_card['weight'] = request.form.get('weight', target_card.get('weight', ''))
            target_card['sexuality'] = request.form.get('sexuality', target_card.get('sexuality', ''))
            target_card['signature'] = request.form.get('signature', target_card.get('signature', ''))
            if 'x' in request.form:
                try: target_card['x'] = float(request.form.get('x'))
                except: pass
            if 'y' in request.form:
                try: target_card['y'] = float(request.form.get('y'))
                except: pass
            if 'photo' in request.form and request.form.get('photo'):
                target_card['photo'] = request.form.get('photo')
            if 'image' in request.files:
                file = request.files['image']
                if file.filename:
                    filename = f"oc_avatar_{uuid.uuid4().hex[:8]}_{file.filename}"
                    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                    target_card['photo'] = f"/static/uploads/{filename}"
            id_data = target_card
        else:
            req = request.json or {}
            if isinstance(req, list):
                data['idCards'] = req
                id_data = req[0] if req else {}
            elif 'idCards' in req and isinstance(req['idCards'], list):
                data['idCards'] = req['idCards']
                id_data = data['idCards'][0] if data['idCards'] else {}
            else:
                card_id = req.get('id', f"oc-id-{len(data['idCards']) + 1}")
                req['id'] = card_id
                target_card = next((c for c in data['idCards'] if c.get('id') == card_id), None)
                if target_card:
                    target_card.update(req)
                    id_data = target_card
                else:
                    data['idCards'].append(req)
                    id_data = req
        
        data['idCard'] = data['idCards'][0] if data['idCards'] else {}
        save_data(data)
        return jsonify({'success': True, 'idCard': id_data, 'idCards': data['idCards']})

@app.route('/api/clues', methods=['POST'])
def add_clue():
    data = load_data()
    
    # Check if multipart form or JSON
    if request.content_type and 'multipart/form-data' in request.content_type:
        title = request.form.get('title', 'New Evidence')
        category = request.form.get('category', 'Document')
        tag = request.form.get('tag', 'Field Clue')
        dossier_text = request.form.get('dossierText', '')
        cipher = request.form.get('cipher', '')
        audio_text = request.form.get('audioIntercept', '')
        
        image_url = '/static/images/dossier_agent.jpg'
        if 'image' in request.files:
            file = request.files['image']
            if file.filename:
                filename = f"{uuid.uuid4().hex[:8]}_{file.filename}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                image_url = f"/static/uploads/{filename}"
    else:
        req = request.json or {}
        title = req.get('title', 'New Evidence')
        category = req.get('category', 'Document')
        tag = req.get('tag', 'Field Clue')
        dossier_text = req.get('dossierText', '')
        cipher = req.get('cipher', '')
        audio_text = req.get('audioIntercept', '')
        image_url = req.get('image', '/static/images/dossier_agent.jpg')

    new_id = f"clue-{uuid.uuid4().hex[:6]}"
    new_clue = {
        "id": new_id,
        "title": title,
        "category": category,
        "tag": tag,
        "date": "1929.10.24",
        "image": image_url,
        "x": 420 + (len(data.get('clues', [])) % 4) * 30,
        "y": 280 + (len(data.get('clues', [])) % 4) * 25,
        "width": 200,
        "height": 220,
        "rotation": -3 + (len(data.get('clues', [])) % 7),
        "pinX": 100,
        "pinY": 20,
        "status": "uninspected",
        "classification": "FIELD REPORT // RECENT INGESTION",
        "dossierText": dossier_text or "Newly pinned evidence from field investigation. Awaiting deeper forensic frequency analysis.",
        "cipher": cipher or "ANOMALOUS TRACE DETECTED",
        "audioIntercept": audio_text or "Ambient background static with intermittent frequency pulse."
    }
    
    data.setdefault('clues', []).append(new_clue)
    save_data(data)
    return jsonify({'success': True, 'clue': new_clue})

@app.route('/api/clues/<clue_id>', methods=['PUT'])
def update_clue(clue_id):
    data = load_data()
    req = request.json or {}
    target = None
    for c in data.get('clues', []):
        if c['id'] == clue_id:
            target = c
            break
            
    if not target:
        return jsonify({'error': 'Clue not found'}), 404
        
    for k in ['x', 'y', 'width', 'height', 'rotation', 'title', 'tag', 'status', 'dossierText', 'cipher']:
        if k in req:
            target[k] = req[k]
            
    save_data(data)
    return jsonify({'success': True, 'clue': target})

@app.route('/api/clues/<clue_id>', methods=['DELETE'])
def delete_clue(clue_id):
    data = load_data()
    data['clues'] = [c for c in data.get('clues', []) if c['id'] != clue_id]
    data['connections'] = [conn for conn in data.get('connections', []) if conn['from'] != clue_id and conn['to'] != clue_id]
    save_data(data)
    return jsonify({'success': True})

@app.route('/api/connections', methods=['POST'])
def add_connection():
    data = load_data()
    req = request.json or {}
    from_id = req.get('from')
    to_id = req.get('to')
    label = req.get('label', 'Arcane Link')
    
    if not from_id or not to_id or from_id == to_id:
        return jsonify({'error': 'Invalid connection nodes'}), 400
        
    # Check duplicate
    for c in data.get('connections', []):
        if (c['from'] == from_id and c['to'] == to_id) or (c['from'] == to_id and c['to'] == from_id):
            return jsonify({'success': True, 'message': 'Connection already exists', 'connection': c})
            
    conn = {
        'from': from_id,
        'to': to_id,
        'label': label
    }
    data.setdefault('connections', []).append(conn)
    save_data(data)
    return jsonify({'success': True, 'connection': conn})

@app.route('/api/connections', methods=['DELETE'])
def remove_connection():
    data = load_data()
    req = request.json or {}
    from_id = req.get('from')
    to_id = req.get('to')
    
    data['connections'] = [
        c for c in data.get('connections', [])
        if not ((c['from'] == from_id and c['to'] == to_id) or (c['from'] == to_id and c['to'] == from_id))
    ]
    save_data(data)
    return jsonify({'success': True})

@app.route('/api/deduce', methods=['POST'])
def check_deductions():
    data = load_data()
    connected_pairs = set()
    for c in data.get('connections', []):
        connected_pairs.add(tuple(sorted([c['from'], c['to']])))
        
    solved_any = False
    newly_solved = []
    
    for deduction in data.get('deductions', []):
        req_clues = deduction.get('requiredClues', [])
        # Check if all pairs in req_clues are directly or transitively connected
        # For simplicity, check if every consecutive pair or star link is present
        all_linked = True
        for i in range(len(req_clues) - 1):
            pair = tuple(sorted([req_clues[i], req_clues[i+1]]))
            if pair not in connected_pairs:
                all_linked = False
                break
                
        if all_linked and not deduction.get('solved', False):
            deduction['solved'] = True
            solved_any = True
            newly_solved.append(deduction)
            
    if solved_any:
        save_data(data)
        
    return jsonify({
        'success': True,
        'deductions': data.get('deductions', []),
        'newlySolved': newly_solved
    })

@app.route('/api/reset', methods=['POST'])
def reset_board():
    if os.path.exists(DEFAULT_BACKUP):
        shutil.copyfile(DEFAULT_BACKUP, DATA_FILE)
    return jsonify({'success': True, 'data': load_data()})

@app.route('/api/export', methods=['GET'])
def export_dossier():
    data = load_data()
    report = {
        'case_header': data.get('case', {}),
        'total_clues': len(data.get('clues', [])),
        'active_connections': len(data.get('connections', [])),
        'solved_deductions': [d['title'] for d in data.get('deductions', []) if d.get('solved')],
        'dossiers': [
            {
                'title': c['title'],
                'tag': c.get('tag'),
                'date': c.get('date'),
                'classification': c.get('classification'),
                'forensic_text': c.get('dossierText'),
                'cipher': c.get('cipher')
            }
            for c in data.get('clues', [])
        ]
    }
    return jsonify(report)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5050))
    print(f"[*] Reverse 1999 Tactical Investigation Board running on http://localhost:{port}")
    app.run(host='0.0.0.0', port=port, debug=True)
