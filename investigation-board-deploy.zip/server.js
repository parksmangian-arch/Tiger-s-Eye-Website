const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const BASE_DIR = __dirname;
const DATA_FILE = path.join(BASE_DIR, 'data', 'case_data.json');
const BACKUP_FILE = path.join(BASE_DIR, 'data', 'case_data_backup.json');
const UPLOAD_DIR = path.join(BASE_DIR, 'static', 'uploads');

if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

function loadData() {
  try {
    if (!fs.existsSync(DATA_FILE) && fs.existsSync(BACKUP_FILE)) {
      fs.copyFileSync(BACKUP_FILE, DATA_FILE);
    }
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
  } catch (e) {
    return { case: {}, clues: [], connections: [], deductions: [] };
  }
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff'
};

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;

  // Enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // 1. Root route
  if (pathname === '/' || pathname === '/index.html') {
    const indexPath = path.join(BASE_DIR, 'templates', 'index.html');
    if (fs.existsSync(indexPath)) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(fs.readFileSync(indexPath));
      return;
    }
  }

  // 2. Static files
  if (pathname.startsWith('/static/')) {
    const filePath = path.join(BASE_DIR, pathname);
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
      const ext = path.extname(filePath).toLowerCase();
      const mime = MIME_TYPES[ext] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': mime });
      res.end(fs.readFileSync(filePath));
      return;
    } else {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
  }

  // 3. API Routes
  if (pathname === '/api/case' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(loadData()));
    return;
  }

  if (pathname === '/api/id_card' || pathname === '/api/id_cards') {
    const data = loadData();
    if (!data.idCards || !Array.isArray(data.idCards)) {
      data.idCards = data.idCard ? [{ id: 'oc-id-1', ...data.idCard }] : [];
    }

    if (req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ 
        success: true, 
        idCards: data.idCards, 
        idCard: data.idCards[0] || data.idCard || {} 
      }));
      return;
    }

    if (req.method === 'POST') {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', () => {
        try {
          const bodyJson = JSON.parse(body || '{}');
          if (Array.isArray(bodyJson)) {
            data.idCards = bodyJson;
          } else if (bodyJson.idCards && Array.isArray(bodyJson.idCards)) {
            data.idCards = bodyJson.idCards;
          } else {
            const cardId = bodyJson.id || ('oc-id-' + Date.now());
            bodyJson.id = cardId;
            const idx = data.idCards.findIndex(c => c.id === cardId);
            if (idx >= 0) {
              data.idCards[idx] = Object.assign(data.idCards[idx], bodyJson);
            } else {
              data.idCards.push(bodyJson);
            }
          }
          data.idCard = data.idCards[0] || {};

          // Sync clue for primary or updated card
          if (Array.isArray(data.clues)) {
            for (let c of data.clues) {
              if (c.id === 'clue-oc-id') {
                c.title = `Certified OC ID: ${data.idCard.name || 'Identification Card'}`;
                if (data.idCard.photo) c.image = data.idCard.photo;
                break;
              }
            }
          }

          saveData(data);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, idCard: data.idCard, idCards: data.idCards }));
        } catch (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
        }
      });
      return;
    }

    if (req.method === 'DELETE') {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', () => {
        try {
          const bodyJson = JSON.parse(body || '{}');
          const idToDelete = bodyJson.id || parsedUrl.query.id;
          if (idToDelete) {
            data.idCards = (data.idCards || []).filter(c => c.id !== idToDelete);
            data.idCard = data.idCards[0] || {};
            // Also clean up connections for this deleted ID
            const clueId = `clue-oc-id-${idToDelete}`;
            data.connections = (data.connections || []).filter(c => c.from !== clueId && c.to !== clueId);
            saveData(data);
          }
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, idCards: data.idCards, idCard: data.idCards[0] }));
        } catch (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: err.message }));
        }
      });
      return;
    }
  }

  if (pathname.startsWith('/api/clues')) {
    const data = loadData();
    const parts = pathname.split('/').filter(Boolean);
    const clueId = parts[2]; // /api/clues/:id

    if (clueId && req.method === 'DELETE') {
      data.clues = (data.clues || []).filter(c => c.id !== clueId);
      data.connections = (data.connections || []).filter(c => c.from !== clueId && c.to !== clueId);
      saveData(data);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true }));
      return;
    }

    if (clueId && req.method === 'PUT') {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', () => {
        try {
          const reqJson = JSON.parse(body || '{}');
          const target = (data.clues || []).find(c => c.id === clueId);
          if (target) {
            for (let k of ['x', 'y', 'width', 'height', 'rotation', 'title', 'tag', 'status', 'dossierText', 'cipher', 'onBoard', 'inFolder', 'flapX', 'flapY', 'format', 'personName', 'category', 'image']) {
              if (reqJson[k] !== undefined) target[k] = reqJson[k];
            }
            saveData(data);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true, clue: target }));
          } else {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Clue not found' }));
          }
        } catch (e) {
          res.writeHead(400);
          res.end(JSON.stringify({ error: e.message }));
        }
      });
      return;
    }

    if (!clueId && req.method === 'POST') {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', () => {
        try {
          const reqJson = JSON.parse(body || '{}');
          if (!data.clues) data.clues = [];
          if (!reqJson.id) reqJson.id = 'clue-' + Date.now();
          if (!reqJson.title) reqJson.title = 'New Evidence Artifact';
          if (!reqJson.category) reqJson.category = 'Photograph';
          if (!reqJson.tag) reqJson.tag = 'Field Clue';

          if (!reqJson.format) {
            if (reqJson.category === 'Missing Paper' || (reqJson.title && reqJson.title.toLowerCase().includes('missing'))) {
              reqJson.format = 'missing';
            } else if (reqJson.category === 'Document') {
              reqJson.format = 'document';
            } else {
              reqJson.format = 'polaroid';
            }
          }

          if (reqJson.format === 'missing') {
            if (reqJson.width === undefined) reqJson.width = 205;
            if (reqJson.height === undefined) reqJson.height = 305;
            if (!reqJson.image) reqJson.image = '/static/images/missing_person_poster.jpg';
            if (!reqJson.personName) reqJson.personName = 'UNKNOWN SUBJECT';
          } else if (reqJson.format === 'document') {
            if (reqJson.width === undefined) reqJson.width = 215;
            if (reqJson.height === undefined) reqJson.height = 275;
            if (!reqJson.image) reqJson.image = '/static/images/sighting_report_cebu.png';
          } else {
            if (reqJson.width === undefined) reqJson.width = 195;
            if (reqJson.height === undefined) reqJson.height = 235;
            if (!reqJson.image) reqJson.image = '/static/images/creature_polaroid.png';
          }

          if (reqJson.inFolder !== undefined) {
            reqJson.inFolder = Boolean(reqJson.inFolder);
            if (reqJson.inFolder) reqJson.onBoard = false;
          }
          if (reqJson.onBoard !== undefined) {
            reqJson.onBoard = Boolean(reqJson.onBoard);
          }
          if (reqJson.x === undefined || reqJson.x === null || reqJson.x === '') {
            reqJson.x = 420 + ((data.clues.length * 35) % 350);
          } else {
            reqJson.x = Number(reqJson.x);
          }
          if (reqJson.y === undefined || reqJson.y === null || reqJson.y === '') {
            reqJson.y = 220 + ((data.clues.length * 28) % 220);
          } else {
            reqJson.y = Number(reqJson.y);
          }
          if (reqJson.rotation === undefined) reqJson.rotation = Math.floor(Math.random() * 6) - 3;
          if (reqJson.pinX === undefined) reqJson.pinX = Math.round(reqJson.width / 2);
          if (reqJson.pinY === undefined) reqJson.pinY = 14;
          if (!reqJson.status) reqJson.status = 'uninspected';
          if (!reqJson.classification) reqJson.classification = 'FIELD REPORT // RECENT INGESTION';
          if (!reqJson.dossierText) reqJson.dossierText = 'Newly pinned evidence from field investigation.';
          if (!reqJson.cipher) reqJson.cipher = 'ANOMALOUS TRACE DETECTED';
          data.clues.push(reqJson);
          saveData(data);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, clue: reqJson }));
        } catch (e) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: e.message }));
        }
      });
      return;
    }
  }

  if (pathname === '/api/connections') {
    const data = loadData();
    if (req.method === 'POST') {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', () => {
        try {
          const conn = JSON.parse(body);
          if (!data.connections) data.connections = [];
          const exists = data.connections.some(c => (c.from === conn.from && c.to === conn.to) || (c.from === conn.to && c.to === conn.from));
          if (!exists) {
            data.connections.push(conn);
            saveData(data);
          }
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, connection: conn }));
        } catch (e) {
          res.writeHead(400);
          res.end(JSON.stringify({ success: false }));
        }
      });
      return;
    }
    if (req.method === 'DELETE') {
      let body = '';
      req.on('data', chunk => { body += chunk; });
      req.on('end', () => {
        try {
          const conn = JSON.parse(body);
          data.connections = (data.connections || []).filter(c => !((c.from === conn.from && c.to === conn.to) || (c.from === conn.to && c.to === conn.from)));
          saveData(data);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true }));
        } catch (e) {
          res.writeHead(400);
          res.end(JSON.stringify({ success: false }));
        }
      });
      return;
    }
  }

  if (pathname === '/api/deduce' && req.method === 'POST') {
    const data = loadData();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: true, deductions: data.deductions || [], newlySolved: [] }));
    return;
  }

  if (pathname === '/api/folder/toggle' && req.method === 'POST') {
    const data = loadData();
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const bodyJson = JSON.parse(body || '{}');
        const current = data.folder?.isOpen || false;
        const nextState = bodyJson.isOpen !== undefined ? bodyJson.isOpen : !current;
        if (!data.folder) data.folder = {};
        data.folder.isOpen = nextState;
        if (bodyJson.x !== undefined) data.folder.x = Math.round(bodyJson.x);
        if (bodyJson.y !== undefined) data.folder.y = Math.round(bodyJson.y);
        saveData(data);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, isOpen: nextState, folder: data.folder }));
      } catch (e) {
        res.writeHead(400);
        res.end();
      }
    });
    return;
  }

  if (pathname === '/api/folder/position' && req.method === 'POST') {
    const data = loadData();
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const bodyJson = JSON.parse(body || '{}');
        if (!data.folder) data.folder = {};
        if (bodyJson.x !== undefined) data.folder.x = Math.round(bodyJson.x);
        if (bodyJson.y !== undefined) data.folder.y = Math.round(bodyJson.y);
        saveData(data);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, folder: data.folder }));
      } catch (e) {
        res.writeHead(400);
        res.end();
      }
    });
    return;
  }

  if (pathname === '/api/reset' && req.method === 'POST') {
    if (fs.existsSync(BACKUP_FILE)) {
      fs.copyFileSync(BACKUP_FILE, DATA_FILE);
    }
    const data = loadData();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: true, data }));
    return;
  }

  if (pathname === '/api/export' && req.method === 'GET') {
    const data = loadData();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      case_header: data.case,
      evidence_count: (data.clues || []).length,
      connections_count: (data.connections || []).length,
      clues: data.clues || [],
      connections: data.connections || []
    }));
    return;
  }

  res.writeHead(404);
  res.end('Not found');
});

const PORT = process.env.PORT || 5050;
server.listen(PORT, () => {
  console.log(`[+] Investigation Board server listening on http://localhost:${PORT}`);
});
