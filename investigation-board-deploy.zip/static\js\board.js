/**
 * CURRENT 平衡小结 · Reverse 1999 Tactical Investigation Board
 * Dynamic Red Yarn Physics, Tactical Evidence Dossier, and Web Audio Soundscape
 */

(function () {
  'use strict';

  // --- Board State ---
  const state = {
    caseData: null,
    idCard: null,
    idCards: [],
    activeIdCardId: null,
    isIdCardFlipped: false,
    idCardSaveTimer: null,
    isFolderOpen: false,
    isStringToolActive: false,
    selectedPin: null, // { clueId, x, y, element }
    currentModalClueId: null,
    isUvActive: false,
    isAudioOn: false,
    audioContext: null,
    ambientNodes: null,
    interceptAudio: null,
    draggingClue: null,
    dragOffset: { x: 0, y: 0 },
    hasMovedDuringDrag: false,
    isLoupeActive: false
  };

  const FOLDER_CLUES = new Set([
    'clue-polaroid', 'clue-sightings-log', 'clue-bureau-card',
    'clue-warding', 'clue-red-dossier', 'clue-report-cebu', 'clue-visayas-map'
  ]);

  // --- DOM Elements ---
  const dom = {
    viewport: document.getElementById('board-viewport'),
    surface: document.getElementById('board-surface'),
    stringsSvg: document.getElementById('strings-svg'),
    cluesContainer: document.getElementById('clues-container'),
    connectedCount: document.getElementById('connected-count'),
    deductionBadge: document.getElementById('deduction-badge'),
    
    // HUD Buttons
    btnStringTool: document.getElementById('btn-string-tool'),
    btnAddClue: document.getElementById('btn-add-clue'),
    btnDeductions: document.getElementById('btn-deductions'),
    btnAudioToggle: document.getElementById('btn-audio-toggle'),
    audioIcon: document.getElementById('audio-icon'),
    btnSfxToggle: document.getElementById('btn-sfx-toggle'),
    sfxIcon: document.getElementById('sfx-icon'),
    btnExportDossier: document.getElementById('btn-export-dossier'),
    btnResetBoard: document.getElementById('btn-reset-board'),
    eraSelect: document.getElementById('era-select'),

    // Dossier Modal
    dossierModal: document.getElementById('dossier-modal'),
    modalCloseBtn: document.getElementById('modal-close-btn'),
    modalTitle: document.getElementById('modal-title'),
    modalClassification: document.getElementById('modal-classification'),
    modalMeta: document.getElementById('modal-meta'),
    modalMediaFrame: document.getElementById('modal-media-frame'),
    modalImage: document.getElementById('modal-image'),
    modalUvOverlay: document.getElementById('modal-uv-overlay'),
    modalUvText: document.getElementById('modal-uv-text'),
    modalText: document.getElementById('modal-text'),
    modalCipher: document.getElementById('modal-cipher'),
    modalAudioQuote: document.getElementById('modal-audio-quote'),
    btnToggleUv: document.getElementById('btn-toggle-uv'),
    btnModalConnect: document.getElementById('btn-modal-connect'),
    btnViewFullScan: document.getElementById('btn-view-full-scan'),
    btnPlayIntercept: document.getElementById('btn-play-intercept'),
    btnDeleteClue: document.getElementById('btn-delete-clue'),

    // Scan / Lightbox Modal
    scanModal: document.getElementById('scan-modal'),
    scanModalCloseBtn: document.getElementById('scan-modal-close-btn'),
    lightboxFullImg: document.getElementById('lightbox-full-img'),

    // Forensic Loupe
    modalLoupe: document.getElementById('modal-loupe'),
    btnToggleLoupe: document.getElementById('btn-toggle-loupe'),

    // Classified Report Modal
    reportModal: document.getElementById('report-modal'),
    reportModalCloseBtn: document.getElementById('report-modal-close-btn'),
    reportBodyContent: document.getElementById('report-body-content'),
    btnReportPrint: document.getElementById('btn-report-print'),
    btnReportDownloadJson: document.getElementById('btn-report-download-json'),

    // Interactive Folder Elements
    folderWrapper: document.getElementById('folder-wrapper'),
    folderSpread: document.getElementById('folder-spread'),
    folderClosedCover: document.getElementById('folder-closed-cover'),
    btnToggleFolder: document.getElementById('btn-toggle-folder'),
    btnMinimizeFolder: document.getElementById('btn-minimize-folder'),
    btnHudFolderToggle: document.getElementById('btn-hud-folder-toggle'),
    hudFolderIcon: document.getElementById('hud-folder-icon'),
    hudFolderLabel: document.getElementById('hud-folder-label'),
    folderToggleIcon: document.getElementById('folder-toggle-icon'),
    folderTabBadge: document.getElementById('folder-tab-badge'),
    extraCluesLayer: document.getElementById('extra-clues-layer'),

    // Add Modal
    addModal: document.getElementById('add-modal'),
    addModalCloseBtn: document.getElementById('add-modal-close-btn'),
    btnCancelAdd: document.getElementById('btn-cancel-add'),
    addClueForm: document.getElementById('add-clue-form'),

    // Deductions Modal & Toast
    deductionsModal: document.getElementById('deductions-modal'),
    deductionsModalCloseBtn: document.getElementById('deductions-modal-close-btn'),
    btnCloseDeductions: document.getElementById('btn-close-deductions'),
    deductionsList: document.getElementById('deductions-list'),
    deductionToast: document.getElementById('deduction-toast'),
    toastTitle: document.getElementById('toast-deduction-title'),
    toastDesc: document.getElementById('toast-deduction-desc'),

    // Desk Tools Workstation & Multi-ID Layer
    boardDeskTools: document.getElementById('board-desk-tools'),
    boardTrashBin: document.getElementById('board-trash-bin'),
    boardPinBasket: document.getElementById('board-pin-basket'),
    boardIdCardsLayer: document.getElementById('board-id-cards-layer'),
    boardRoamingPapersLayer: document.getElementById('board-roaming-papers-layer'),
    closedEvidenceBadgeText: document.getElementById('closed-evidence-badge-text'),
    idBadgeCount: document.getElementById('id-badge-count'),

    // Make ID Studio Elements
    btnMakeId: document.getElementById('btn-make-id'),
    idMakerModal: document.getElementById('id-maker-modal'),
    idModalCloseBtn: document.getElementById('id-modal-close-btn'),
    boardPinnedId: document.getElementById('board-pinned-id'),
    ocIdForm: document.getElementById('oc-id-form'),
    inputOcCreator: document.getElementById('input-oc-creator'),
    inputOcName: document.getElementById('input-oc-name'),
    inputOcPhotoFile: document.getElementById('input-oc-photo-file'),
    btnTriggerPhotoUpload: document.getElementById('btn-trigger-photo-upload'),
    previewPhotoBox: document.getElementById('preview-photo-box'),
    inputOcBirthdate: document.getElementById('input-oc-birthdate'),
    inputOcAge: document.getElementById('input-oc-age'),
    inputOcNationality: document.getElementById('input-oc-nationality'),
    inputOcSpecies: document.getElementById('input-oc-species'),
    inputOcHeight: document.getElementById('input-oc-height'),
    inputOcWeight: document.getElementById('input-oc-weight'),
    inputOcSexuality: document.getElementById('input-oc-sexuality'),
    inputOcSignature: document.getElementById('input-oc-signature'),
    btnDownloadId: document.getElementById('btn-download-id'),
    btnToggleIdPinned: document.getElementById('btn-toggle-id-pinned'),
    pinIdBtnText: document.getElementById('pin-id-btn-text'),
    modalIdPhotoDisplay: document.getElementById('modal-id-photo-display'),
    boardIdPhotoDisplay: document.getElementById('board-id-photo-display'),

    // Cinematic ID Focus Mode Elements
    idFocusStage: document.getElementById('id-focus-stage'),
    idFocusBackdrop: document.getElementById('id-focus-backdrop'),
    btnExitIdFocus: document.getElementById('btn-exit-id-focus'),
    idCardViewport: document.getElementById('id-card-viewport'),
    idCardFlipper: document.getElementById('id-card-flipper'),
    cardLaminateGlare: document.getElementById('card-laminate-glare'),
    focusedPhotoBox: document.getElementById('focused-photo-box'),
    focusedIdPhotoDisplay: document.getElementById('focused-id-photo-display'),
    focusedIdGenderCircle: document.getElementById('focused-id-gender-circle'),
    idAvatarPopover: document.getElementById('id-avatar-popover'),
    btnCloseAvatarPopover: document.getElementById('btn-close-avatar-popover'),
    btnFlipCardTop: document.getElementById('btn-flip-card-top'),
    btnFocusXClose: document.getElementById('btn-focus-x-close'),
    btnFocusFlip: document.getElementById('btn-focus-flip'),
    btnFocusPhoto: document.getElementById('btn-focus-photo'),
    btnFocusRandom: document.getElementById('btn-focus-random'),
    btnFocusDownload: document.getElementById('btn-focus-download'),
    btnFocusDone: document.getElementById('btn-focus-done'),
    focusOcPhotoFile: document.getElementById('focus-oc-photo-file'),
    btnFocusTriggerUpload: document.getElementById('btn-focus-trigger-upload'),
    cardThumbprintBox: document.getElementById('card-thumbprint-box'),
    cardThumbprintMark: document.getElementById('card-thumbprint-mark'),

    // Multi-ID Focus Navigation & Actions
    btnPrevId: document.getElementById('btn-prev-id'),
    btnNextId: document.getElementById('btn-next-id'),
    idCounterBadge: document.getElementById('id-counter-badge'),
    btnFocusNewId: document.getElementById('btn-focus-new-id'),
    btnFocusDeleteId: document.getElementById('btn-focus-delete-id')
  };

  // --- Initial Setup ---
  async function init() {
    // Unconditionally ensure clean initial state (no stuck focus overlay)
    document.body.classList.remove('id-focus-active');
    if (dom.idFocusStage) dom.idFocusStage.classList.add('hidden');
    if (dom.idAvatarPopover) dom.idAvatarPopover.classList.add('hidden');
    if (dom.idMakerModal) dom.idMakerModal.classList.add('hidden');

    state.isFolderOpen = false;

    setupLucideIcons();
    setupEventListeners();
    await loadCaseData();
    await loadIdCards();
    renderBoard();
    setupFolderToggle();
  }

  function setupLucideIcons() {
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }
  }

  // --- Audio Synthesis via Web Audio API ---
  function getAudioContext() {
    if (!state.audioContext) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      state.audioContext = new AudioCtx();
    }
    if (state.audioContext.state === 'suspended') {
      state.audioContext.resume();
    }
    return state.audioContext;
  }

  // Play subtle metallic brass pushpin ping
  function playPinSound() {
    try {
      if (window.PaperAudio) window.PaperAudio.tap(0.7, 'card');
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(1400, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(320, ctx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.13);
    } catch (e) {
      console.warn('Audio not allowed yet', e);
    }
  }

  // Play crisp clink when grabbing a pin from the brass basket
  function playPinBasketPickupSound() {
    try {
      if (window.PaperAudio) window.PaperAudio.tap(0.85, 'card');
      const ctx = getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(1750, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(480, ctx.currentTime + 0.1);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.11);
    } catch (_) {}
  }

  // Play impactful thunk + ping when pin is pushed firmly into evidence paper
  function playPinDriveInSound() {
    try {
      if (window.PaperAudio) window.PaperAudio.tap(1.2, 'heavy');
      playPinSound();
    } catch (_) {}
  }

  // Play slide / extraction sound when pulling out a pushpin
  function playPinExtractionSound() {
    try {
      if (window.PaperAudio) window.PaperAudio.tap(0.65, 'subtle');
      const ctx = getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(450, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1500, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.09);
    } catch (_) {}
  }

  // Play paper tension tug when trying to move pinned evidence
  function playPinTugSound() {
    try {
      if (window.PaperAudio) window.PaperAudio.tap(0.65, 'card');
      const ctx = getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(360, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(120, ctx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.14, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.13);
    } catch (_) {}
  }

  // Play acoustic plucked string note (for red yarn interaction)
  function playStringPluckSound(freq = 320) {
    try {
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.98, ctx.currentTime + 0.3);

      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(950, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(120, ctx.currentTime + 0.3);

      gain.gain.setValueAtTime(0.14, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.32);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.33);
    } catch (e) {}
  }

  // Play string snap sound
  function playStringSnapSound() {
    try {
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(620, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.22, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.09);
    } catch (e) {}
  }

  // Play tactile paper / tape thud
  function playPaperThud() {
    try {
      if (window.PaperAudio) {
        window.PaperAudio.thud();
        return;
      }
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(120, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.18, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.09);
    } catch (e) {
      console.warn('Audio not allowed yet', e);
    }
  }

  // Camera focus / lens chirp
  function playCameraFocusSound() {
    try {
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.09, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.13);
    } catch (e) {}
  }

  // Typewriter key click sound
  function playTypewriterKey() {
    try {
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(1400 + Math.random() * 400, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(250, ctx.currentTime + 0.035);
      gain.gain.setValueAtTime(0.07, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.045);
    } catch (e) {}
  }

  // Rubber stamp impact thud
  function playStampSound() {
    try {
      if (window.PaperAudio) window.PaperAudio.tap(1.2, 'heavy');
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(170, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.1);
      
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(650, ctx.currentTime);

      gain.gain.setValueAtTime(0.22, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.11);
      
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.12);
    } catch (e) {}
  }

  // Card 3D flip whoosh
  function playCardFlipSound() {
    try {
      if (window.PaperAudio) {
        window.PaperAudio.flip();
        return;
      }
      const ctx = getAudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(260, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(620, ctx.currentTime + 0.09);
      osc.frequency.exponentialRampToValueAtTime(160, ctx.currentTime + 0.18);
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.21);
    } catch (e) {}
  }

  // Play mystical glass deduction chime
  function playDeductionChime() {
    try {
      const ctx = getAudioContext();
      const freqs = [528, 660, 792, 1056];
      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.1);
        gain.gain.setValueAtTime(0.15, ctx.currentTime + idx * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.1 + 0.9);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.1);
        osc.stop(ctx.currentTime + idx * 0.1 + 0.95);
      });
    } catch (e) {
      console.warn('Audio not allowed yet', e);
    }
  }

  // Atmospheric Soundscape (Rain, Vinyl Crackle, 432Hz Drone)
  function toggleAtmosphericAudio() {
    const ctx = getAudioContext();
    if (state.isAudioOn) {
      // Turn off
      if (state.ambientNodes) {
        state.ambientNodes.masterGain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
        setTimeout(() => {
          if (state.ambientNodes) {
            state.ambientNodes.sources.forEach(s => {
              try { s.stop(); } catch(e){}
            });
            state.ambientNodes = null;
          }
        }, 550);
      }
      state.isAudioOn = false;
      dom.btnAudioToggle.classList.remove('active');
      dom.audioIcon.setAttribute('data-lucide', 'volume-x');
    } else {
      // Turn on
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.0001, ctx.currentTime);
      masterGain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 1.2);
      masterGain.connect(ctx.destination);

      const sources = [];

      // 1. Drone Oscillator (432 Hz arcanum harmonic)
      const drone = ctx.createOscillator();
      const droneGain = ctx.createGain();
      drone.type = 'sine';
      drone.frequency.setValueAtTime(432 / 4, ctx.currentTime); // 108Hz deep bass
      droneGain.gain.value = 0.35;
      drone.connect(droneGain);
      droneGain.connect(masterGain);
      drone.start();
      sources.push(drone);

      // 2. Vinyl Crackle & Rain Simulator (White noise with random pops)
      const bufferSize = ctx.sampleRate * 2;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        // Soft rain hiss + sparse vinyl pops
        const isPop = Math.random() < 0.0015;
        output[i] = (Math.random() * 2 - 1) * 0.1 + (isPop ? (Math.random() * 0.8) : 0);
      }

      const noiseSource = ctx.createBufferSource();
      noiseSource.buffer = noiseBuffer;
      noiseSource.loop = true;

      // Bandpass filter to sound like gentle rain outside detective office
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(900, ctx.currentTime);
      filter.Q.setValueAtTime(0.8, ctx.currentTime);

      noiseSource.connect(filter);
      filter.connect(masterGain);
      noiseSource.start();
      sources.push(noiseSource);

      state.ambientNodes = { masterGain, sources };
      state.isAudioOn = true;
      dom.btnAudioToggle.classList.add('active');
      dom.audioIcon.setAttribute('data-lucide', 'volume-2');
    }
    setupLucideIcons();
  }

  // Radio Intercept Sound Player
  function playInterceptAudio() {
    const ctx = getAudioContext();
    const playBtn = dom.btnPlayIntercept;
    const waveBars = document.querySelectorAll('.wave-bar');

    if (state.interceptAudio) {
      try {
        state.interceptAudio.stop();
      } catch (e) {}
      state.interceptAudio = null;
      waveBars.forEach(b => b.classList.remove('playing'));
      playBtn.querySelector('span').textContent = 'Replay Audio Log';
      return;
    }

    waveBars.forEach(b => b.classList.add('playing'));
    playBtn.querySelector('span').textContent = 'Transmission Playing...';

    // Heterodyne radio whistle + Morse code simulation
    const carrier = ctx.createOscillator();
    const carrierGain = ctx.createGain();
    carrier.type = 'sine';
    carrier.frequency.setValueAtTime(880, ctx.currentTime);
    carrier.frequency.linearRampToValueAtTime(920, ctx.currentTime + 1.5);
    carrier.frequency.linearRampToValueAtTime(840, ctx.currentTime + 3.0);

    // Amplitude modulation for Morse-like beeping
    carrierGain.gain.setValueAtTime(0.08, ctx.currentTime);
    const morseTimes = [0.2, 0.4, 0.7, 0.9, 1.2, 1.5, 1.9, 2.2, 2.6];
    morseTimes.forEach(t => {
      carrierGain.gain.setValueAtTime(0.12, ctx.currentTime + t);
      carrierGain.gain.setValueAtTime(0.01, ctx.currentTime + t + 0.1);
    });
    carrierGain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 3.5);

    carrier.connect(carrierGain);
    carrierGain.connect(ctx.destination);
    carrier.start();
    carrier.stop(ctx.currentTime + 3.6);

    state.interceptAudio = carrier;
    setTimeout(() => {
      waveBars.forEach(b => b.classList.remove('playing'));
      playBtn.querySelector('span').textContent = 'Replay Audio Log';
      state.interceptAudio = null;
    }, 3600);
  }

  // --- API Communications ---
  async function loadCaseData() {
    try {
      const res = await fetch('/api/case');
      if (!res.ok) throw new Error('Failed to load case data');
      state.caseData = await res.json();
      if (state.caseData && Array.isArray(state.caseData.connections)) {
        state.caseData.connections = state.caseData.connections.filter(c => 
          !FOLDER_CLUES.has(c.from) && !FOLDER_CLUES.has(c.to) && c.from !== 'clue-case-folder' && c.to !== 'clue-case-folder'
        );
      }
      updateStatusHeader();
    } catch (err) {
      console.error('Error fetching case:', err);
    }
  }

  function updateStatusHeader() {
    if (!state.caseData) return;
    
    // Update era selector if matching
    if (state.caseData.case && state.caseData.case.era) {
      const era = state.caseData.eras.find(e => e.name === state.caseData.case.era);
      if (era && dom.eraSelect) {
        dom.eraSelect.value = era.id;
      }
    }

    // Update connection count
    const connCount = (state.caseData.connections || []).length;
    if (dom.connectedCount) {
      dom.connectedCount.textContent = `${connCount} RED STRINGS ACTIVE`;
    }

    // Update deduction count badge
    const deductions = state.caseData.deductions || [];
    const solved = deductions.filter(d => d.solved).length;
    if (dom.deductionBadge) {
      dom.deductionBadge.textContent = `${solved}/${deductions.length}`;
    }
  }

  // --- Pin Global Coordinates Calculation with Intelligent Caching ---
  const pinCoordsCache = new Map();
  let cachedSurfaceRect = null;

  function invalidatePinCache(clueId) {
    if (clueId) {
      pinCoordsCache.delete(clueId);
    } else {
      pinCoordsCache.clear();
      cachedSurfaceRect = null;
    }
  }

  function getSurfaceRect() {
    if (dom.surface) {
      const rect = dom.surface.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        cachedSurfaceRect = rect;
        return rect;
      }
    }
    const fallbackW = dom.surface ? (dom.surface.clientWidth || dom.surface.offsetWidth) : window.innerWidth;
    const fallbackH = dom.surface ? (dom.surface.clientHeight || dom.surface.offsetHeight) : window.innerHeight;
    return cachedSurfaceRect || { left: 0, top: 0, width: fallbackW || window.innerWidth || 1920, height: fallbackH || window.innerHeight || 1080 };
  }

  function getPinCoordinates(clue, forceFresh = false) {
    const clueId = (typeof clue === 'string') ? clue : clue.id;
    if (!forceFresh && pinCoordsCache.has(clueId)) {
      return pinCoordsCache.get(clueId);
    }

    let pinEl = document.querySelector(`.clue-pin[data-clue-id="${clueId}"]`);
    if (!pinEl && (clueId === 'clue-oc-id' || clueId.startsWith('clue-oc-id'))) {
      pinEl = document.querySelector('.board-id-cards-layer .clue-pin');
    }
    const sRect = getSurfaceRect();

    if (pinEl) {
      const pinRect = pinEl.getBoundingClientRect();
      if (pinRect.width > 0 && pinRect.height > 0) {
        const coords = {
          x: pinRect.left - sRect.left + pinRect.width / 2,
          y: pinRect.top - sRect.top + pinRect.height / 2
        };
        pinCoordsCache.set(clueId, coords);
        return coords;
      }
    }

    // Fallback if not rendered or closed
    if (clue && clue.x !== undefined && clue.y !== undefined) {
      const fallback = {
        x: clue.x + (clue.pinX || 50),
        y: clue.y + (clue.pinY || 20)
      };
      pinCoordsCache.set(clueId, fallback);
      return fallback;
    }
    return { x: 500, y: 300 };
  }

  // --- Board Clue Cards & Strings Rendering ---
  function renderBoard() {
    if (!state.caseData) return;
    setupFolderPapers();
    renderExtraClues();
    renderIdCards();
    restorePlacedPinsState();
    if (dom.folderWrapper && state.caseData.folder) {
      if (state.caseData.folder.x !== undefined && state.caseData.folder.y !== undefined) {
        dom.folderWrapper.style.left = `${state.caseData.folder.x}px`;
        dom.folderWrapper.style.top = `${state.caseData.folder.y}px`;
      }
    }
    if (state.isFolderOpen) {
      openFolder();
    } else {
      closeFolder();
    }
    setTimeout(() => {
      invalidatePinCache();
      requestRenderStrings();
    }, 150);
    updateStatusHeader();
  }

  const FOLDER_ITEM_DEFAULTS = {
    'clue-polaroid': { flap: 'flap-left', itemClass: 'item-polaroid', defaultX: 45, defaultY: 30, rotation: -3 },
    'clue-sightings-log': { flap: 'flap-left', itemClass: 'item-sightings-log', defaultX: 20, defaultY: 260, rotation: 2 },
    'clue-bureau-card': { flap: 'flap-left', itemClass: 'item-bureau-card', defaultX: 220, defaultY: 420, rotation: -2 },
    'clue-warding': { flap: 'flap-right', itemClass: 'item-warding', defaultX: 30, defaultY: 25, rotation: 1 },
    'clue-red-dossier': { flap: 'flap-right', itemClass: 'item-red-dossier', defaultX: 20, defaultY: 95, rotation: -1 },
    'clue-report-cebu': { flap: 'flap-right', itemClass: 'item-report-cebu', defaultX: 28, defaultY: 295, rotation: 2 },
    'clue-visayas-map': { flap: 'flap-right', itemClass: 'item-flight-map', defaultX: 195, defaultY: 55, rotation: 1 }
  };

  function isClueInFolder(clue) {
    if (!clue) return false;
    if (clue.inFolder !== undefined) return Boolean(clue.inFolder);
    if (FOLDER_CLUES.has(clue.id)) return !clue.onBoard;
    return false;
  }

  function updateClosedEvidenceCount() {
    const badge = dom.closedEvidenceBadgeText || document.getElementById('closed-evidence-badge-text');
    if (!badge || !state.caseData) return;
    const folderClues = (state.caseData.clues || []).filter(c => isClueInFolder(c));
    const count = folderClues.length;
    badge.textContent = `${count} EVIDENCE ARTIFACT${count === 1 ? '' : 'S'} ENCLOSED`;
  }

  function putClueIntoFolder(clue, cardEl) {
    if (!clue) return;
    clue.inFolder = true;
    clue.onBoard = false;
    clue.flapX = null;
    clue.flapY = null;

    if (cardEl) {
      cardEl.classList.remove('dragging', 'over-trash');
      cardEl.classList.add('card-filing-into-dossier');
    }

    if (window.PaperAudio) window.PaperAudio.tap(1.0, 'card');
    else playPaperThud();

    saveCluePosition(clue);
    showDisposalToast('EVIDENCE FILED', `"${clue.title}" enclosed into Case Dossier.`);
    setTimeout(() => {
      renderBoard();
    }, cardEl ? 260 : 0);
  }

  function dockPaperIntoFolder(clue, paper) {
    if (!clue) return;
    clue.inFolder = true;
    clue.onBoard = false;
    clue.flapX = null;
    clue.flapY = null;

    if (paper) {
      const def = FOLDER_ITEM_DEFAULTS[clue.id] || { flap: 'flap-left' };
      const flap = dom.folderSpread ? dom.folderSpread.querySelector(`.${def.flap}`) : null;
      if (flap && paper.parentElement !== flap) {
        flap.appendChild(paper);
      }
      paper.classList.remove('paper-on-board', 'dragging', 'over-trash', 'is-picked-up');
      paper.style.left = '';
      paper.style.top = '';
      paper.style.bottom = '';
      paper.style.right = '';
      paper.style.transform = '';
      paper.style.zIndex = '';
    }

    if (window.PaperAudio) window.PaperAudio.tap(1.0, 'card');
    else playPaperThud();

    saveCluePosition(clue);
    showDisposalToast('EVIDENCE ARCHIVED', `"${clue.title}" returned to Case File.`);
    renderBoard();
  }

  function movePaperToBoard(clue, paper, targetBoardX, targetBoardY) {
    if (!clue) return;
    clue.inFolder = false;
    clue.onBoard = true;
    clue.flapX = null;
    clue.flapY = null;

    const sRect = getSurfaceRect();
    const cardW = paper ? (paper.offsetWidth || 200) : (clue.width || 200);
    const cardH = paper ? (paper.offsetHeight || 220) : (clue.height || 220);
    const clampedX = Math.max(10, Math.min(sRect.width - cardW - 10, targetBoardX));
    const clampedY = Math.max(10, Math.min(sRect.height - cardH - 10, targetBoardY));

    const def = FOLDER_ITEM_DEFAULTS[clue.id] || { rotation: 0 };
    clue.x = Math.round(clampedX);
    clue.y = Math.round(clampedY);
    if (clue.rotation === undefined) clue.rotation = def.rotation || 0;

    if (paper && FOLDER_CLUES.has(clue.id)) {
      const roamingLayer = dom.boardRoamingPapersLayer || document.getElementById('board-roaming-papers-layer') || dom.cluesContainer;
      if (roamingLayer) {
        roamingLayer.appendChild(paper);
      }
      paper.classList.add('paper-on-board');
      paper.classList.remove('dragging', 'over-trash', 'is-picked-up');
      paper.style.left = `${clue.x}px`;
      paper.style.top = `${clue.y}px`;
      paper.style.bottom = 'auto';
      paper.style.right = 'auto';
      paper.style.transform = `rotate(${clue.rotation}deg)`;
      paper.style.zIndex = '';
    }

    if (window.PaperAudio) window.PaperAudio.drop({ type: 'card' });
    else playPaperThud();

    saveCluePosition(clue);
    showDisposalToast('EVIDENCE DEPLOYED', `"${clue.title}" pinned to corkboard.`);
    renderBoard();
  }

  function keepPaperInFlap(clue, paper, dx, dy, initialFlapLeft, initialFlapTop) {
    if (!clue || !paper) return;
    paper.classList.remove('dragging', 'over-trash');
    paper.style.zIndex = '';

    const newLeft = Math.round(initialFlapLeft + dx);
    const newTop = Math.round(initialFlapTop + dy);

    paper.style.left = `${newLeft}px`;
    paper.style.top = `${newTop}px`;
    paper.style.bottom = 'auto';
    paper.style.right = 'auto';

    clue.flapX = newLeft;
    clue.flapY = newTop;
    clue.onBoard = false;

    if (window.PaperAudio) window.PaperAudio.drop({ type: 'card' });
    else playPaperThud();

    saveCluePosition(clue);
  }

  function setupFolderPapers() {
    const roamingLayer = dom.boardRoamingPapersLayer || document.getElementById('board-roaming-papers-layer') || dom.cluesContainer;

    // Dynamically render custom / added evidence papers filed into the dossier
    const dynamicFolderContainer = document.getElementById('folder-dynamic-items');
    if (dynamicFolderContainer) {
      dynamicFolderContainer.innerHTML = '';
      const customFolderClues = (state.caseData?.clues || []).filter(c => isClueInFolder(c) && !FOLDER_CLUES.has(c.id) && !c.id.startsWith('clue-oc-id'));
      customFolderClues.forEach((clue, idx) => {
        const paper = document.createElement('div');
        paper.className = 'folder-paper-item item-dynamic-file';
        paper.dataset.id = clue.id;
        paper.id = `paper-${clue.id}`;
        paper.title = `${clue.title} (Click to inspect · Drag to deploy on board)`;

        const clipColors = ['clip-silver', 'clip-red', 'clip-black'];
        const clipColor = clipColors[idx % clipColors.length];

        const staggerX = 25 + (idx % 2) * 50;
        const staggerY = 35 + (idx % 3) * 65;
        const staggerRot = -2 + ((idx * 3) % 6);

        if (clue.flapX !== undefined && clue.flapX !== null && clue.flapY !== undefined && clue.flapY !== null) {
          paper.style.left = `${clue.flapX}px`;
          paper.style.top = `${clue.flapY}px`;
        } else {
          paper.style.left = `${staggerX}px`;
          paper.style.top = `${staggerY}px`;
        }
        paper.style.transform = `rotate(${staggerRot}deg)`;
        paper.style.zIndex = 16 + idx;

        const fmt = getClueFormat(clue);
        if (fmt === 'missing') {
          paper.innerHTML = `
            <div class="paperclip-graphic ${clipColor}"></div>
            <div class="dynamic-file-card type-missing" style="padding: 10px 5px 5px 5px;">
              <div class="missing-poster-inner" style="padding: 4px 5px; height: 100%;">
                <div class="ink-splatter ink-top-right" style="top: 6px; right: 4px; transform: scale(0.45);"></div>
                <div class="missing-poster-header" style="margin-bottom: 2px;">
                  <h2 class="missing-banner-title" style="font-size: 13px; margin: 0; letter-spacing: 2px;">MISSING</h2>
                  <div class="missing-stars-row" style="font-size: 7px; gap: 4px; margin: 1px 0;">
                    <span>✦</span><span>✦</span><span>✦</span><span>✦</span>
                  </div>
                </div>
                <div class="missing-box-outline" style="border-width: 1px; padding: 2px; margin-bottom: 2px;">
                  <div class="missing-photo-frame" style="height: 68px;">
                    <img src="${clue.image || '/static/images/missing_person_poster.jpg'}" alt="${escapeHtml(clue.title)}">
                  </div>
                  <div class="missing-name-strip" style="padding: 2px 3px; margin-top: 2px;">
                    <span class="missing-name-value" style="font-size: 7.5px;">${escapeHtml(clue.personName || clue.title)}</span>
                  </div>
                </div>
              </div>
            </div>
          `;
        } else if (fmt === 'document') {
          paper.innerHTML = `
            <div class="paperclip-graphic ${clipColor}"></div>
            <div class="dynamic-file-card type-document" style="padding: 10px 5px 5px 5px;">
              <div class="document-paper-inner" style="padding: 4px; height: 100%;">
                <div class="doc-box-outline" style="border-width: 1px; padding: 3px;">
                  <div class="doc-paper-header-row" style="margin-bottom: 2px;">
                    <span class="doc-header-seal" style="font-size: 5.5px;">MEMO</span>
                    <div class="doc-stars-row" style="font-size: 6px; gap: 3px;">
                      <span>✦</span><span>✦</span><span>✦</span>
                    </div>
                    <span class="doc-stamp-filed" style="font-size: 5.5px;">FILED</span>
                  </div>
                  <h3 class="doc-paper-title" style="font-size: 7.5px; margin-bottom: 2px;">${escapeHtml(clue.title)}</h3>
                  <div class="doc-paper-body-text" style="font-size: 6.5px; -webkit-line-clamp: 4;">
                    ${escapeHtml(clue.dossierText || clue.text || '')}
                  </div>
                </div>
              </div>
            </div>
          `;
        } else {
          paper.innerHTML = `
            <div class="paperclip-graphic ${clipColor}"></div>
            <div class="dynamic-file-card type-polaroid" style="padding: 10px 5px 5px 5px;">
              <div class="polaroid-inner-frame" style="padding: 3px; height: 100%;">
                <div class="polaroid-photo-box" style="height: 72px;">
                  <img src="${clue.image || '/static/images/creature_polaroid.png'}" alt="${escapeHtml(clue.title)}" class="paper-img">
                </div>
                <div class="polaroid-bottom-caption" style="padding: 2px 0 0 0;">
                  <span class="polaroid-title-text" style="font-size: 7.5px;">${escapeHtml(clue.title)}</span>
                  <span class="polaroid-date-tag" style="font-size: 5.5px;">1993.01.26</span>
                </div>
              </div>
            </div>
          `;
        }
        dynamicFolderContainer.appendChild(paper);
      });
    }

    const folderPapers = document.querySelectorAll('.folder-paper-item');

    folderPapers.forEach(paper => {
      const clueId = paper.dataset.id;
      const clue = (state.caseData.clues || []).find(c => c.id === clueId);
      
      // If clue was incinerated/deleted, hide it immediately
      if (!clue) {
        paper.style.display = 'none';
        return;
      }
      paper.style.display = '';

      // Placement check for embedded folder clues: is clue currently placed on board or in flap?
      if (FOLDER_CLUES.has(clue.id)) {
        if (clue.onBoard) {
          if (paper.parentElement !== roamingLayer && roamingLayer) {
            roamingLayer.appendChild(paper);
          }
          paper.classList.add('paper-on-board');
          paper.style.left = `${clue.x}px`;
          paper.style.top = `${clue.y}px`;
          paper.style.bottom = 'auto';
          paper.style.right = 'auto';
          paper.style.transform = `rotate(${clue.rotation || 0}deg)`;
        } else {
          paper.classList.remove('paper-on-board');
          const def = FOLDER_ITEM_DEFAULTS[clue.id] || { flap: 'flap-left' };
          const flap = dom.folderSpread ? dom.folderSpread.querySelector(`.${def.flap}`) : null;
          if (flap && paper.parentElement !== flap) {
            flap.appendChild(paper);
          }
          const defRot = def.rotation || 0;
          if (clue.flapX !== undefined && clue.flapX !== null && clue.flapY !== undefined && clue.flapY !== null) {
            paper.style.left = `${clue.flapX}px`;
            paper.style.top = `${clue.flapY}px`;
            paper.style.bottom = 'auto';
            paper.style.right = 'auto';
            paper.style.transform = defRot ? `rotate(${defRot}deg)` : '';
          } else {
            paper.style.left = '';
            paper.style.top = '';
            paper.style.bottom = '';
            paper.style.right = '';
            paper.style.transform = defRot ? `rotate(${defRot}deg)` : '';
          }
        }
      }

      // Avoid duplicate pointer listener bindings
      if (paper._hasFolderDragInit) return;
      paper._hasFolderDragInit = true;

      // Pointer down for click-to-inspect or dragging paper
      paper.onpointerdown = (e) => {
        // Exclude interactive clicks on child buttons/links or placed pins
        if (e.target.closest('button') || e.target.closest('a') || e.target.closest('.placed-evidence-pin')) return;

        // If pinned to stay put: allow click to inspect, but prevent dragging!
        if (paper.dataset.stayPut === 'true' || paper.classList.contains('pinned-stay-put') || paper.querySelector('.placed-evidence-pin')) {
          const startX = e.clientX;
          const startY = e.clientY;
          const onPinnedPaperUp = (upEv) => {
            window.removeEventListener('pointerup', onPinnedPaperUp);
            const dist = Math.hypot(upEv.clientX - startX, upEv.clientY - startY);
            if (dist < 6) {
              if (window.PaperAudio) window.PaperAudio.tap(1.0, 'card');
              openDossierModal(clue);
            } else {
              playPinTugFeedback(paper);
            }
          };
          window.addEventListener('pointerup', onPinnedPaperUp);
          return;
        }

        if (window.PaperAudio) window.PaperAudio.tap(0.85, 'card');

        const startClientX = e.clientX;
        const startClientY = e.clientY;
        let moved = false;

        const surfaceRect = getSurfaceRect();
        const paperRect = paper.getBoundingClientRect();
        const paperScreenOriginX = paperRect.left;
        const paperScreenOriginY = paperRect.top;
        const paperW = paperRect.width || 180;
        const paperH = paperRect.height || 220;
        const grabOffsetX = e.clientX - paperRect.left;
        const grabOffsetY = e.clientY - paperRect.top;
        const initialFlapLeft = paper.offsetLeft;
        const initialFlapTop = paper.offsetTop;
        const isInitiallyOnBoard = clue.onBoard === true;

        if (!isInitiallyOnBoard) {
          paper.style.bottom = 'auto';
          paper.style.right = 'auto';
          paper.style.left = `${initialFlapLeft}px`;
          paper.style.top = `${initialFlapTop}px`;
        }

        paper.classList.add('dragging', 'is-picked-up');
        paper.style.zIndex = '9999';
        paper.style.willChange = 'left, top, transform';
        if (dom.folderWrapper) dom.folderWrapper.style.zIndex = '999';
        if (dom.boardTrashBin) dom.boardTrashBin.classList.add('is-drag-active');

        try {
          paper.setPointerCapture(e.pointerId);
        } catch (_) {}

        let baseRot = 0;
        if (isInitiallyOnBoard) {
          baseRot = clue.rotation || 0;
        } else if (FOLDER_ITEM_DEFAULTS[clue.id] && FOLDER_ITEM_DEFAULTS[clue.id].rotation !== undefined) {
          baseRot = FOLDER_ITEM_DEFAULTS[clue.id].rotation;
        } else if (clue.rotation !== undefined) {
          baseRot = clue.rotation;
        } else {
          const match = paper.style.transform && paper.style.transform.match(/rotate\(([-0-9.]+)deg\)/);
          if (match) baseRot = parseFloat(match[1]) || 0;
        }

        const swing = (window.SwingPhysics) ? window.SwingPhysics.create({
          element: paper,
          baseRotation: baseRot,
          pivotX: '50%',
          pivotY: '24px',
          maxAngle: 15,
          sensitivity: 0.012,
          liftScale: 1.05
        }) : null;
        if (swing) swing.pickup(e.clientX, e.clientY);

        // Pre-cache collision targets at pointerdown to avoid synchronous forced reflows during drag
        const trashRect = dom.boardTrashBin ? dom.boardTrashBin.getBoundingClientRect() : null;
        const folderRect = dom.folderWrapper ? dom.folderWrapper.getBoundingClientRect() : null;

        let latestClientX = e.clientX;
        let latestClientY = e.clientY;
        let dragRaf = null;

        const onPointerMove = (ev) => {
          latestClientX = ev.clientX;
          latestClientY = ev.clientY;

          const dx = ev.clientX - startClientX;
          const dy = ev.clientY - startClientY;
          if (Math.hypot(dx, dy) > 5) {
            moved = true;
          }

          if (swing) swing.move(ev.clientX, ev.clientY);
          if (window.PaperAudio) {
            window.PaperAudio.handleDragMotion(ev.movementX || 5, ev.movementY || 5);
          }

          // Check trash collision using pure math without layout thrashing
          const curCardRect = {
            left: paperScreenOriginX + dx,
            top: paperScreenOriginY + dy,
            right: paperScreenOriginX + dx + paperW,
            bottom: paperScreenOriginY + dy + paperH,
            width: paperW,
            height: paperH
          };
          const isOverTrash = checkTrashCollision(ev.clientX, ev.clientY, curCardRect, trashRect);
          if (dom.boardTrashBin) {
            dom.boardTrashBin.classList.toggle('drag-over', isOverTrash);
          }
          paper.classList.toggle('over-trash', isOverTrash);

          // Check folder collision for re-docking
          const isOverFolder = folderRect && (
            ev.clientX >= folderRect.left &&
            ev.clientX <= folderRect.right &&
            ev.clientY >= folderRect.top &&
            ev.clientY <= folderRect.bottom
          );

          if (dom.folderWrapper) {
            dom.folderWrapper.classList.toggle('folder-dock-hover', isOverFolder && isInitiallyOnBoard && !isOverTrash);
          }

          // Visual motion update in 60/120fps display refresh frame
          if (!dragRaf) {
            dragRaf = requestAnimationFrame(() => {
              const curX = latestClientX;
              const curY = latestClientY;

              if (isInitiallyOnBoard) {
                const curBoardX = curX - surfaceRect.left - grabOffsetX;
                const curBoardY = curY - surfaceRect.top - grabOffsetY;
                paper.style.left = `${Math.round(curBoardX)}px`;
                paper.style.top = `${Math.round(curBoardY)}px`;
              } else {
                const curDx = curX - startClientX;
                const curDy = curY - startClientY;
                const newLeft = initialFlapLeft + curDx;
                const newTop = initialFlapTop + curDy;
                paper.style.left = `${Math.round(newLeft)}px`;
                paper.style.top = `${Math.round(newTop)}px`;
              }
              dragRaf = null;
            });
          }
        };

        const onPointerUp = async (ev) => {
          if (dragRaf) {
            cancelAnimationFrame(dragRaf);
            dragRaf = null;
          }
          try {
            paper.releasePointerCapture(ev.pointerId);
          } catch (_) {}

          window.removeEventListener('pointermove', onPointerMove);
          window.removeEventListener('pointerup', onPointerUp);
          window.removeEventListener('pointercancel', onPointerUp);

          paper.classList.remove('dragging');
          paper.style.zIndex = '';
          paper.style.willChange = '';
          if (dom.folderWrapper) {
            dom.folderWrapper.style.zIndex = '';
            dom.folderWrapper.classList.remove('folder-dock-hover');
          }
          if (dom.boardTrashBin) {
            dom.boardTrashBin.classList.remove('is-drag-active', 'drag-over');
          }

          // 1. If clicked without dragging -> Open Dossier
          if (!moved) {
            if (swing) swing.cancel();
            paper.classList.remove('is-picked-up');
            if (window.PaperAudio) window.PaperAudio.tap(1.0, 'card');
            openDossierModal(clue);
            return;
          }

          const dx = ev.clientX - startClientX;
          const dy = ev.clientY - startClientY;
          const curCardRect = {
            left: paperScreenOriginX + dx,
            top: paperScreenOriginY + dy,
            right: paperScreenOriginX + dx + paperW,
            bottom: paperScreenOriginY + dy + paperH,
            width: paperW,
            height: paperH
          };
          const isOverTrash = checkTrashCollision(ev.clientX, ev.clientY, curCardRect, trashRect);

          // 2. Trash disposal check
          if (isOverTrash) {
            if (swing) swing.cancel();
            paper.classList.remove('over-trash', 'is-picked-up');
            await incinerateClue(clue, paper);
            return;
          }

          paper.classList.remove('over-trash');

          const isOverFolder = folderRect && (
            ev.clientX >= folderRect.left &&
            ev.clientX <= folderRect.right &&
            ev.clientY >= folderRect.top &&
            ev.clientY <= folderRect.bottom
          );

          // 3. Drop Routing
          if (isInitiallyOnBoard) {
            if (isOverFolder) {
              if (swing) swing.cancel();
              paper.classList.remove('is-picked-up');
              // Dock back into folder!
              dockPaperIntoFolder(clue, paper);
            } else {
              // Freely move on board without snapping back
              const finalBoardX = ev.clientX - surfaceRect.left - grabOffsetX;
              const finalBoardY = ev.clientY - surfaceRect.top - grabOffsetY;
              const clampedX = Math.max(10, Math.min(surfaceRect.width - (paper.offsetWidth || 200) - 10, Math.round(finalBoardX)));
              const clampedY = Math.max(10, Math.min(surfaceRect.height - (paper.offsetHeight || 220) - 10, Math.round(finalBoardY)));
              clue.x = clampedX;
              clue.y = clampedY;
              paper.style.left = `${clue.x}px`;
              paper.style.top = `${clue.y}px`;
              saveCluePosition(clue);
              if (window.PaperAudio) window.PaperAudio.drop({ type: 'card' });
              else playPaperThud();
              if (swing) swing.drop();
              else paper.classList.remove('is-picked-up');
            }
          } else {
            // Started inside folder flap
            if (isOverFolder && state.isFolderOpen) {
              // Roam freely inside folder flap without snapping back
              keepPaperInFlap(clue, paper, dx, dy, initialFlapLeft, initialFlapTop);
              if (swing) swing.drop();
              else {
                paper.classList.remove('is-picked-up');
                paper.style.transform = baseRot ? `rotate(${baseRot}deg)` : '';
              }
            } else {
              // Dragged outside folder -> Deploy onto board!
              if (swing) swing.cancel();
              paper.classList.remove('is-picked-up');
              const dropBoardX = ev.clientX - surfaceRect.left - grabOffsetX;
              const dropBoardY = ev.clientY - surfaceRect.top - grabOffsetY;
              movePaperToBoard(clue, paper, dropBoardX, dropBoardY);
            }
          }
        };

        window.addEventListener('pointermove', onPointerMove);
        window.addEventListener('pointerup', onPointerUp);
        window.addEventListener('pointercancel', onPointerUp);
      };

      // 3D Parallax Hover for in-flap papers
      let cachedPaperRect = null;
      paper.addEventListener('pointerenter', () => {
        if (!clue.onBoard && !paper.classList.contains('dragging') && !paper.classList.contains('is-picked-up')) {
          cachedPaperRect = paper.getBoundingClientRect();
        }
      });

      paper.addEventListener('pointermove', (ev) => {
        if (clue.onBoard || paper.classList.contains('dragging') || paper.classList.contains('is-picked-up') || !cachedPaperRect) return;
        const px = (ev.clientX - cachedPaperRect.left) / cachedPaperRect.width - 0.5;
        const py = (ev.clientY - cachedPaperRect.top) / cachedPaperRect.height - 0.5;
        paper.style.transform = `perspective(600px) rotateY(${px * 10}deg) rotateX(${-py * 10}deg) translateY(-5px) scale(1.025)`;
      });

      paper.addEventListener('pointerleave', () => {
        cachedPaperRect = null;
        if (!paper.classList.contains('dragging') && !paper.classList.contains('is-picked-up')) {
          const baseRot = (FOLDER_ITEM_DEFAULTS[clue.id]?.rotation) ?? (clue.rotation || 0);
          paper.style.transform = clue.onBoard ? `rotate(${clue.rotation || 0}deg)` : (baseRot ? `rotate(${baseRot}deg)` : '');
        }
      });
    });

    updateClosedEvidenceCount();
  }

  // --- Interactive Case File Folder Open / Close (Minimize & Maximize) & Dragging ---
  function setupFolderToggle() {
    // Initial state: starts minimized
    closeFolder();

    // Initial position from caseData or screen center
    if (dom.folderWrapper) {
      const sRect = getSurfaceRect();
      const defaultCenterX = Math.round(sRect.width / 2);
      const defaultCenterY = Math.round(sRect.height / 2);
      const folderPos = state.caseData && state.caseData.folder;
      const initialX = (folderPos && folderPos.x !== undefined) ? folderPos.x : defaultCenterX;
      const initialY = (folderPos && folderPos.y !== undefined) ? folderPos.y : defaultCenterY;
      dom.folderWrapper.style.left = `${initialX}px`;
      dom.folderWrapper.style.top = `${initialY}px`;
      if (!state.caseData.folder) state.caseData.folder = {};
      state.caseData.folder.x = initialX;
      state.caseData.folder.y = initialY;
    }

    // Initialize dragging and moveability
    setupFolderDrag();

    // Closed folder pin for string tool
    const folderPin = document.getElementById('folder-main-pin');
    if (folderPin) {
      folderPin.onclick = (e) => {
        e.stopPropagation();
        const folderClue = { id: 'clue-case-folder', title: 'Manila Case File' };
        handlePinClick(folderClue, folderPin);
      };
    }

    // Click on top minimize button inside open spread to close / minimize
    if (dom.btnMinimizeFolder) {
      dom.btnMinimizeFolder.addEventListener('click', (e) => {
        e.stopPropagation();
        closeFolder();
      });
    }

    // Click on tab toggle button
    if (dom.btnToggleFolder) {
      dom.btnToggleFolder.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleFolder();
      });
    }

    // Click on tab badge
    if (dom.folderTabBadge) {
      dom.folderTabBadge.addEventListener('click', (e) => {
        if (e.target.closest('#btn-toggle-folder')) return;
        e.stopPropagation();
        toggleFolder();
      });
    }

    // Click on HUD folder button
    if (dom.btnHudFolderToggle) {
      dom.btnHudFolderToggle.addEventListener('click', () => {
        toggleFolder();
      });
    }
  }

  function setupFolderDrag() {
    if (!dom.folderWrapper) return;

    let startX = 0;
    let startY = 0;
    let hasMoved = false;
    let currentCenterX = 600;
    let currentCenterY = 375;
    let grabOffsetX = 0;
    let grabOffsetY = 0;
    let isCapturing = false;

    let folderSwing = (window.SwingPhysics) ? window.SwingPhysics.create({
      element: dom.folderWrapper,
      baseRotation: 0,
      pivotX: '50%',
      pivotY: '30px',
      maxAngle: 9,
      sensitivity: 0.007,
      liftScale: 1.03,
      getTransformPrefix: () => 'translate(-50%, -50%)'
    }) : null;

    dom.folderWrapper.addEventListener('pointerdown', (e) => {
      // 1. Exclude red yarn pins
      if (e.target.closest('.clue-pin')) return;

      // 2. Exclude action buttons
      if (e.target.closest('.folder-action-btn') || e.target.closest('button')) return;

      // 3. String tool active check on closed folder
      if (state.isStringToolActive && !state.isFolderOpen) {
        const folderPin = document.getElementById('folder-main-pin');
        if (folderPin) {
          handlePinClick({ id: 'clue-case-folder', title: 'Manila Case File' }, folderPin);
        }
        return;
      }

      // 4. In open folder state: only allow dragging from drag handle, top actions bar, or flap margins
      if (state.isFolderOpen) {
        if (e.target.closest('.folder-paper-item')) return;
        const isHandle = e.target.closest('.folder-drag-handle');
        const isTopActions = e.target.closest('.folder-top-actions');
        const isFlapBg = e.target.classList.contains('folder-flap') || 
                         e.target.classList.contains('flap-texture') || 
                         e.target.classList.contains('folder-spread') ||
                         e.target.classList.contains('folder-clip-top');
        if (!isHandle && !isTopActions && !isFlapBg) return;
      }

      startX = e.clientX;
      startY = e.clientY;
      hasMoved = false;

      if (folderSwing) folderSwing.pickup(e.clientX, e.clientY);

      const surfaceRect = getSurfaceRect();
      const rect = dom.folderWrapper.getBoundingClientRect();

      currentCenterX = (rect.left - surfaceRect.left) + rect.width / 2;
      currentCenterY = (rect.top - surfaceRect.top) + rect.height / 2;

      const pointerSurfaceX = e.clientX - surfaceRect.left;
      const pointerSurfaceY = e.clientY - surfaceRect.top;

      grabOffsetX = pointerSurfaceX - currentCenterX;
      grabOffsetY = pointerSurfaceY - currentCenterY;

      try {
        dom.folderWrapper.setPointerCapture(e.pointerId);
        isCapturing = true;
      } catch (_) {
        isCapturing = false;
      }

      // Pre-cache pin offsets relative to folder center at start of drag
      const folderPinOffsets = new Map();
      const fPins = dom.folderWrapper.querySelectorAll('.clue-pin');
      fPins.forEach(p => {
        const pId = p.dataset.clueId;
        if (pId) {
          const pinCoord = getPinCoordinates(pId);
          folderPinOffsets.set(pId, {
            ox: pinCoord.x - currentCenterX,
            oy: pinCoord.y - currentCenterY
          });
        }
      });
      const mainPinCoord = getPinCoordinates('clue-case-folder');
      folderPinOffsets.set('clue-case-folder', {
        ox: mainPinCoord.x - currentCenterX,
        oy: mainPinCoord.y - currentCenterY
      });
      let folderDragRaf = null;

      const onPointerMove = (ev) => {
        const dist = Math.hypot(ev.clientX - startX, ev.clientY - startY);
        if (dist > 5) {
          if (!hasMoved) {
            hasMoved = true;
            dom.folderWrapper.classList.add('dragging');
          }

          if (folderSwing) folderSwing.move(ev.clientX, ev.clientY);

          const sRect = getSurfaceRect();
          const boardW = sRect.width;
          const boardH = sRect.height;

          const currentPointerX = ev.clientX - sRect.left;
          const currentPointerY = ev.clientY - sRect.top;

          let newCenterX = currentPointerX - grabOffsetX;
          let newCenterY = currentPointerY - grabOffsetY;

          const halfW = (dom.folderWrapper.offsetWidth || 480) / 2;
          const halfH = (dom.folderWrapper.offsetHeight || 330) / 2;

          const minX = halfW + 10;
          const maxX = Math.max(minX, boardW - halfW - 10);
          const minY = halfH + 10;
          const maxY = Math.max(minY, boardH - halfH - 10);

          newCenterX = Math.max(minX, Math.min(maxX, newCenterX));
          newCenterY = Math.max(minY, Math.min(maxY, newCenterY));

          const roundedCenterX = Math.round(newCenterX);
          const roundedCenterY = Math.round(newCenterY);

          if (!state.caseData.folder) state.caseData.folder = {};
          state.caseData.folder.x = roundedCenterX;
          state.caseData.folder.y = roundedCenterY;

          // Directly update cached coordinates for all folder pins without querying DOM
          folderPinOffsets.forEach((offset, pId) => {
            pinCoordsCache.set(pId, {
              x: roundedCenterX + offset.ox,
              y: roundedCenterY + offset.oy
            });
          });

          if (window.PaperAudio) {
            window.PaperAudio.handleDragMotion(ev.movementX || 6, ev.movementY || 6);
          }

          if (!folderDragRaf) {
            folderDragRaf = requestAnimationFrame(() => {
              dom.folderWrapper.style.left = `${roundedCenterX}px`;
              dom.folderWrapper.style.top = `${roundedCenterY}px`;
              renderStrings();
              folderDragRaf = null;
            });
          }
        }
      };

      const onPointerUp = (ev) => {
        if (folderDragRaf) {
          cancelAnimationFrame(folderDragRaf);
          folderDragRaf = null;
        }
        if (isCapturing) {
          try {
            dom.folderWrapper.releasePointerCapture(ev.pointerId);
          } catch (_) {}
          isCapturing = false;
        }
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
        window.removeEventListener('pointercancel', onPointerUp);

        dom.folderWrapper.classList.remove('dragging');
        if (folderSwing) folderSwing.drop();

        if (state.caseData.folder) {
          dom.folderWrapper.style.left = `${state.caseData.folder.x}px`;
          dom.folderWrapper.style.top = `${state.caseData.folder.y}px`;
        }

        if (!hasMoved) {
          // Clicked without dragging: if closed cover was clicked, open the folder!
          if (!state.isFolderOpen && dom.folderClosedCover && (dom.folderClosedCover === e.target || dom.folderClosedCover.contains(e.target))) {
            openFolder();
          }
        } else {
          // Drag finished: play paper sound, re-render strings and persist position
          if (window.PaperAudio) {
            window.PaperAudio.drop({ type: 'folder' });
          } else {
            playPaperThud();
          }
          invalidatePinCache();
          requestRenderStrings();
          if (state.caseData.folder) {
            saveFolderPosition(state.caseData.folder.x, state.caseData.folder.y);
          }
        }
      };

      window.addEventListener('pointermove', onPointerMove);
      window.addEventListener('pointerup', onPointerUp);
      window.addEventListener('pointercancel', onPointerUp);
    });
  }

  async function saveFolderPosition(x, y) {
    try {
      await fetch('/api/folder/position', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ x, y })
      });
    } catch (e) {
      console.warn('Failed to save folder position:', e);
    }
  }

  function toggleFolder(forceState) {
    const shouldOpen = forceState !== undefined ? forceState : !state.isFolderOpen;
    if (shouldOpen) {
      openFolder();
    } else {
      closeFolder();
    }
  }

  function openFolder() {
    state.isFolderOpen = true;

    if (dom.folderWrapper) {
      dom.folderWrapper.classList.remove('is-minimized');
      dom.folderWrapper.classList.add('is-open');
    }

    if (dom.hudFolderLabel) {
      dom.hudFolderLabel.textContent = 'Minimize File';
    }
    if (dom.hudFolderIcon) {
      dom.hudFolderIcon.setAttribute('data-lucide', 'folder-minus');
    }
    if (dom.folderToggleIcon) {
      dom.folderToggleIcon.setAttribute('data-lucide', 'folder-minus');
    }

    try {
      if (window.PaperAudio) {
        if (typeof window.PaperAudio.uncrumple === 'function') {
          window.PaperAudio.uncrumple();
        } else {
          window.PaperAudio.folderFlap('open');
        }
      } else {
        playPaperThud();
      }
    } catch (_) {}

    setupLucideIcons();
    updateClosedEvidenceCount();

    // Recompute pins and strings smoothly after unfolding
    invalidatePinCache();
    setTimeout(() => {
      invalidatePinCache();
      requestRenderStrings();
    }, 120);
    setTimeout(() => {
      invalidatePinCache();
      requestRenderStrings();
    }, 380);
  }

  function closeFolder() {
    state.isFolderOpen = false;

    if (dom.folderWrapper) {
      dom.folderWrapper.classList.remove('is-open');
      dom.folderWrapper.classList.add('is-minimized');
    }

    if (dom.hudFolderLabel) {
      dom.hudFolderLabel.textContent = 'Open Case File';
    }
    if (dom.hudFolderIcon) {
      dom.hudFolderIcon.setAttribute('data-lucide', 'folder');
    }
    if (dom.folderToggleIcon) {
      dom.folderToggleIcon.setAttribute('data-lucide', 'folder-plus');
    }

    try {
      if (window.PaperAudio) {
        window.PaperAudio.folderFlap('close');
      } else {
        playPaperThud();
      }
    } catch (_) {}

    setupLucideIcons();
    updateClosedEvidenceCount();

    invalidatePinCache();
    setTimeout(() => {
      invalidatePinCache();
      requestRenderStrings();
    }, 100);
  }


  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function getClueFormat(clue) {
    if (!clue) return 'polaroid';
    if (clue.format) return clue.format;
    if (clue.category === 'Missing Paper' || (clue.title && clue.title.toLowerCase().includes('missing'))) {
      return 'missing';
    }
    if (clue.category === 'Document' || (clue.tag && (clue.tag.toLowerCase().includes('report') || clue.tag.toLowerCase().includes('log') || clue.tag.toLowerCase().includes('affidavit')))) {
      return 'document';
    }
    return 'polaroid';
  }

  function renderExtraClues() {
    if (!dom.extraCluesLayer) return;
    dom.extraCluesLayer.innerHTML = '';
    const embeddedIds = new Set([
      'clue-polaroid', 'clue-sightings-log', 'clue-bureau-card',
      'clue-warding', 'clue-red-dossier', 'clue-report-cebu', 'clue-visayas-map'
    ]);

    const extraClues = (state.caseData.clues || []).filter(c => !embeddedIds.has(c.id) && !c.id.startsWith('clue-oc-id') && !isClueInFolder(c));

    extraClues.forEach(clue => {
      const format = getClueFormat(clue);
      const card = document.createElement('div');
      card.className = `clue-card type-${format}`;
      card.dataset.id = clue.id;
      card.dataset.category = clue.category || (format === 'missing' ? 'Missing Paper' : (format === 'document' ? 'Document' : 'Photograph'));
      card.dataset.format = format;

      let defaultWidth = 195;
      let defaultHeight = 235;
      if (format === 'missing') {
        defaultWidth = 205;
        defaultHeight = 305;
      } else if (format === 'document') {
        defaultWidth = 215;
        defaultHeight = 275;
      }

      const cardW = clue.width || defaultWidth;
      const cardH = clue.height || defaultHeight;

      card.style.left = `${clue.x || 100}px`;
      card.style.top = `${clue.y || 100}px`;
      card.style.width = `${cardW}px`;
      card.style.height = `${cardH}px`;
      card.style.transform = `rotate(${clue.rotation || 0}deg)`;

      const pin = document.createElement('div');
      pin.className = 'clue-pin';
      pin.dataset.clueId = clue.id;
      pin.style.left = `${clue.pinX || cardW / 2}px`;
      pin.style.top = `${clue.pinY || 14}px`;
      pin.title = `Pin: ${clue.title}`;

      if (format === 'missing') {
        // --- 1. MISSING PAPER FORMAT (Exact Reference Photo Theme) ---
        const inner = document.createElement('div');
        inner.className = 'missing-poster-inner';
        inner.innerHTML = `
          <div class="ink-splatter ink-top-right"></div>
          <div class="ink-splatter ink-mid-left"></div>
          <div class="ink-splatter ink-bottom-right"></div>
          <div class="missing-poster-header">
            <h2 class="missing-banner-title">MISSING</h2>
            <div class="missing-stars-row" aria-hidden="true">
              <span>✦</span>
              <span>✦</span>
              <span>✦</span>
              <span>✦</span>
            </div>
          </div>
          <div class="missing-box-outline">
            <div class="missing-photo-frame">
              <img src="${clue.image || '/static/images/missing_person_poster.jpg'}" alt="Missing Person: ${escapeHtml(clue.personName || clue.title)}">
            </div>
            <div class="missing-name-strip">
              <span class="missing-name-label">NAME OF MISSING PERSON:</span>
              <span class="missing-name-value">${escapeHtml(clue.personName || clue.title || 'UNKNOWN SUBJECT')}</span>
            </div>
          </div>
          <div class="missing-details-snippet">
            ${escapeHtml(clue.dossierText || clue.text || 'Subject last seen August 12, 1973 in Pasadena vicinity.')}
          </div>
          <div class="missing-footer-strip">
            <span>POLICE ARCHIVE</span>
            <span>NOTIFY IMMEDIATELY</span>
          </div>
        `;
        card.appendChild(pin);
        card.appendChild(inner);
      } else if (format === 'document') {
        // --- 2. ONLY A PAPER WITH CUSTOMIZABLE TEXT ---
        const inner = document.createElement('div');
        inner.className = 'document-paper-inner';
        inner.innerHTML = `
          <div class="ink-splatter ink-top-right" style="opacity: 0.6; transform: scale(0.75);"></div>
          <div class="ink-splatter ink-bottom-right" style="opacity: 0.6; transform: scale(0.75);"></div>
          <div class="doc-box-outline">
            <div class="doc-paper-header-row">
              <span class="doc-header-seal">OFFICIAL DISPATCH // DIV VII</span>
              <div class="doc-stars-row" aria-hidden="true">
                <span>✦</span>
                <span>✦</span>
                <span>✦</span>
              </div>
              <span class="doc-stamp-filed">FILED</span>
            </div>
            <h3 class="doc-paper-title">${escapeHtml(clue.title || 'INCIDENT REPORT')}</h3>
            <div class="doc-paper-body-text">
              ${escapeHtml(clue.dossierText || clue.text || 'Official sworn statement filed for archival preservation.')}
            </div>
            <div class="doc-paper-footer-row">
              <span>${escapeHtml(clue.cipher || 'REF: ARCHIVE RECORD')}</span>
              <span class="doc-signature">Agent Maza ✍</span>
            </div>
          </div>
        `;
        card.appendChild(pin);
        card.appendChild(inner);
      } else {
        // --- 3. POLAROID WITH TEXT (The Classic One) ---
        const inner = document.createElement('div');
        inner.className = 'polaroid-inner-frame';
        inner.innerHTML = `
          <div class="polaroid-photo-box">
            <img src="${clue.image || '/static/images/creature_polaroid.png'}" alt="${escapeHtml(clue.title)}">
          </div>
          <div class="polaroid-bottom-caption">
            <span class="polaroid-title-text">${escapeHtml(clue.title || 'Surveillance Polaroid')}</span>
            <span class="polaroid-date-tag">${escapeHtml(clue.date || '1993.01.26 // 02:32 AM')}</span>
          </div>
        `;
        card.appendChild(pin);
        card.appendChild(inner);
      }

      setupCardInteractions(card, clue);
      dom.extraCluesLayer.appendChild(card);
    });
  }

  let renderStringsRafId = null;
  function requestRenderStrings() {
    if (renderStringsRafId) return;
    renderStringsRafId = requestAnimationFrame(() => {
      renderStringsRafId = null;
      renderStrings();
    });
  }

  let activeDrawLineEl = null;
  function updateActiveDrawLine() {
    if (state.selectedPin && state.activeMousePos) {
      if (!activeDrawLineEl) {
        activeDrawLineEl = document.createElementNS('http://www.w3.org/2000/svg', 'line');
        activeDrawLineEl.setAttribute('class', 'red-yarn-line active-draw-line');
        activeDrawLineEl.id = 'active-draw-line';
        dom.stringsSvg.appendChild(activeDrawLineEl);
      }
      activeDrawLineEl.setAttribute('x1', state.selectedPin.x);
      activeDrawLineEl.setAttribute('y1', state.selectedPin.y);
      activeDrawLineEl.setAttribute('x2', state.activeMousePos.x);
      activeDrawLineEl.setAttribute('y2', state.activeMousePos.y);
      activeDrawLineEl.style.display = '';
    } else if (activeDrawLineEl) {
      activeDrawLineEl.style.display = 'none';
    }
  }

  function renderStrings() {
    if (!state.caseData || !dom.stringsSvg) return;
    if (!cachedSurfaceRect && dom.surface) {
      cachedSurfaceRect = dom.surface.getBoundingClientRect();
    }

    const cluesMap = new Map();
    (state.caseData.clues || []).forEach(c => cluesMap.set(c.id, c));

    // Exclude any connections connected to/from files in the folder
    const rawConnections = state.caseData.connections || [];
    const connections = rawConnections.filter(c => {
      const fromClue = cluesMap.get(c.from);
      const toClue = cluesMap.get(c.to);
      if (!fromClue || !toClue) return false;
      return !isClueInFolder(fromClue) && !isClueInFolder(toClue) && c.from !== 'clue-case-folder' && c.to !== 'clue-case-folder';
    });
    const existingPaths = dom.stringsSvg.querySelectorAll('path.red-yarn-line');

    if (existingPaths.length !== connections.length) {
      dom.stringsSvg.innerHTML = '';
      activeDrawLineEl = null;

      connections.forEach((conn, index) => {
        const fromClue = cluesMap.get(conn.from);
        const toClue = cluesMap.get(conn.to);
        if (!fromClue || !toClue) return;

        const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        path.setAttribute('class', 'red-yarn-line');
        path.dataset.from = conn.from;
        path.dataset.to = conn.to;
        path.dataset.index = index;

        // If folder is minimized, hide internal connections between folder papers
        if (!state.isFolderOpen && FOLDER_CLUES.has(conn.from) && FOLDER_CLUES.has(conn.to)) {
          path.style.display = 'none';
        } else {
          path.style.display = '';
        }

        const p1 = getPinCoordinates(fromClue);
        const p2 = getPinCoordinates(toClue);

        const dx = p2.x - p1.x;
        const dy = p2.y - p1.y;
        const dist = Math.hypot(dx, dy);
        const sag = Math.min(32, Math.max(12, dist * 0.045));
        const mx = (p1.x + p2.x) / 2;
        const my = (p1.y + p2.y) / 2 + sag;

        path.setAttribute('d', `M ${p1.x.toFixed(1)} ${p1.y.toFixed(1)} Q ${mx.toFixed(1)} ${my.toFixed(1)} ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`);

        path.addEventListener('click', (e) => {
          e.stopPropagation();
          handleStringClick(conn);
        });

        const title = document.createElementNS('http://www.w3.org/2000/svg', 'title');
        title.textContent = `Thread: ${fromClue.title} ↔ ${toClue.title} (${conn.label || 'Connected'}) - Click to sever`;
        path.appendChild(title);

        path.addEventListener('pointerenter', () => {
          const freqs = [220, 261, 329, 392, 440, 523];
          const f = freqs[index % freqs.length];
          playStringPluckSound(f);
          path.classList.add('string-vibrating');
          setTimeout(() => path.classList.remove('string-vibrating'), 280);
        });

        dom.stringsSvg.appendChild(path);
      });
    } else {
      connections.forEach((conn, index) => {
        const path = existingPaths[index];
        if (!path) return;
        const fromClue = cluesMap.get(conn.from);
        const toClue = cluesMap.get(conn.to);
        if (!fromClue || !toClue) return;

        // If folder is minimized, hide internal connections between folder papers
        if (!state.isFolderOpen && FOLDER_CLUES.has(conn.from) && FOLDER_CLUES.has(conn.to)) {
          path.style.display = 'none';
          return;
        } else {
          path.style.display = '';
        }

        const p1 = getPinCoordinates(fromClue);
        const p2 = getPinCoordinates(toClue);

        const dx = p2.x - p1.x;
        const dy = p2.y - p1.y;
        const dist = Math.hypot(dx, dy);
        const sag = Math.min(32, Math.max(12, dist * 0.045));
        const mx = (p1.x + p2.x) / 2;
        const my = (p1.y + p2.y) / 2 + sag;

        path.setAttribute('d', `M ${p1.x.toFixed(1)} ${p1.y.toFixed(1)} Q ${mx.toFixed(1)} ${my.toFixed(1)} ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`);
      });
    }

    updateActiveDrawLine();
  }

  // --- Card Pointer Dragging & Selection Handling ---
  function setupCardInteractions(card, clue) {
    const pin = card.querySelector('.clue-pin');

    const pinX = clue.pinX || ((clue.width || 200) / 2);
    const pinY = clue.pinY || 20;

    const swing = (window.SwingPhysics) ? window.SwingPhysics.create({
      element: card,
      baseRotation: clue.rotation || 0,
      pivotX: `${pinX}px`,
      pivotY: `${pinY}px`,
      maxAngle: 17,
      sensitivity: 0.013,
      liftScale: 1.05
    }) : null;
    card._swingPhysics = swing;

    // Pin click: for tying red string
    pin.addEventListener('click', (e) => {
      e.stopPropagation();
      handlePinClick(clue, pin);
    });

    let cardDragRaf = null;
    let pinRelX = pinX;
    let pinRelY = pinY;

    // Pointer down on card for dragging or inspect click
    card.addEventListener('pointerdown', (e) => {
      if (e.target === pin || e.target.closest('.clue-pin') || e.target.closest('.placed-evidence-pin')) return;

      // If pinned to stay put: allow click to inspect, but prevent dragging!
      if (card.dataset.stayPut === 'true' || card.classList.contains('pinned-stay-put') || card.querySelector('.placed-evidence-pin')) {
        const startX = e.clientX;
        const startY = e.clientY;
        const onPinnedCardUp = (upEv) => {
          window.removeEventListener('pointerup', onPinnedCardUp);
          const dist = Math.hypot(upEv.clientX - startX, upEv.clientY - startY);
          if (dist < 6) {
            if (window.PaperAudio) window.PaperAudio.tap(1.0, 'card');
            openDossierModal(clue);
          } else {
            playPinTugFeedback(card);
          }
        };
        window.addEventListener('pointerup', onPinnedCardUp);
        return;
      }

      if (state.isStringToolActive) {
        handlePinClick(clue, pin);
        return;
      }

      if (window.PaperAudio) window.PaperAudio.tap(0.85, 'card');
      if (swing) swing.pickup(e.clientX, e.clientY);

      state.draggingClue = clue;
      state.hasMovedDuringDrag = false;
      const rect = card.getBoundingClientRect();
      const surfaceRect = getSurfaceRect();

      state.dragOffset = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      };

      // Measure pin relative offset once at drag start
      const curPin = getPinCoordinates(clue, true);
      const cardOriginX = clue.x !== undefined ? clue.x : (rect.left - surfaceRect.left);
      const cardOriginY = clue.y !== undefined ? clue.y : (rect.top - surfaceRect.top);
      pinRelX = curPin.x - cardOriginX;
      pinRelY = curPin.y - cardOriginY;

      card.classList.add('dragging');
      if (dom.boardTrashBin) {
        dom.boardTrashBin.classList.add('is-drag-active');
      }
      card.setPointerCapture(e.pointerId);
    });

    card.addEventListener('pointermove', (e) => {
      if (state.draggingClue !== clue) return;
      state.hasMovedDuringDrag = true;

      if (swing) swing.move(e.clientX, e.clientY);

      if (window.PaperAudio) {
        window.PaperAudio.handleDragMotion(e.movementX || 6, e.movementY || 6);
      }

      // Check collision with bottom-right disposal incinerator
      const isOverTrash = checkTrashCollision(e.clientX, e.clientY, card.getBoundingClientRect());
      if (dom.boardTrashBin) {
        dom.boardTrashBin.classList.toggle('drag-over', isOverTrash);
      }
      card.classList.toggle('over-trash', isOverTrash);

      // Check collision with Case Folder for filing
      const folderRect = dom.folderWrapper ? dom.folderWrapper.getBoundingClientRect() : null;
      const isOverFolder = folderRect && (
        e.clientX >= folderRect.left &&
        e.clientX <= folderRect.right &&
        e.clientY >= folderRect.top &&
        e.clientY <= folderRect.bottom
      );
      if (dom.folderWrapper) {
        dom.folderWrapper.classList.toggle('folder-dock-hover', isOverFolder && !isOverTrash);
      }

      const sRect = getSurfaceRect();
      const boardW = sRect.width;
      const boardH = sRect.height;

      let newX = e.clientX - sRect.left - state.dragOffset.x;
      let newY = e.clientY - sRect.top - state.dragOffset.y;

      const cardW = clue.width || card.offsetWidth || 220;
      const cardH = clue.height || card.offsetHeight || 180;

      // Constrain dynamically to board viewport width and height
      newX = Math.max(10, Math.min(boardW - cardW - 10, newX));
      newY = Math.max(10, Math.min(boardH - cardH - 10, newY));

      const roundedX = Math.round(newX);
      const roundedY = Math.round(newY);

      clue.x = roundedX;
      clue.y = roundedY;

      // Update pin coordinates directly in cache without any DOM layout queries
      pinCoordsCache.set(clue.id, {
        x: roundedX + pinRelX,
        y: roundedY + pinRelY
      });

      // Synchronize DOM style update and string rendering with display refresh rate
      if (!cardDragRaf) {
        cardDragRaf = requestAnimationFrame(() => {
          card.style.left = `${roundedX}px`;
          card.style.top = `${roundedY}px`;
          renderStrings();
          cardDragRaf = null;
        });
      }
    });

    card.addEventListener('pointerup', async (e) => {
      if (state.draggingClue !== clue) return;
      if (cardDragRaf) {
        cancelAnimationFrame(cardDragRaf);
        cardDragRaf = null;
      }
      card.style.left = `${clue.x}px`;
      card.style.top = `${clue.y}px`;

      card.classList.remove('dragging', 'over-trash');
      state.draggingClue = null;
      if (dom.folderWrapper) {
        dom.folderWrapper.classList.remove('folder-dock-hover');
      }
      if (dom.boardTrashBin) {
        dom.boardTrashBin.classList.remove('is-drag-active', 'drag-over');
      }
      if (swing) swing.drop();

      if (!state.hasMovedDuringDrag) {
        // It was a click! Open Dossier Modal
        if (window.PaperAudio) window.PaperAudio.tap(1.0, 'card');
        openDossierModal(clue);
      } else {
        // 1. Check if dropped into the Trash Bin!
        const isOverTrash = checkTrashCollision(e.clientX, e.clientY, card.getBoundingClientRect());
        if (isOverTrash) {
          await incinerateClue(clue, card);
          return;
        }

        // 2. Check if dropped onto the Case Folder / Files!
        const folderRect = dom.folderWrapper ? dom.folderWrapper.getBoundingClientRect() : null;
        const isOverFolder = folderRect && (
          e.clientX >= folderRect.left &&
          e.clientX <= folderRect.right &&
          e.clientY >= folderRect.top &&
          e.clientY <= folderRect.bottom
        );
        if (isOverFolder) {
          putClueIntoFolder(clue, card);
          return;
        }

        // 3. Normal board move: sync coordinates to backend
        if (window.PaperAudio) window.PaperAudio.drop({ type: 'card' });
        else playPaperThud();
        invalidatePinCache(clue.id);
        requestRenderStrings();
        saveCluePosition(clue);
      }
    });

    card.addEventListener('pointercancel', () => {
      if (state.draggingClue === clue) {
        if (cardDragRaf) {
          cancelAnimationFrame(cardDragRaf);
          cardDragRaf = null;
        }
        card.classList.remove('dragging', 'over-trash');
        state.draggingClue = null;
        if (dom.boardTrashBin) {
          dom.boardTrashBin.classList.remove('is-drag-active', 'drag-over');
        }
        if (swing) swing.cancel();
      }
    });
  }


  async function saveCluePosition(clue) {
    try {
      await fetch(`/api/clues/${clue.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          x: clue.x, 
          y: clue.y,
          onBoard: clue.onBoard,
          flapX: clue.flapX,
          flapY: clue.flapY
        })
      });
    } catch (e) {
      console.warn('Failed to sync card position:', e);
    }
  }

  // --- String Tying Logic ---
  function handlePinClick(clue, pinElement) {
    if (!clue || FOLDER_CLUES.has(clue.id) || clue.id === 'clue-case-folder') return;
    playPinSound();
    const pinCoords = getPinCoordinates(clue);

    if (!state.selectedPin) {
      // First pin selected
      state.selectedPin = {
        clueId: clue.id,
        x: pinCoords.x,
        y: pinCoords.y,
        element: pinElement
      };
      pinElement.classList.add('pin-selected');
    } else if (state.selectedPin.clueId === clue.id) {
      // Clicked same pin: cancel
      clearSelectedPin();
    } else {
      // Second pin selected: connect them!
      const fromId = state.selectedPin.clueId;
      const toId = clue.id;
      clearSelectedPin();
      createConnection(fromId, toId);
    }
  }

  function clearSelectedPin() {
    if (state.selectedPin && state.selectedPin.element) {
      state.selectedPin.element.classList.remove('pin-selected');
    }
    state.selectedPin = null;
    state.activeMousePos = null;
    renderStrings();
  }

  async function createConnection(fromId, toId) {
    try {
      const res = await fetch('/api/connections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ from: fromId, to: toId, label: 'Investigative Link' })
      });
      const data = await res.json();
      if (data.success) {
        playPinSound();
        // Check if already in connections
        const exists = state.caseData.connections.some(c => 
          (c.from === fromId && c.to === toId) || (c.from === toId && c.to === fromId)
        );
        if (!exists) {
          state.caseData.connections.push(data.connection || { from: fromId, to: toId });
        }
        renderStrings();
        updateStatusHeader();

        // Check deductions trigger
        checkDeductionsAfterConnection();
      }
    } catch (e) {
      console.error('Error creating connection:', e);
    }
  }

  async function handleStringClick(connection) {
    const fromClue = state.caseData.clues.find(c => c.id === connection.from);
    const toClue = state.caseData.clues.find(c => c.id === connection.to);
    const confirmMsg = `Sever the red string between "${fromClue ? fromClue.title : connection.from}" and "${toClue ? toClue.title : connection.to}"?`;
    
    if (confirm(confirmMsg)) {
      try {
        await fetch('/api/connections', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ from: connection.from, to: connection.to })
        });
        state.caseData.connections = state.caseData.connections.filter(c => 
          !((c.from === connection.from && c.to === connection.to) || (c.from === connection.to && c.to === connection.from))
        );
        playStringSnapSound();
        renderStrings();
        updateStatusHeader();
      } catch (e) {
        console.error('Failed to remove string:', e);
      }
    }
  }

  async function checkDeductionsAfterConnection() {
    try {
      const res = await fetch('/api/deduce', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        state.caseData.deductions = data.deductions;
        updateStatusHeader();

        if (data.newlySolved && data.newlySolved.length > 0) {
          data.newlySolved.forEach(sol => {
            showDeductionToast(sol);
          });
        }
      }
    } catch (e) {
      console.error('Deduction check error:', e);
    }
  }

  function showDeductionToast(deduction) {
    playDeductionChime();
    dom.toastTitle.textContent = deduction.title;
    dom.toastDesc.textContent = deduction.summary;
    dom.deductionToast.classList.remove('hidden');

    setTimeout(() => {
      dom.deductionToast.classList.add('hidden');
    }, 5500);
  }

  // --- Dossier Inspector Modal ---
  function openDossierModal(clue) {
    if (clue && (clue.id === 'clue-oc-id')) {
      enterIdFocusMode();
      return;
    }
    state.currentModalClueId = clue.id;
    document.body.classList.add('is-examining-evidence');

    state.isUvActive = false;
    state.isLoupeActive = false;
    if (dom.modalMediaFrame) dom.modalMediaFrame.classList.remove('uv-active');
    if (dom.modalUvOverlay) dom.modalUvOverlay.classList.add('hidden');
    if (dom.btnToggleUv) dom.btnToggleUv.classList.remove('active');
    if (dom.btnToggleLoupe) dom.btnToggleLoupe.classList.remove('active');
    if (dom.modalLoupe) dom.modalLoupe.classList.add('hidden');

    if (dom.modalTitle) dom.modalTitle.textContent = clue.title;
    const format = getClueFormat(clue);
    const missingNameplate = document.getElementById('dossier-missing-nameplate');
    const personNameEl = document.getElementById('dossier-person-name');
    const captionLabel = document.getElementById('dossier-caption-label');
    const dossierStarsRow = document.getElementById('dossier-stars-row');

    if (format === 'missing') {
      if (dom.modalClassification) {
        dom.modalClassification.textContent = 'PASADENA POLICE DEPT // PUBLIC INFORMATION BULLETIN';
      }
      if (dossierStarsRow) {
        dossierStarsRow.innerHTML = '<span>✦</span><span>✦</span><span>✦</span><span>✦</span>';
        dossierStarsRow.classList.remove('hidden');
      }
      if (missingNameplate) {
        missingNameplate.classList.remove('hidden');
        if (personNameEl) {
          personNameEl.textContent = clue.personName || clue.title || 'MALCOLM "MACK" SUMMERS';
        }
      }
      if (captionLabel) {
        captionLabel.textContent = 'PUBLIC BULLETIN PHOTOMODEL // PASADENA P.D. ARCHIVE';
      }
    } else if (format === 'document') {
      if (dom.modalClassification) {
        dom.modalClassification.textContent = 'OFFICIAL SPECIAL BUREAU ARCHIVE // INCIDENT LOG';
      }
      if (dossierStarsRow) {
        dossierStarsRow.innerHTML = '<span>✦</span><span>✦</span><span>✦</span>';
        dossierStarsRow.classList.remove('hidden');
      }
      if (missingNameplate) missingNameplate.classList.add('hidden');
      if (captionLabel) {
        captionLabel.textContent = 'DOCUMENT FACSIMILE // POLICE ARCHIVE PROPERTY';
      }
    } else {
      if (dom.modalClassification) {
        dom.modalClassification.textContent = clue.classification || 'SPECIAL INVESTIGATION ARCHIVE // EVIDENCE DOSSIER';
      }
      if (dossierStarsRow) dossierStarsRow.classList.add('hidden');
      if (missingNameplate) missingNameplate.classList.add('hidden');
      if (captionLabel) {
        captionLabel.textContent = 'EXHIBIT PHOTOMODEL // REGION VII ARCHIVE';
      }
    }

    if (dom.modalMeta) dom.modalMeta.textContent = `Specimen ID: ${clue.id} · Era Date: ${clue.date || '1973.08.12'}`;
    if (dom.modalImage) dom.modalImage.src = clue.image;
    if (dom.lightboxFullImg) {
      dom.lightboxFullImg.src = clue.fullImage || clue.image || '/static/images/tigers_eye_case_file.png';
    }
    if (dom.modalUvText) dom.modalUvText.textContent = clue.cipher || 'SALT & ASH VULNERABILITY // 05:30 AM SUNRISE';
    if (dom.modalText) dom.modalText.textContent = clue.dossierText || 'No archival log found for this artifact.';
    if (dom.modalCipher) dom.modalCipher.textContent = clue.cipher || 'COORDINATES LOCKED // UNVERIFIED FREQUENCY';
    if (dom.modalAudioQuote) dom.modalAudioQuote.textContent = clue.audioIntercept ? `"${clue.audioIntercept}"` : '"Ambient background static with intermittent frequency pulse."';

    const cipherContainer = document.getElementById('modal-cipher-container');
    if (cipherContainer) {
      cipherContainer.style.display = clue.cipher ? '' : 'none';
    }

    const audioContainer = document.getElementById('modal-audio-container');
    if (audioContainer) {
      audioContainer.style.display = clue.audioIntercept ? '' : 'none';
    }

    // Toggle File into Case Dossier / Pin to Board
    const btnToggleFile = document.getElementById('btn-modal-toggle-file');
    const textToggleFile = document.getElementById('text-modal-file');
    const iconToggleFile = document.getElementById('icon-modal-file');

    if (btnToggleFile) {
      const inFolder = isClueInFolder(clue);
      btnToggleFile.classList.toggle('action-pin-board', inFolder);
      if (textToggleFile) {
        textToggleFile.textContent = inFolder ? 'PIN TO BOARD' : 'FILE INTO DOSSIER';
      }
      if (iconToggleFile) {
        iconToggleFile.setAttribute('data-lucide', inFolder ? 'pin' : 'folder-input');
      }
      btnToggleFile.title = inFolder ? 'Take evidence out of file and pin to board' : 'Enclose evidence into Case Dossier folder';

      btnToggleFile.onclick = (e) => {
        e.stopPropagation();
        if (inFolder) {
          movePaperToBoard(clue, null, 420 + Math.random() * 100, 220 + Math.random() * 80);
        } else {
          putClueIntoFolder(clue, null);
        }
        closeDossierModal();
      };
    }

    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }

    if (window.PaperAudio) {
      if (typeof window.PaperAudio.uncrumple === 'function') {
        window.PaperAudio.uncrumple();
      } else {
        window.PaperAudio.crumple('light');
      }
    }
    if (dom.dossierModal) dom.dossierModal.classList.remove('hidden');
  }

  function closeDossierModal() {
    document.body.classList.remove('is-examining-evidence');
    if (window.PaperAudio) {
      window.PaperAudio.drop({ type: 'card' });
    } else {
      playPaperThud();
    }
    if (dom.dossierModal) dom.dossierModal.classList.add('hidden');
    state.currentModalClueId = null;
    if (state.interceptAudio) {
      try { state.interceptAudio.stop(); } catch(e){}
      state.interceptAudio = null;
      document.querySelectorAll('.wave-bar').forEach(b => b.classList.remove('playing'));
    }
  }

  // --- Deductions Modal ---
  function openDeductionsModal() {
    const deductions = state.caseData.deductions || [];
    dom.deductionsList.innerHTML = '';

    deductions.forEach(d => {
      const card = document.createElement('div');
      card.className = `deduction-card ${d.solved ? 'solved' : ''}`;

      const header = document.createElement('div');
      header.className = 'deduction-header';

      const title = document.createElement('h4');
      title.className = 'deduction-title';
      title.textContent = d.title;

      const statusBadge = document.createElement('span');
      statusBadge.className = `deduction-status ${d.solved ? 'solved' : ''}`;
      statusBadge.textContent = d.solved ? 'RESOLVED' : 'UNSOLVED';

      header.appendChild(title);
      header.appendChild(statusBadge);

      const desc = document.createElement('p');
      desc.className = 'deduction-desc';
      desc.textContent = d.summary;

      card.appendChild(header);
      card.appendChild(desc);
      dom.deductionsList.appendChild(card);
    });

    if (window.PaperAudio) window.PaperAudio.crumple('light');
    dom.deductionsModal.classList.remove('hidden');
  }

  function closeDeductionsModal() {
    if (window.PaperAudio) window.PaperAudio.tap(0.9, 'card');
    dom.deductionsModal.classList.add('hidden');
  }

  // ================= STREAMLINED EVIDENCE CREATION STUDIO =================

  // ================= 3 DISTINCT PHYSICAL EVIDENCE FORMATS =================

  const EVIDENCE_ARCHETYPES = {
    missing: {
      format: "missing",
      title: "Pasadena Police Missing Bulletin #73-08",
      category: "Missing Paper",
      tag: "Missing Person",
      personName: "MALCOLM \"MACK\" SUMMERS",
      image: "/static/images/missing_person_poster.jpg",
      text: "Official Pasadena Police Public Information Bulletin. Subject last seen August 12, 1973 in the vicinity of Southmore Ave. Age 16, height 5'7\", brown hair. Urgent alert for patrol officers.",
      cipher: "CASE REF: #73-08-4109 // PASADENA P.D. ARCHIVE"
    },
    document: {
      format: "document",
      title: "Sworn Incident Affidavit // Night Log",
      category: "Document",
      tag: "Police Report",
      personName: "",
      image: "/static/images/sighting_report_cebu.png",
      text: "OFFICIAL INCIDENT REPORT:\nSworn statement filed by local constable regarding unusual nocturnal disturbances and sudden drop in barometric pressure. Witnesses report an airborne shadow traversing the ridge line towards Talisay ridge.",
      cipher: "FILED: 1993.01.26 // CLASSIFIED RECORD"
    },
    polaroid: {
      format: "polaroid",
      title: "Night Flight Surveillance Polaroid",
      category: "Photograph",
      tag: "Photo Evidence",
      personName: "",
      image: "/static/images/creature_polaroid.png",
      text: "Polaroid print captured near the tree line. Visual analysis indicates an airborne silhouette inconsistent with regional fauna.",
      cipher: "COORDINATES: TALISAY RIDGE // ALT: 450M"
    }
  };

  const RANDOM_CASE_CLUES = [
    {
      format: "missing",
      title: "Pasadena Missing Bulletin #73-08",
      category: "Missing Paper",
      tag: "Missing Person",
      personName: "MALCOLM \"MACK\" SUMMERS",
      image: "/static/images/missing_person_poster.jpg",
      text: "Official 1973 public information flyer posted near Southmore Ave. Hand-annotated notes link the subject to Dean Corll candy factory.",
      cipher: "CASE REF: #73-08-4109 // URGENT INQUIRY"
    },
    {
      format: "missing",
      title: "Houston Police Missing Notice #73-12",
      category: "Missing Paper",
      tag: "Missing Person",
      personName: "DEAN CORLL SUSPECT INQUIRY",
      image: "/static/images/dossier_agent.jpg",
      text: "Houston Police Bulletin: Multiple youths reported unaccounted for since June 1973. Search radius focused on Pasadena and Houston heights.",
      cipher: "CASE REF: #73-08-HPD // ARCHIVE"
    },
    {
      format: "document",
      title: "Sworn Eyewitness Statement // Siquijor",
      category: "Document",
      tag: "Affidavit",
      image: "/static/images/sighting_report_cebu.png",
      text: "AFFIDAVIT TRANSCRIPTION:\nWitness logs midnight observation over metal roof. High-pitched mechanical or biological whine heard prior to structural claw damage on roof eaves.",
      cipher: "AFFIDAVIT REF: SIQ-2003-91"
    },
    {
      format: "document",
      title: "Sitio Balungag Night Incident Dispatch",
      category: "Document",
      tag: "Incident Log",
      image: "/static/images/sighting_report_cebu.png",
      text: "POLICE DISPATCH LOG:\nPatrol unit responded to reported disturbance. Unidentified airborne entity sighted ascending over coconut tree canopy at 02:32 AM. Severe sulfur smell detected.",
      cipher: "DISPATCH: TALISAY STATION 4"
    },
    {
      format: "polaroid",
      title: "Sitio Balungag Night Sighting // Negative #4",
      category: "Photograph",
      tag: "Surveillance Photo",
      image: "/static/images/creature_polaroid.png",
      text: "High-contrast night surveillance negative. Silhouette shows airborne entity ascending over coconut palms with trailing anatomical viscera.",
      cipher: "OPTICAL MATCH: 8920-1129 // 2:32 AM"
    },
    {
      format: "polaroid",
      title: "Tree Line Reconnaissance Snapshot",
      category: "Photograph",
      tag: "Crime Scene Photo",
      image: "/static/images/sighting_log.png",
      text: "Instant photograph of severed foliage and barbed wire snag points at the southern perimeter fence line.",
      cipher: "SECTOR: SOUTH PERIMETER // GRID 4"
    }
  ];

  function setCreatorDestination(dest) {
    const inputDestination = document.getElementById('creator-destination');
    const btnDestBoard = document.getElementById('btn-dest-board');
    const btnDestFolder = document.getElementById('btn-dest-folder');
    const submitText = document.getElementById('btn-submit-clue-text');
    const submitIcon = document.getElementById('btn-submit-clue-icon');

    if (inputDestination) inputDestination.value = dest;
    if (btnDestBoard) btnDestBoard.classList.toggle('active', dest === 'board');
    if (btnDestFolder) btnDestFolder.classList.toggle('active', dest === 'folder');
    if (submitText) {
      submitText.textContent = dest === 'folder' ? 'File into Dossier' : 'Pin to Board';
    }
    if (submitIcon) {
      submitIcon.setAttribute('data-lucide', dest === 'folder' ? 'folder-input' : 'pin');
    }
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }
  }

  function setCreatorFormat(format, applyDefaults = false) {
    const hiddenFormat = document.getElementById('creator-format');
    if (hiddenFormat) hiddenFormat.value = format;

    document.querySelectorAll('.archetype-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.type === format);
    });

    const groupPersonName = document.getElementById('group-person-name');
    const mediaSection = document.getElementById('creator-media-section');
    const labelTitle = document.getElementById('label-new-title');
    const labelText = document.getElementById('label-new-text');
    const catSelect = document.getElementById('new-category');
    const tagInput = document.getElementById('new-tag');
    const previewFormatTag = document.getElementById('preview-format-tag');
    const previewFooterHint = document.getElementById('preview-footer-hint');

    // Show/hide person name field (Type 1 only)
    if (groupPersonName) {
      groupPersonName.style.display = format === 'missing' ? '' : 'none';
    }

    // Type 2: Only a paper with customizable text -> hide photo upload/presets section
    if (mediaSection) {
      mediaSection.style.display = format === 'document' ? 'none' : '';
    }

    if (format === 'missing') {
      if (labelTitle) labelTitle.textContent = 'Poster Title / Bulletin Ref';
      if (labelText) labelText.textContent = 'Missing Person Details & Last Seen Info';
      if (catSelect) catSelect.value = 'Missing Paper';
      if (tagInput && !tagInput.value) tagInput.value = 'Missing Person';
      if (previewFormatTag) previewFormatTag.textContent = 'TYPE 1: MISSING PAPER';
      if (previewFooterHint) previewFooterHint.textContent = 'Real bulletin flyer with bold MISSING and name directly under photo';
    } else if (format === 'document') {
      if (labelTitle) labelTitle.textContent = 'Document Title / Subject';
      if (labelText) labelText.textContent = 'Document Body Text (Displayed directly on paper)';
      if (catSelect) catSelect.value = 'Document';
      if (tagInput && !tagInput.value) tagInput.value = 'Police Report';
      if (previewFormatTag) previewFormatTag.textContent = 'TYPE 2: TEXT DOCUMENT';
      if (previewFooterHint) previewFooterHint.textContent = 'Pure paper document sheet with customizable typewriter text';
    } else {
      if (labelTitle) labelTitle.textContent = 'Polaroid Caption / Title';
      if (labelText) labelText.textContent = 'Investigative Notes & Forensic Observations';
      if (catSelect) catSelect.value = 'Photograph';
      if (tagInput && !tagInput.value) tagInput.value = 'Photo Evidence';
      if (previewFormatTag) previewFormatTag.textContent = 'TYPE 3: POLAROID PHOTO';
      if (previewFooterHint) previewFooterHint.textContent = 'Classic instant Polaroid photo with bottom white caption margin';
    }

    if (applyDefaults) {
      const arch = EVIDENCE_ARCHETYPES[format];
      if (arch) {
        const titleInput = document.getElementById('new-title');
        const personInput = document.getElementById('new-person-name');
        const notesInput = document.getElementById('new-text');
        const cipherInput = document.getElementById('new-cipher');

        if (titleInput) titleInput.value = arch.title;
        if (personInput && arch.personName) personInput.value = arch.personName;
        if (notesInput) notesInput.value = arch.text;
        if (cipherInput) cipherInput.value = arch.cipher;
        if (tagInput) tagInput.value = arch.tag;
        if (arch.image) setCreatorImage(arch.image);
      }
    }

    updateCreatorPreview();
  }

  function openAddClueModal(opts = {}) {
    if (!dom.addModal) return;

    if (window.PaperAudio) {
      if (typeof window.PaperAudio.uncrumple === 'function') window.PaperAudio.uncrumple();
      else window.PaperAudio.tap(1.0, 'card');
    } else {
      playPaperThud();
    }

    const inputX = document.getElementById('creator-clue-x');
    const inputY = document.getElementById('creator-clue-y');
    const coordsText = document.getElementById('creator-coords-text');

    if (opts.x !== undefined && opts.y !== undefined) {
      if (inputX) inputX.value = opts.x;
      if (inputY) inputY.value = opts.y;
      if (coordsText) coordsText.textContent = `Target Spot: X:${opts.x}, Y:${opts.y} (Pinned at Click)`;
    } else {
      if (inputX) inputX.value = '';
      if (inputY) inputY.value = '';
      if (coordsText) coordsText.textContent = 'Position: Auto-centered on Corkboard';
    }

    const initialFormat = opts.format || (opts.category === 'Document' ? 'document' : (opts.category === 'Photograph' ? 'polaroid' : 'missing'));
    setCreatorFormat(initialFormat, !opts.title);

    if (opts.image) {
      setCreatorImage(opts.image);
    }
    if (opts.title) {
      const titleInput = document.getElementById('new-title');
      if (titleInput) titleInput.value = opts.title;
    }
    if (opts.personName) {
      const personInput = document.getElementById('new-person-name');
      if (personInput) personInput.value = opts.personName;
    }
    if (opts.category) {
      const catSelect = document.getElementById('new-category');
      if (catSelect) catSelect.value = opts.category;
    }

    setCreatorDestination(opts.destination || 'board');
    updateCreatorPreview();
    dom.addModal.classList.remove('hidden');

    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }

    const titleInput = document.getElementById('new-title');
    if (titleInput) {
      setTimeout(() => {
        titleInput.focus();
        titleInput.select();
      }, 100);
    }
  }

  function closeAddClueModal() {
    if (!dom.addModal) return;
    if (window.PaperAudio) window.PaperAudio.tap(0.65, 'subtle');
    dom.addModal.classList.add('hidden');
  }

  function setCreatorImage(imgSrc) {
    const hiddenImg = document.getElementById('creator-image-data');
    if (hiddenImg) hiddenImg.value = imgSrc;

    const previewImg = document.getElementById('preview-img-target');
    if (previewImg) previewImg.src = imgSrc;

    document.querySelectorAll('.photo-thumb-option').forEach(el => {
      el.classList.toggle('active', el.dataset.src === imgSrc);
    });

    updateCreatorPreview();
  }

  function updateCreatorPreview() {
    const previewCard = document.getElementById('preview-live-card');
    if (!previewCard) return;

    const format = document.getElementById('creator-format')?.value || 'missing';
    const titleVal = document.getElementById('new-title')?.value.trim() || 'Untitled Evidence';
    const personNameVal = document.getElementById('new-person-name')?.value.trim() || 'MALCOLM "MACK" SUMMERS';
    const textVal = document.getElementById('new-text')?.value.trim() || '';
    const imgVal = document.getElementById('creator-image-data')?.value || '/static/images/missing_person_poster.jpg';
    const cipherVal = document.getElementById('new-cipher')?.value.trim() || '';

    previewCard.className = `preview-live-card type-${format}`;

    if (format === 'missing') {
      previewCard.innerHTML = `
        <div class="preview-card-pin"></div>
        <div class="missing-poster-inner">
          <div class="ink-splatter ink-top-right"></div>
          <div class="ink-splatter ink-mid-left"></div>
          <div class="ink-splatter ink-bottom-right"></div>
          <div class="missing-poster-header">
            <h2 class="missing-banner-title">MISSING</h2>
            <div class="missing-stars-row" aria-hidden="true">
              <span>✦</span>
              <span>✦</span>
              <span>✦</span>
              <span>✦</span>
            </div>
          </div>
          <div class="missing-box-outline">
            <div class="missing-photo-frame">
              <img src="${imgVal}" alt="Missing Person Preview" class="preview-card-photo" id="preview-img-target">
            </div>
            <div class="missing-name-strip">
              <span class="missing-name-label">NAME OF MISSING PERSON:</span>
              <span class="missing-name-value" id="preview-person-name">${escapeHtml(personNameVal || 'UNKNOWN SUBJECT')}</span>
            </div>
          </div>
          <div class="missing-details-snippet" id="preview-missing-details">
            ${escapeHtml(textVal || 'Subject last seen August 12, 1973 in Pasadena vicinity. Urgent alert for patrol officers.')}
          </div>
          <div class="missing-footer-strip">
            <span>POLICE ARCHIVE</span>
            <span>NOTIFY IMMEDIATELY</span>
          </div>
        </div>
      `;
    } else if (format === 'document') {
      previewCard.innerHTML = `
        <div class="preview-card-pin"></div>
        <div class="document-paper-inner">
          <div class="ink-splatter ink-top-right" style="opacity: 0.6; transform: scale(0.75);"></div>
          <div class="ink-splatter ink-bottom-right" style="opacity: 0.6; transform: scale(0.75);"></div>
          <div class="doc-box-outline">
            <div class="doc-paper-header-row">
              <span class="doc-header-seal">OFFICIAL DISPATCH // DIV VII</span>
              <div class="doc-stars-row" aria-hidden="true">
                <span>✦</span>
                <span>✦</span>
                <span>✦</span>
              </div>
              <span class="doc-stamp-filed">FILED</span>
            </div>
            <h3 class="doc-paper-title" id="preview-doc-title">${escapeHtml(titleVal || 'INCIDENT AFFIDAVIT')}</h3>
            <div class="doc-paper-body-text" id="preview-doc-body">
              ${escapeHtml(textVal || 'Official sworn statement filed for archival preservation. Awaiting forensic frequency check.')}
            </div>
            <div class="doc-paper-footer-row">
              <span>${escapeHtml(cipherVal || 'REF: ARCHIVE RECORD')}</span>
              <span class="doc-signature">Agent Maza ✍</span>
            </div>
          </div>
        </div>
      `;
    } else {
      previewCard.innerHTML = `
        <div class="preview-card-pin"></div>
        <div class="polaroid-inner-frame">
          <div class="polaroid-photo-box">
            <img src="${imgVal}" alt="Polaroid Preview" class="preview-card-photo" id="preview-img-target">
          </div>
          <div class="polaroid-bottom-caption">
            <span class="polaroid-title-text" id="preview-title-text">${escapeHtml(titleVal || 'Surveillance Polaroid')}</span>
            <span class="polaroid-date-tag">1993.01.26 // VISAYAS ARCHIVE</span>
          </div>
        </div>
      `;
    }
  }

  function setupEvidenceCreator() {
    // Open modal button
    if (dom.btnAddClue) {
      dom.btnAddClue.addEventListener('click', () => openAddClueModal());
    }
    if (dom.addModalCloseBtn) {
      dom.addModalCloseBtn.addEventListener('click', closeAddClueModal);
    }
    if (dom.btnCancelAdd) {
      dom.btnCancelAdd.addEventListener('click', closeAddClueModal);
    }

    // Click backdrop to close
    if (dom.addModal) {
      dom.addModal.addEventListener('click', (e) => {
        if (e.target === dom.addModal) {
          closeAddClueModal();
        }
      });
    }

    // Escape key to close
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && dom.addModal && !dom.addModal.classList.contains('hidden')) {
        closeAddClueModal();
      }
    });

    // Double-click pin basket to open intake studio
    if (dom.boardPinBasket) {
      dom.boardPinBasket.addEventListener('dblclick', () => openAddClueModal());
    }

    // Archetype Template Buttons (3 Distinct Physical Evidence Types)
    document.querySelectorAll('.archetype-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const type = btn.dataset.type;
        setCreatorFormat(type, true);
        if (window.PaperAudio) window.PaperAudio.tap(0.85, 'card');
      });
    });

    // Preset Photo Thumbnails
    document.querySelectorAll('.photo-thumb-option').forEach(thumb => {
      thumb.addEventListener('click', () => {
        setCreatorImage(thumb.dataset.src);
        if (window.PaperAudio) window.PaperAudio.tap(0.6, 'card');
      });
    });

    // Quick Random Case Clue Generator
    const btnRandom = document.getElementById('btn-quick-random-clue');
    if (btnRandom) {
      btnRandom.addEventListener('click', () => {
        const item = RANDOM_CASE_CLUES[Math.floor(Math.random() * RANDOM_CASE_CLUES.length)];
        const format = item.format || 'missing';

        setCreatorFormat(format, false);

        const titleInput = document.getElementById('new-title');
        const personInput = document.getElementById('new-person-name');
        const tagInput = document.getElementById('new-tag');
        const notesInput = document.getElementById('new-text');
        const cipherInput = document.getElementById('new-cipher');

        if (titleInput) titleInput.value = item.title;
        if (personInput) personInput.value = item.personName || '';
        if (tagInput) tagInput.value = item.tag;
        if (notesInput) notesInput.value = item.dossierText || item.text || '';
        if (cipherInput) cipherInput.value = item.cipher || '';

        if (item.image) setCreatorImage(item.image);
        updateCreatorPreview();

        const card = document.getElementById('preview-live-card');
        if (card) {
          card.style.transform = 'rotate(3deg) scale(1.04)';
          setTimeout(() => { if (card) card.style.transform = 'rotate(-2deg) scale(1)'; }, 180);
        }
        if (window.PaperAudio) window.PaperAudio.tap(1.1, 'card');
      });
    }

    // Live preview inputs synchronization
    const titleInput = document.getElementById('new-title');
    if (titleInput) {
      titleInput.addEventListener('input', updateCreatorPreview);
    }
    const personInput = document.getElementById('new-person-name');
    if (personInput) {
      personInput.addEventListener('input', updateCreatorPreview);
    }
    const notesInput = document.getElementById('new-text');
    if (notesInput) {
      notesInput.addEventListener('input', updateCreatorPreview);
    }
    const cipherInput = document.getElementById('new-cipher');
    if (cipherInput) {
      cipherInput.addEventListener('input', updateCreatorPreview);
    }

    // Category dropdown changes -> syncs format
    const catSelect = document.getElementById('new-category');
    if (catSelect) {
      catSelect.addEventListener('change', () => {
        const val = catSelect.value;
        if (val === 'Missing Paper') {
          setCreatorFormat('missing');
        } else if (val === 'Document') {
          setCreatorFormat('document');
        } else {
          setCreatorFormat('polaroid');
        }
      });
    }

    // Custom File Input & Browse
    const fileInput = document.getElementById('new-image-file');
    const btnBrowse = document.getElementById('btn-browse-photo');
    const dropzone = document.getElementById('creator-upload-dropzone');
    const dropzoneLabel = document.getElementById('dropzone-text-label');

    if (btnBrowse && fileInput) {
      btnBrowse.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        fileInput.click();
      });
    }

    if (dropzone && fileInput) {
      dropzone.addEventListener('click', (e) => {
        if (e.target !== btnBrowse) fileInput.click();
      });

      dropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
      });
      dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
      dropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
        const file = e.dataTransfer?.files?.[0];
        if (file && file.type.startsWith('image/')) {
          handleFileChosen(file);
        }
      });
    }

    if (fileInput) {
      fileInput.addEventListener('change', (e) => {
        const file = e.target.files?.[0];
        if (file) handleFileChosen(file);
      });
    }

    function handleFileChosen(file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const dataUrl = ev.target.result;
        setCreatorImage(dataUrl);
        if (dropzoneLabel) dropzoneLabel.textContent = `Loaded: ${file.name.substring(0, 24)}`;
        if (window.PaperAudio) window.PaperAudio.tap(0.8, 'card');
      };
      reader.readAsDataURL(file);
    }

    // Corkboard Double-Click -> Open Creator at exact cursor spot
    if (dom.surface) {
      dom.surface.addEventListener('dblclick', (e) => {
        if (e.target.closest('.clue-card') || 
            e.target.closest('.folder-paper-item') || 
            e.target.closest('.board-pinned-id-card') || 
            e.target.closest('.interactive-folder-wrapper') ||
            e.target.closest('#board-pin-basket') ||
            e.target.closest('#board-trash-bin') ||
            e.target.closest('.modal-backdrop')) {
          return;
        }

        const sRect = getSurfaceRect();
        const clickX = Math.round(e.clientX - sRect.left - 100);
        const clickY = Math.round(e.clientY - sRect.top - 20);

        openAddClueModal({ x: Math.max(20, clickX), y: Math.max(20, clickY) });
      });

      // Corkboard Drag & Drop custom image file directly onto board
      dom.surface.addEventListener('dragover', (e) => {
        if (e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files')) {
          e.preventDefault();
        }
      });

      dom.surface.addEventListener('drop', (e) => {
        const file = e.dataTransfer?.files?.[0];
        if (file && file.type.startsWith('image/')) {
          e.preventDefault();
          const sRect = getSurfaceRect();
          const dropX = Math.round(e.clientX - sRect.left - 100);
          const dropY = Math.round(e.clientY - sRect.top - 20);
          const rawName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');

          const reader = new FileReader();
          reader.onload = (ev) => {
            openAddClueModal({
              x: Math.max(20, dropX),
              y: Math.max(20, dropY),
              image: ev.target.result,
              title: rawName.charAt(0).toUpperCase() + rawName.slice(1),
              category: 'Photograph'
            });
          };
          reader.readAsDataURL(file);
        }
      });
    }

    // Global Clipboard Paste (Ctrl+V) Image
    window.addEventListener('paste', (e) => {
      if (['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) return;
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        if (items[i].type.indexOf('image') !== -1) {
          const blob = items[i].getAsFile();
          if (blob) {
            e.preventDefault();
            const reader = new FileReader();
            reader.onload = (ev) => {
              openAddClueModal({
                image: ev.target.result,
                title: 'Pasted Photographic Evidence',
                category: 'Photograph'
              });
            };
            reader.readAsDataURL(blob);
            break;
          }
        }
      }
    });

    // Keyboard shortcut: Press N on board to open creator
    window.addEventListener('keydown', (e) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) return;
      if (e.key === 'n' || e.key === 'N') {
        const anyModalOpen = document.querySelector('.modal-backdrop:not(.hidden)');
        if (!anyModalOpen) {
          e.preventDefault();
          openAddClueModal();
        }
      }
    });

    // Destination Placement Buttons
    const btnDestBoard = document.getElementById('btn-dest-board');
    const btnDestFolder = document.getElementById('btn-dest-folder');
    if (btnDestBoard) {
      btnDestBoard.addEventListener('click', () => {
        setCreatorDestination('board');
        if (window.PaperAudio) window.PaperAudio.tap(0.65, 'subtle');
      });
    }
    if (btnDestFolder) {
      btnDestFolder.addEventListener('click', () => {
        setCreatorDestination('folder');
        if (window.PaperAudio) window.PaperAudio.tap(0.65, 'subtle');
      });
    }

    // Form Submit Handler
    if (dom.addClueForm) {
      dom.addClueForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formatVal = document.getElementById('creator-format')?.value || 'missing';
        const titleVal = document.getElementById('new-title')?.value.trim() || 'New Evidence';
        const personNameVal = document.getElementById('new-person-name')?.value.trim() || '';
        const catVal = document.getElementById('new-category')?.value || (formatVal === 'missing' ? 'Missing Paper' : (formatVal === 'document' ? 'Document' : 'Photograph'));
        const tagVal = document.getElementById('new-tag')?.value.trim() || (formatVal === 'missing' ? 'Missing Person' : (formatVal === 'document' ? 'Police Report' : 'Photo Evidence'));
        const textVal = document.getElementById('new-text')?.value.trim() || '';
        const cipherVal = document.getElementById('new-cipher')?.value.trim() || '';
        const imgVal = document.getElementById('creator-image-data')?.value || (formatVal === 'missing' ? '/static/images/missing_person_poster.jpg' : '/static/images/creature_polaroid.png');
        const xVal = document.getElementById('creator-clue-x')?.value;
        const yVal = document.getElementById('creator-clue-y')?.value;

        const inputDestination = document.getElementById('creator-destination');
        const isFolderDest = inputDestination?.value === 'folder';

        const payload = {
          format: formatVal,
          title: titleVal,
          personName: personNameVal,
          category: catVal,
          tag: tagVal,
          dossierText: textVal,
          cipher: cipherVal,
          image: imgVal,
          inFolder: isFolderDest,
          onBoard: !isFolderDest,
          x: xVal ? Number(xVal) : null,
          y: yVal ? Number(yVal) : null
        };

        try {
          const res = await fetch('/api/clues', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
          const data = await res.json();
          if (data.success && data.clue) {
            if (isFolderDest) {
              if (window.PaperAudio) window.PaperAudio.tap(1.0, 'card');
              else playPaperThud();
              showDisposalToast('EVIDENCE ENCLOSED', `"${data.clue.title}" filed into Case Dossier`);
            } else {
              playPinDriveInSound();
              showDisposalToast('EVIDENCE PINNED', `"${data.clue.title}" secured to board`);
            }
            if (!state.caseData.clues) state.caseData.clues = [];
            state.caseData.clues.push(data.clue);
            closeAddClueModal();
            renderBoard();
          }
        } catch (err) {
          console.error('Failed to create clue:', err);
        }
      });
    }
  }

  // --- Delete Clue ---
  async function deleteCurrentClue() {
    if (!state.currentModalClueId) return;
    const clue = state.caseData.clues.find(c => c.id === state.currentModalClueId);
    if (!confirm(`Are you sure you want to unpin "${clue ? clue.title : 'this clue'}" from the board?`)) return;

    try {
      if (window.PaperAudio) window.PaperAudio.crumple('heavy');
      await fetch(`/api/clues/${state.currentModalClueId}`, { method: 'DELETE' });
      state.caseData.clues = state.caseData.clues.filter(c => c.id !== state.currentModalClueId);
      state.caseData.connections = state.caseData.connections.filter(c => 
        c.from !== state.currentModalClueId && c.to !== state.currentModalClueId
      );
      closeDossierModal();
      renderBoard();
    } catch (e) {
      console.error('Failed to delete clue:', e);
    }
  }

  // --- Tactical Archival Incineration / Disposal Mechanics ---
  function checkTrashCollision(clientX, clientY, cardRect, customTrashRect) {
    const trash = dom.boardTrashBin;
    if (!trash) return false;
    const tRect = customTrashRect || trash.getBoundingClientRect();
    // Forgiving hit margin for tactile UX
    const padding = 24;
    const isPointerOver = (
      clientX >= tRect.left - padding &&
      clientX <= tRect.right + padding &&
      clientY >= tRect.top - padding &&
      clientY <= tRect.bottom + padding
    );
    if (isPointerOver) return true;

    if (cardRect) {
      const trashCenterX = tRect.left + tRect.width / 2;
      const trashCenterY = tRect.top + tRect.height / 2;
      if (
        trashCenterX >= cardRect.left &&
        trashCenterX <= cardRect.right &&
        trashCenterY >= cardRect.top &&
        trashCenterY <= cardRect.bottom
      ) {
        return true;
      }
    }
    return false;
  }

  let disposalToastTimeout = null;
  function showDisposalToast(title, desc) {
    let toast = document.getElementById('archive-disposal-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'archive-disposal-toast';
      toast.className = 'archive-disposal-toast';
      document.body.appendChild(toast);
    }
    toast.innerHTML = `
      <div class="toast-disposal-icon"><i data-lucide="trash-2"></i></div>
      <div class="toast-disposal-body">
        <span class="toast-disposal-tag">${title}</span>
        <span class="toast-disposal-msg">${desc}</span>
      </div>
    `;
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }
    toast.classList.add('show');

    clearTimeout(disposalToastTimeout);
    disposalToastTimeout = setTimeout(() => {
      toast.classList.remove('show');
    }, 2800);
  }

  async function incinerateClue(clue, cardEl) {
    if (!clue) return;
    const clueId = clue.id;
    const clueTitle = clue.title || 'Evidence Artifact';

    // 1. Audio: Heavy tactile paper crumple & red string snap
    if (window.PaperAudio) window.PaperAudio.crumple('heavy');
    playStringSnapSound();

    // 2. Trash bin burst feedback
    if (dom.boardTrashBin) {
      dom.boardTrashBin.classList.add('trash-incinerated');
      setTimeout(() => {
        if (dom.boardTrashBin) dom.boardTrashBin.classList.remove('trash-incinerated');
      }, 600);
    }

    // 3. Card visual incineration shrink
    if (cardEl) {
      cardEl.classList.add('card-incinerating');
    }

    // 4. Remove connected red strings immediately
    state.caseData.connections = (state.caseData.connections || []).filter(c => 
      c.from !== clueId && c.to !== clueId
    );
    renderStrings();

    // 5. Brief animation interval
    await new Promise(r => setTimeout(r, 320));

    // 6. Backend API sync & state cleanup
    try {
      await fetch(`/api/clues/${clueId}`, { method: 'DELETE' });
    } catch (err) {
      console.warn('Backend DELETE error, continuing client cleanup:', err);
    }

    state.caseData.clues = (state.caseData.clues || []).filter(c => c.id !== clueId);
    invalidatePinCache(clueId);

    if (state.currentModalClueId === clueId) {
      closeDossierModal();
    }

    if (cardEl) {
      cardEl.classList.remove('card-incinerating', 'over-trash', 'dragging', 'is-picked-up');
      cardEl.style.display = 'none';
      if (cardEl.classList.contains('paper-on-board')) {
        cardEl.remove();
      }
    }

    renderBoard();
    updateClosedEvidenceCount();
    showDisposalToast('EVIDENCE INCINERATED', `"${clueTitle}" deleted from archive`);
  }

  async function incinerateIdCard(card, cardEl) {
    if (!card) return;
    const cardId = card.id;
    const cardName = card.name || 'Operative ID';

    if (state.idCards.length <= 1) {
      showDisposalToast('DISPOSAL RESTRICTED', 'At least one operative ID must remain in registry.');
      if (window.PaperAudio) window.PaperAudio.tap(1.0, 'heavy');
      renderIdCards();
      return;
    }

    if (window.PaperAudio) window.PaperAudio.crumple('heavy');
    playStringSnapSound();

    if (dom.boardTrashBin) {
      dom.boardTrashBin.classList.add('trash-incinerated');
      setTimeout(() => {
        if (dom.boardTrashBin) dom.boardTrashBin.classList.remove('trash-incinerated');
      }, 600);
    }

    if (cardEl) {
      cardEl.classList.add('card-incinerating');
    }

    const clueId = `clue-oc-id-${cardId}`;
    if (state.caseData) {
      state.caseData.clues = (state.caseData.clues || []).filter(c => c.id !== clueId);
      state.caseData.connections = (state.caseData.connections || []).filter(c => c.from !== clueId && c.to !== clueId);
    }
    renderStrings();

    await new Promise(r => setTimeout(r, 320));

    try {
      await fetch('/api/id_cards', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: cardId })
      });
    } catch (err) {
      console.warn('Backend ID DELETE error:', err);
    }

    state.idCards = (state.idCards || []).filter(c => c.id !== cardId);
    const nextCard = state.idCards[0];
    state.activeIdCardId = nextCard.id;
    state.idCard = nextCard;

    syncIdCardClues();
    updateIdCountBadge();
    renderIdCards();
    updateIdCardDisplays();
    showDisposalToast('CREDENTIAL INCINERATED', `Operative "${cardName}" removed`);
  }

  // --- Reset & Export ---
  async function resetBoard() {
    if (!confirm("Reset the board to default Tiger's Eye investigation layout?")) return;
    try {
      if (window.PaperAudio) window.PaperAudio.crumple('heavy');
      const res = await fetch('/api/reset', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        state.caseData = data.data;
        renderBoard();
      }
    } catch (e) {
      console.error('Failed to reset board:', e);
    }
  }

  // --- Dossier Case Report ---
  async function exportDossier() {
    try {
      const res = await fetch('/api/export');
      const data = await res.json();
      openReportModal(data);
    } catch (e) {
      console.error('Export failed:', e);
    }
  }

  function openReportModal(reportData) {
    if (!dom.reportModal || !dom.reportBodyContent) return;
    playPaperThud();

    const clues = reportData.dossiers || [];
    const solvedDeductions = reportData.solved_deductions || [];

    let html = `
      <div class="report-meta-summary">
        <h3 class="report-section-title"><i data-lucide="info" class="w-4 h-4"></i> CASE OVERVIEW & ARCHIVAL STATUS</h3>
        <p style="font-family:'Courier Prime',monospace; font-size:11px; line-height:1.6; color:#cbd5e1;">
          <strong>Case:</strong> ${reportData.case_header?.title || "Tiger's Eye"}<br>
          <strong>Department:</strong> ${reportData.case_header?.subtitle || "Special Investigation Archive // Region VII"}<br>
          <strong>File Code:</strong> ${reportData.case_header?.caseNo || "FILE NO. 8920-1129"}<br>
          <strong>Classification:</strong> ${reportData.case_header?.classifiedLevel || "TOP SECRET // LEVEL 4"}<br>
          <strong>Active Era:</strong> ${reportData.case_header?.era || "1993 Initial Bureau Filing"} · 
          <strong>Evidence Nodes:</strong> ${reportData.total_clues} · 
          <strong>Active Red Threads:</strong> ${reportData.active_connections}
        </p>
      </div>

      <div class="report-deductions-block">
        <h3 class="report-section-title"><i data-lucide="sparkles" class="w-4 h-4 text-amber-400"></i> SYNTHESIZED CASE DEDUCTIONS (${solvedDeductions.length} RESOLVED)</h3>
        <div style="display:flex; flex-direction:column; gap:8px;">
          ${solvedDeductions.length > 0 ? solvedDeductions.map(d => `
            <div style="background:rgba(34,197,94,0.1); border:1px solid rgba(34,197,94,0.3); border-radius:4px; padding:8px 12px; font-family:'Courier Prime',monospace; font-size:11px; color:#4ade80;">
              ✔ RESOLVED: ${d}
            </div>
          `).join('') : '<p style="font-family:\'Courier Prime\',monospace; font-size:11px; color:#94a3b8;">No case conclusions synthesized yet. Connect matching evidence pins with red yarn to unlock deductions.</p>'}
        </div>
      </div>

      <div class="report-evidence-roster">
        <h3 class="report-section-title"><i data-lucide="archive" class="w-4 h-4"></i> EVIDENCE ROSTER & SPECIMEN ARCHIVE</h3>
        <div class="report-clues-grid">
          ${clues.map(c => `
            <div class="report-clue-card">
              <h4 class="report-clue-title">${c.title}</h4>
              <div class="report-clue-meta">Tag: ${c.tag || 'Clue'} · Date: ${c.date || '1993'}</div>
              <p style="font-family:'Courier Prime',monospace; font-size:10px; color:#94a3b8; line-height:1.4;">${c.forensic_text?.substring(0, 110)}...</p>
              ${c.cipher ? `<div class="report-clue-cipher">CIPHER: ${c.cipher}</div>` : ''}
            </div>
          `).join('')}
        </div>
      </div>
    `;

    dom.reportBodyContent.innerHTML = html;
    dom.reportModal.classList.remove('hidden');
    setupLucideIcons();
  }

  function closeReportModal() {
    if (dom.reportModal) dom.reportModal.classList.add('hidden');
  }

  function downloadReportJson(data) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `CASE_TIGERS_EYE_DOSSIER_REPORT.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  // --- Era Change ---
  async function switchEra(eraId) {
    try {
      const res = await fetch('/api/case/era', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ era_id: eraId })
      });
      const data = await res.json();
      if (data.success) {
        state.caseData.case.era = data.era;
        playPaperThud();
      }
    } catch (e) {
      console.error('Era switch error:', e);
    }
  }

  // ================= CERTIFIED OC ID CARD LOGIC =================
  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  async function loadIdCards() {
    try {
      const res = await fetch('/api/id_cards');
      if (!res.ok) throw new Error('Failed to load ID cards data');
      const data = await res.json();

      let cards = data.idCards;
      if (!Array.isArray(cards) || cards.length === 0) {
        if (data.idCard && typeof data.idCard === 'object' && Object.keys(data.idCard).length > 0) {
          cards = [{ id: data.idCard.id || 'oc-id-1', ...data.idCard }];
        } else {
          cards = [{
            id: 'oc-id-1',
            creator: 'AGENT TIGER',
            name: 'Maria Tala Esperanza',
            birthdate: '1993 / 10 / 22',
            age: '31',
            nationality: 'Visayan / Philippine',
            species: 'Manananggal',
            gender: 'fem',
            height: '5\'7" (170cm)',
            weight: '128 lbs (58kg)',
            sexuality: 'Classified / Bi',
            signature: 'M. Tala Esperanza',
            photo: '/static/images/dossier_agent.jpg',
            pinned: true,
            x: 820,
            y: 440,
            rotation: 3
          }];
        }
      }

      state.idCards = cards;
      state.activeIdCardId = state.idCards[0].id;
      state.idCard = state.idCards[0];

      syncIdCardClues();
      updateIdCountBadge();
      updateIdCardDisplays();
      renderIdCards();
    } catch (err) {
      console.warn('Error fetching ID cards:', err);
    }
  }

  function syncIdCardClues() {
    if (!state.caseData) return;
    if (!state.caseData.clues) state.caseData.clues = [];

    state.idCards.forEach(card => {
      const clueId = `clue-oc-id-${card.id}`;
      let clue = state.caseData.clues.find(c => c.id === clueId);
      if (!clue) {
        clue = {
          id: clueId,
          title: `Certified OC ID: ${card.name || 'Operative'}`,
          category: 'Suspect',
          x: card.x !== undefined ? card.x : 820,
          y: card.y !== undefined ? card.y : 440,
          width: 320,
          height: 240,
          image: card.photo || '/static/images/dossier_agent.jpg',
          dossierText: `Official OC Identification Record for ${card.name || 'Operative'}. Species: ${card.species || 'Unknown'}. Origin: ${card.nationality || 'Classified'}.`
        };
        state.caseData.clues.push(clue);
      } else {
        clue.title = `Certified OC ID: ${card.name || 'Operative'}`;
        clue.x = card.x !== undefined ? card.x : clue.x;
        clue.y = card.y !== undefined ? card.y : clue.y;
        clue.image = card.photo || clue.image;
      }
    });

    // Also sync the primary alias clue-oc-id
    if (state.idCards[0]) {
      const primary = state.idCards[0];
      let aliasClue = state.caseData.clues.find(c => c.id === 'clue-oc-id');
      if (aliasClue) {
        aliasClue.title = `Certified OC ID: ${primary.name || 'Operative'}`;
        aliasClue.x = primary.x !== undefined ? primary.x : aliasClue.x;
        aliasClue.y = primary.y !== undefined ? primary.y : aliasClue.y;
        aliasClue.image = primary.photo || aliasClue.image;
      }
    }
  }

  function updateIdCountBadge() {
    if (dom.idBadgeCount) {
      dom.idBadgeCount.textContent = (state.idCards || []).length;
    }
  }

  function updateFocusNavControls() {
    if (!state.idCards || state.idCards.length === 0) return;
    const total = state.idCards.length;
    const currentIdx = Math.max(0, state.idCards.findIndex(c => c.id === state.activeIdCardId));

    if (dom.idCounterBadge) {
      dom.idCounterBadge.textContent = `CARD ${currentIdx + 1} / ${total}`;
    }

    if (dom.btnPrevId) {
      dom.btnPrevId.disabled = total <= 1;
    }
    if (dom.btnNextId) {
      dom.btnNextId.disabled = total <= 1;
    }
  }

  function syncBoardCardElement(card) {
    if (!card || !card.id) return;
    const cardEl = document.getElementById(`board-pinned-id-${card.id}`);
    if (!cardEl) return;

    const gClass = (card.gender === 'no.b' || card.gender === 'nob') ? 'nob' : (card.gender === 'mal' ? 'mal' : 'fem');
    const setTxt = (sel, val) => {
      const el = cardEl.querySelector(sel);
      if (el) el.textContent = val || '';
    };

    setTxt('.board-txt-creator', card.creator || 'AGENT TIGER');
    setTxt('.board-txt-name', card.name || 'Operative');
    setTxt('.board-txt-birthdate', card.birthdate || '1993 / 10 / 22');
    setTxt('.board-txt-age', card.age || '31');
    setTxt('.board-txt-nationality', card.nationality || 'Visayan / Philippine');
    setTxt('.board-txt-species', card.species || 'Manananggal');
    setTxt('.board-txt-height', card.height || '5\'7" (170cm)');
    setTxt('.board-txt-weight', card.weight || '128 lbs (58kg)');
    setTxt('.board-txt-sexuality', card.sexuality || 'Classified');
    setTxt('.board-txt-signature', card.signature || card.name || 'Signature');
    setTxt('.pinned-id-tag', `OFFICIAL ID // ${(card.name || 'OPERATIVE').toUpperCase()}`);

    const circle = cardEl.querySelector('.board-circle-gender');
    if (circle) circle.className = `oc-id-gender-circle ${gClass} board-circle-gender`;

    const photo = cardEl.querySelector('.board-card-photo');
    if (photo && card.photo) photo.src = card.photo;
  }

  function renderIdCards() {
    if (!dom.boardIdCardsLayer) return;
    dom.boardIdCardsLayer.innerHTML = '';

    (state.idCards || []).forEach((card, index) => {
      if (card.pinned === false) return;

      const cardEl = document.createElement('div');
      cardEl.className = 'board-pinned-id-card';
      cardEl.dataset.cardId = card.id;
      cardEl.id = `board-pinned-id-${card.id}`;
      cardEl.style.left = `${card.x !== undefined ? card.x : (780 + index * 40)}px`;
      cardEl.style.top = `${card.y !== undefined ? card.y : (380 + index * 40)}px`;
      cardEl.style.transform = `rotate(${card.rotation !== undefined ? card.rotation : (index % 2 === 0 ? 2 : -2)}deg)`;
      cardEl.title = `Certified OC ID: ${card.name || 'Operative'} (Click to Focus & Edit)`;

      const gClass = (card.gender === 'no.b' || card.gender === 'nob') ? 'nob' : (card.gender === 'mal' ? 'mal' : 'fem');
      const safeCreator = escapeHtml(card.creator || 'AGENT TIGER');
      const safeName = escapeHtml(card.name || 'Operative');
      const safeBirthdate = escapeHtml(card.birthdate || '1993 / 10 / 22');
      const safeAge = escapeHtml(card.age || '31');
      const safeNationality = escapeHtml(card.nationality || 'Visayan / Philippine');
      const safeSpecies = escapeHtml(card.species || 'Manananggal');
      const safeHeight = escapeHtml(card.height || '5\'7" (170cm)');
      const safeWeight = escapeHtml(card.weight || '128 lbs (58kg)');
      const safeSexuality = escapeHtml(card.sexuality || 'Classified');
      const safeSignature = escapeHtml(card.signature || card.name || 'Signature');
      const photoSrc = card.photo || '/static/images/dossier_agent.jpg';

      cardEl.innerHTML = `
        <div class="pinned-id-tape"></div>
        <div class="clue-pin" data-clue-id="clue-oc-id-${card.id}" title="Pin: ${safeName} (Click to tie red yarn)"></div>
        <div class="oc-id-card-render">
          <img src="/static/images/oc_id_template.png" class="oc-id-bg-img" alt="Official OC ID Card">
          <div class="oc-id-photo-box">
            <img src="${photoSrc}" alt="Portrait" class="board-card-photo">
          </div>
          <div class="oc-id-field-creator board-txt-creator">${safeCreator}</div>
          <div class="oc-id-field-name board-txt-name">${safeName}</div>
          <div class="oc-id-field-birthdate board-txt-birthdate">${safeBirthdate}</div>
          <div class="oc-id-field-age board-txt-age">${safeAge}</div>
          <div class="oc-id-field-nationality board-txt-nationality">${safeNationality}</div>
          <div class="oc-id-field-species board-txt-species">${safeSpecies}</div>
          <div class="oc-id-gender-circle ${gClass} board-circle-gender"></div>
          <div class="oc-id-field-height board-txt-height">${safeHeight}</div>
          <div class="oc-id-field-weight board-txt-weight">${safeWeight}</div>
          <div class="oc-id-field-sexuality board-txt-sexuality">${safeSexuality}</div>
          <div class="oc-id-field-signature board-txt-signature">${safeSignature}</div>
        </div>
        <div class="pinned-id-tag">OFFICIAL ID // ${safeName.toUpperCase()}</div>
      `;

      setupIndividualIdCard(cardEl, card);
      dom.boardIdCardsLayer.appendChild(cardEl);
    });

    invalidatePinCache();
    requestRenderStrings();
  }

  function setupIndividualIdCard(cardEl, card) {
    const pin = cardEl.querySelector('.clue-pin');
    const clueId = `clue-oc-id-${card.id}`;
    let ocClue = (state.caseData?.clues || []).find(c => c.id === clueId) || {
      id: clueId,
      title: `Certified OC ID: ${card.name || 'Operative'}`,
      category: 'Suspect',
      x: card.x,
      y: card.y,
      width: 320,
      height: 240
    };

    if (pin) {
      pin.onclick = (e) => {
        e.stopPropagation();
        handlePinClick(ocClue, pin);
      };
    }

    let startX = 0, startY = 0, moved = false;
    let cardStartLeft = 0, cardStartTop = 0;

    const baseRot = card.rotation !== undefined ? card.rotation : 0;
    const swing = (window.SwingPhysics) ? window.SwingPhysics.create({
      element: cardEl,
      baseRotation: baseRot,
      pivotX: '50%',
      pivotY: '18px',
      maxAngle: 18,
      sensitivity: 0.014,
      liftScale: 1.055
    }) : null;
    cardEl._swingPhysics = swing;

    cardEl.onpointerdown = (e) => {
      if (e.target === pin || e.target.closest('.clue-pin') || e.target.closest('.placed-evidence-pin')) return;

      // If pinned to stay put: allow click to open Focus mode, but prevent dragging!
      if (cardEl.dataset.stayPut === 'true' || cardEl.classList.contains('pinned-stay-put') || cardEl.querySelector('.placed-evidence-pin')) {
        const startX = e.clientX;
        const startY = e.clientY;
        const onPinnedIdUp = (upEv) => {
          window.removeEventListener('pointerup', onPinnedIdUp);
          const dist = Math.hypot(upEv.clientX - startX, upEv.clientY - startY);
          if (dist < 6) {
            enterIdFocusMode(card.id);
          } else {
            playPinTugFeedback(cardEl);
          }
        };
        window.addEventListener('pointerup', onPinnedIdUp);
        return;
      }

      if (state.isStringToolActive) {
        handlePinClick(ocClue, pin);
        return;
      }

      if (window.PaperAudio) window.PaperAudio.tap(0.85, 'card');
      if (swing) swing.pickup(e.clientX, e.clientY);

      startX = e.clientX;
      startY = e.clientY;
      moved = false;

      const surfaceRect = getSurfaceRect();
      const cardRect = cardEl.getBoundingClientRect();
      cardStartLeft = cardRect.left - surfaceRect.left;
      cardStartTop = cardRect.top - surfaceRect.top;

      const curPin = getPinCoordinates(clueId, true);
      const idPinRelX = curPin.x - cardStartLeft;
      const idPinRelY = curPin.y - cardStartTop;
      let idDragRaf = null;

      cardEl.classList.add('dragging');
      if (dom.boardTrashBin) {
        dom.boardTrashBin.classList.add('is-drag-active');
      }

      try {
        cardEl.setPointerCapture(e.pointerId);
      } catch (_) {}

      const onPointerMove = (ev) => {
        const dx = ev.clientX - startX;
        const dy = ev.clientY - startY;
        if (Math.hypot(dx, dy) > 5) {
          moved = true;
          cardEl.classList.add('dragging');

          if (swing) swing.move(ev.clientX, ev.clientY);

          if (window.PaperAudio) {
            window.PaperAudio.handleDragMotion(ev.movementX || 6, ev.movementY || 6);
          }

          // Check trash collision for ID card
          const isOverTrash = checkTrashCollision(ev.clientX, ev.clientY, cardEl.getBoundingClientRect());
          if (dom.boardTrashBin) {
            dom.boardTrashBin.classList.toggle('drag-over', isOverTrash);
          }
          cardEl.classList.toggle('over-trash', isOverTrash);

          let newX = cardStartLeft + dx;
          let newY = cardStartTop + dy;

          const sRect = getSurfaceRect();
          const boardW = sRect.width;
          const boardH = sRect.height;

          const cardW = cardEl.offsetWidth || 320;
          const cardH = cardEl.offsetHeight || 240;

          // Constrain dynamically to full board width and height
          newX = Math.max(10, Math.min(boardW - cardW - 10, newX));
          newY = Math.max(10, Math.min(boardH - cardH - 10, newY));

          const roundedX = Math.round(newX);
          const roundedY = Math.round(newY);

          card.x = roundedX;
          card.y = roundedY;
          ocClue.x = roundedX;
          ocClue.y = roundedY;

          pinCoordsCache.set(clueId, {
            x: roundedX + idPinRelX,
            y: roundedY + idPinRelY
          });
          if (card.id === state.idCards[0]?.id) {
            pinCoordsCache.set('clue-oc-id', {
              x: roundedX + idPinRelX,
              y: roundedY + idPinRelY
            });
          }

          if (!idDragRaf) {
            idDragRaf = requestAnimationFrame(() => {
              cardEl.style.left = `${roundedX}px`;
              cardEl.style.top = `${roundedY}px`;
              renderStrings();
              idDragRaf = null;
            });
          }
        }
      };

      const onPointerUp = async (ev) => {
        if (idDragRaf) {
          cancelAnimationFrame(idDragRaf);
          idDragRaf = null;
        }
        try {
          cardEl.releasePointerCapture(e.pointerId);
        } catch (_) {}
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
        cardEl.classList.remove('dragging', 'over-trash');
        if (dom.boardTrashBin) {
          dom.boardTrashBin.classList.remove('is-drag-active', 'drag-over');
        }
        if (swing) swing.drop();

        cardEl.style.left = `${card.x}px`;
        cardEl.style.top = `${card.y}px`;

        if (!moved) {
          // Clicked card: Open Cinematic ID Focus Mode focused on THIS card!
          if (window.PaperAudio) window.PaperAudio.tap(1.0, 'card');
          enterIdFocusMode(card.id);
        } else {
          // Check if dropped into the Trash Bin!
          const isOverTrash = checkTrashCollision(ev.clientX, ev.clientY, cardEl.getBoundingClientRect());
          if (isOverTrash) {
            await incinerateIdCard(card, cardEl);
            return;
          }

          // Finished dragging
          if (window.PaperAudio) window.PaperAudio.drop({ type: 'card' });
          else playPaperThud();
          invalidatePinCache(clueId);
          if (card.id === state.idCards[0]?.id) {
            invalidatePinCache('clue-oc-id');
          }
          requestRenderStrings();
          saveIdCard(card, false);
        }
      };

      cardEl.onpointercancel = () => {
        if (idDragRaf) {
          cancelAnimationFrame(idDragRaf);
          idDragRaf = null;
        }
        cardEl.classList.remove('dragging', 'over-trash');
        if (dom.boardTrashBin) {
          dom.boardTrashBin.classList.remove('is-drag-active', 'drag-over');
        }
        if (swing) swing.cancel();
      };

      window.addEventListener('pointermove', onPointerMove);
      window.addEventListener('pointerup', onPointerUp);
    };
  }

  function updateIdCardDisplays() {
    if (!state.idCard) {
      if (state.idCards && state.idCards.length > 0) {
        state.idCard = state.idCards.find(c => c.id === state.activeIdCardId) || state.idCards[0];
      }
    }
    if (!state.idCard) return;
    const card = state.idCard;

    // Gender class
    const gClass = (card.gender === 'no.b' || card.gender === 'nob') ? 'nob' : (card.gender === 'mal' ? 'mal' : 'fem');

    // Update Focused Hero Card Displays
    const setFocusTxt = (id, val) => {
      const el = document.getElementById(id);
      if (el && document.activeElement !== el) {
        el.textContent = val || '';
      }
    };

    setFocusTxt('focused-id-creator', card.creator || 'AGENT TIGER');
    setFocusTxt('focused-id-name', card.name || 'Maria Tala Esperanza');
    setFocusTxt('focused-id-birthdate', card.birthdate || '1993 / 10 / 22');
    setFocusTxt('focused-id-age', card.age || '31');
    setFocusTxt('focused-id-nationality', card.nationality || 'Visayan / Philippine');
    setFocusTxt('focused-id-species', card.species || 'Manananggal');
    setFocusTxt('focused-id-height', card.height || '5\'7" (170cm)');
    setFocusTxt('focused-id-weight', card.weight || '128 lbs (58kg)');
    setFocusTxt('focused-id-sexuality', card.sexuality || 'Classified / Bi');
    setFocusTxt('focused-id-signature', card.signature || card.name || 'M. Tala Esperanza');

    if (dom.focusedIdGenderCircle) {
      dom.focusedIdGenderCircle.className = `oc-id-gender-circle ${gClass}`;
    }

    if (dom.focusedIdPhotoDisplay) {
      dom.focusedIdPhotoDisplay.src = card.photo || '/static/images/dossier_agent.jpg';
    }

    // Also sync board card element for active card
    syncBoardCardElement(card);
    updateFocusNavControls();
  }

  // Enter Cinematic ID Focus Mode
  function enterIdFocusMode(targetCardId) {
    if (!dom.idFocusStage) return;

    if (targetCardId) {
      state.activeIdCardId = targetCardId;
      state.idCard = (state.idCards || []).find(c => c.id === targetCardId) || state.idCards[0];
    } else if (!state.idCard && state.idCards && state.idCards.length > 0) {
      state.activeIdCardId = state.idCards[0].id;
      state.idCard = state.idCards[0];
    }

    updateIdCardDisplays();
    updateFocusNavControls();

    // Reset card flip to front face
    state.isIdCardFlipped = false;
    if (dom.idCardFlipper) {
      dom.idCardFlipper.classList.remove('is-flipped');
    }

    // Close any open avatar popover
    if (dom.idAvatarPopover) {
      dom.idAvatarPopover.classList.add('hidden');
    }

    // Show stage and activate focus mode on body (smoothly hides HUD & status bar, blurs desk)
    document.body.classList.add('id-focus-active');
    dom.idFocusStage.classList.remove('hidden');

    playCameraFocusSound();

    const deskCard = state.activeIdCardId ? document.getElementById(`board-pinned-id-${state.activeIdCardId}`) : null;
    const viewport = dom.idCardViewport;

    // Compute FLIP transform from desk card coordinates
    if (deskCard && viewport) {
      try {
        const startRect = deskCard.getBoundingClientRect();
        const endRect = viewport.getBoundingClientRect();

        if (startRect.width > 0 && endRect.width > 0) {
          const scale = startRect.width / endRect.width;
          const dx = (startRect.left + startRect.width / 2) - (endRect.left + endRect.width / 2);
          const dy = (startRect.top + startRect.height / 2) - (endRect.top + endRect.height / 2);

          viewport.style.transition = 'none';
          viewport.style.transform = `translate(${dx.toFixed(1)}px, ${dy.toFixed(1)}px) scale(${scale.toFixed(3)}) rotate(2deg)`;
          viewport.style.opacity = '0.9';

          void viewport.offsetHeight; // Force browser reflow

          requestAnimationFrame(() => {
            viewport.style.transition = 'transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.25s ease';
            viewport.style.transform = 'translate(0px, 0px) scale(1) rotate(0deg)';
            viewport.style.opacity = '1';

            setTimeout(() => {
              if (document.body.classList.contains('id-focus-active') && viewport) {
                viewport.style.transition = 'none';
              }
            }, 380);
          });
        }
      } catch (err) {
        viewport.style.transform = '';
        viewport.style.opacity = '1';
      }
    }

    setupLucideIcons();
  }

  // Exit Cinematic ID Focus Mode
  function exitIdFocusMode() {
    try {
      playPaperThud();
    } catch (_) {}

    document.body.classList.remove('id-focus-active');

    if (dom.idFocusStage) {
      dom.idFocusStage.classList.add('hidden');
    }
    if (dom.idAvatarPopover) {
      dom.idAvatarPopover.classList.add('hidden');
    }
    if (dom.idMakerModal) {
      dom.idMakerModal.classList.add('hidden');
    }

    if (dom.idCardViewport) {
      dom.idCardViewport.style.transform = '';
      dom.idCardViewport.style.transition = '';
      dom.idCardViewport.style.opacity = '';
    }
    if (dom.cardLaminateGlare) {
      dom.cardLaminateGlare.style.transform = 'translate3d(0, 0, 0)';
    }
    if (dom.idCardFlipper) {
      dom.idCardFlipper.classList.remove('is-flipped');
    }
    state.isIdCardFlipped = false;

    // Ensure no dragging state remains on pinned cards
    document.querySelectorAll('.board-pinned-id-card.dragging').forEach(el => el.classList.remove('dragging'));

    try {
      if (state.idCard) {
        saveIdCard(state.idCard, false);
      }
      renderIdCards();
      renderStrings();
    } catch (e) {
      console.warn('Sync on exit:', e);
    }
  }

  function toggleIdCardFlip() {
    state.isIdCardFlipped = !state.isIdCardFlipped;
    if (dom.idCardFlipper) {
      dom.idCardFlipper.classList.toggle('is-flipped', state.isIdCardFlipped);
    }
    playCardFlipSound();
  }

  function navigateIdCard(direction) {
    if (!state.idCards || state.idCards.length <= 1) return;
    const currentIdx = state.idCards.findIndex(c => c.id === state.activeIdCardId);
    let newIdx = (currentIdx === -1 ? 0 : currentIdx) + direction;
    if (newIdx < 0) newIdx = state.idCards.length - 1;
    if (newIdx >= state.idCards.length) newIdx = 0;

    const nextCard = state.idCards[newIdx];
    if (nextCard) {
      playCardFlipSound();
      if (dom.idCardViewport) {
        dom.idCardViewport.style.transition = 'transform 0.18s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.18s';
        dom.idCardViewport.style.transform = `scale(0.92) translateX(${direction > 0 ? '-30px' : '30px'})`;
        dom.idCardViewport.style.opacity = '0.4';

        setTimeout(() => {
          state.activeIdCardId = nextCard.id;
          state.idCard = nextCard;
          updateIdCardDisplays();

          dom.idCardViewport.style.transform = 'scale(1) translateX(0px)';
          dom.idCardViewport.style.opacity = '1';

          setTimeout(() => {
            if (dom.idCardViewport && document.body.classList.contains('id-focus-active')) {
              dom.idCardViewport.style.transition = 'none';
            }
          }, 200);
        }, 140);
      } else {
        state.activeIdCardId = nextCard.id;
        state.idCard = nextCard;
        updateIdCardDisplays();
      }
    }
  }

  async function createNewIdCard() {
    playPaperThud();
    const count = (state.idCards || []).length;
    const newId = 'oc-id-' + Date.now();
    const sRect = getSurfaceRect();
    const boardW = sRect.width || 1400;

    const offsetX = (count * 45) % Math.max(200, boardW - 500);
    const offsetY = (count * 35) % 250;

    const randomNames = ['Solana Cruz', 'Dante Villanueva', 'Amihan Silang', 'Kael Del Fierro', 'Luzviminda Esperanza', 'Joaquin Alcantara', 'Echo Nightshade', 'Rosario Alcantara', 'Mateo Silang'];
    const chosenName = randomNames[count % randomNames.length] || `Operative ${count + 1}`;

    const newCard = {
      id: newId,
      creator: 'AGENT TIGER',
      name: chosenName,
      birthdate: '1996 / 08 / 14',
      age: '28',
      nationality: 'Visayan / Philippine',
      species: 'Manananggal',
      gender: 'fem',
      height: '5\'6" (168cm)',
      weight: '124 lbs (56kg)',
      sexuality: 'Classified',
      signature: chosenName,
      photo: '/static/images/dossier_agent.jpg',
      pinned: true,
      x: Math.min(840 + offsetX, boardW - 360),
      y: 220 + offsetY,
      rotation: Math.floor(Math.random() * 6) - 3
    };

    if (!state.idCards) state.idCards = [];
    state.idCards.push(newCard);
    state.activeIdCardId = newId;
    state.idCard = newCard;

    syncIdCardClues();
    updateIdCountBadge();
    renderIdCards();

    // Persist to server
    await saveIdCard(newCard, false);

    // Open Cinematic Focus Mode directly on the newly created card!
    enterIdFocusMode(newId);
  }

  async function deleteActiveIdCard() {
    if (!state.activeIdCardId) return;
    const cardId = state.activeIdCardId;
    const card = (state.idCards || []).find(c => c.id === cardId);
    const cardName = card ? card.name : 'this ID card';

    if (state.idCards.length <= 1) {
      if (confirm(`Reset "${cardName}" to a blank template? (At least one official ID card must remain in the archive)`)) {
        if (card) {
          card.creator = 'AGENT TIGER';
          card.name = 'New Operative';
          card.birthdate = '2000 / 01 / 01';
          card.age = '24';
          card.nationality = 'Visayan / Philippine';
          card.species = 'Manananggal';
          card.gender = 'fem';
          card.height = '5\'6" (168cm)';
          card.weight = '125 lbs (57kg)';
          card.sexuality = 'Classified';
          card.signature = 'New Operative';
          card.photo = '/static/images/dossier_agent.jpg';
          await saveIdCard(card, false);
          updateIdCardDisplays();
          renderIdCards();
          playStampSound();
        }
      }
      return;
    }

    if (!confirm(`Delete ID card for "${cardName}"? This will unpin it from the board and remove its connections.`)) {
      return;
    }

    try {
      if (window.PaperAudio) window.PaperAudio.crumple('heavy');
      playStringSnapSound();
      const res = await fetch('/api/id_cards', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: cardId })
      });
      const data = await res.json();
      if (data.success) {
        state.idCards = (state.idCards || []).filter(c => c.id !== cardId);

        // Remove associated clue and connections from state
        const clueId = `clue-oc-id-${cardId}`;
        if (state.caseData) {
          state.caseData.clues = (state.caseData.clues || []).filter(c => c.id !== clueId);
          state.caseData.connections = (state.caseData.connections || []).filter(c => c.from !== clueId && c.to !== clueId);
        }

        // Set next active card
        const nextCard = state.idCards[0];
        state.activeIdCardId = nextCard.id;
        state.idCard = nextCard;

        syncIdCardClues();
        updateIdCountBadge();
        renderIdCards();
        updateIdCardDisplays();
        updateStatusHeader();
      }
    } catch (err) {
      console.error('Failed to delete ID card:', err);
    }
  }

  function openIdMakerModal() {
    createNewIdCard();
  }

  function closeIdMakerModal() {
    exitIdFocusMode();
  }

  async function saveIdCard(cardObj, notify = true) {
    const card = cardObj && cardObj.id ? cardObj : (state.idCard || state.idCards[0]);
    if (!card) return;

    try {
      const res = await fetch('/api/id_card', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(card)
      });
      const data = await res.json();
      if (data.success) {
        if (data.idCards) state.idCards = data.idCards;
        if (data.idCard && data.idCard.id === card.id) {
          Object.assign(card, data.idCard);
        }
        syncIdCardClues();
        syncBoardCardElement(card);
        renderStrings();
        if (notify) {
          playPinSound();
        }
      }
    } catch (e) {
      console.error('Failed to save ID card:', e);
    }
  }

  function generateRandomOc() {
    const creators = ['AGENT TIGER', 'ARCHIVIST ZERO', 'OPERATIVE 1999', 'WATCHER-7', 'BUREAU 8920', 'DETECTIVE MAZA'];
    const firstNamesFem = ['Maria Tala', 'Corazon', 'Luzviminda', 'Amihan', 'Sinag', 'Rosario', 'Mariposa', 'Solana', 'Elena', 'Carmela'];
    const firstNamesMal = ['Dante', 'Ignacio', 'Mateo', 'Crisostomo', 'Alon', 'Bayani', 'Joaquin', 'Ramon', 'Valerio', 'Esteban'];
    const firstNamesNob = ['Echo', 'Zephyr', 'Orion', 'Kael', 'Tadhana', 'Lihim', 'Soberano', 'Nova', 'River', 'Sulu'];
    const lastNames = ['Esperanza', 'Dimagiba', 'Cruz', 'Alcantara', 'Soliman', 'Villanueva', 'Nightshade', 'Del Fierro', 'Silang', 'Bautista'];
    
    const genders = ['fem', 'mal', 'no.b'];
    const selectedGender = genders[Math.floor(Math.random() * genders.length)];
    
    let chosenFirst = firstNamesFem;
    if (selectedGender === 'mal') chosenFirst = firstNamesMal;
    if (selectedGender === 'no.b') chosenFirst = firstNamesNob;

    const firstName = chosenFirst[Math.floor(Math.random() * chosenFirst.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    const fullName = `${firstName} ${lastName}`;

    const speciesList = ['Manananggal', 'Tikbalang Hybrid', 'Aswang Infiltrator', 'Arcane Diviner', 'Diwata Envoy', 'Engkanto Diplomat', 'Half-Mortal Alchemist', 'Kapre Wardkeeper', 'Sirena Telepath'];
    const origins = ['Visayan / Philippine', 'Siquijor Archival Sanctum', 'Ilocos Ridge / Philippine', 'Bicol Volcanic Ward', 'Manila Underground', 'Cebu Talisay Outpost', 'Kensington Bureau / London', 'Batanes Stormwatch'];
    const sexualities = ['Classified / Bi', 'Secret / Pan', 'Lesbian', 'Gay', 'Asexual / Arcane', 'Demisexual', 'Undisclosed'];

    const birthYear = 1960 + Math.floor(Math.random() * 35);
    const birthMonth = String(1 + Math.floor(Math.random() * 12)).padStart(2, '0');
    const birthDay = String(1 + Math.floor(Math.random() * 28)).padStart(2, '0');
    const age = 1999 - birthYear;

    const feet = 5 + Math.floor(Math.random() * 2);
    const inches = Math.floor(Math.random() * 12);
    const cm = Math.round((feet * 12 + inches) * 2.54);
    const weightLbs = 110 + Math.floor(Math.random() * 85);
    const weightKg = Math.round(weightLbs * 0.453592);

    const photos = [
      '/static/images/dossier_agent.jpg',
      '/static/images/creature_polaroid.png',
      '/static/images/umbrella.jpg',
      '/static/images/sighting_log.png',
      '/static/images/bureau_id_card.png',
      '/static/images/manananggal_red_dossier.png'
    ];
    const photo = photos[Math.floor(Math.random() * photos.length)];

    if (!state.idCard) state.idCard = {};
    state.idCard.creator = creators[Math.floor(Math.random() * creators.length)];
    state.idCard.name = fullName;
    state.idCard.birthdate = `${birthYear} / ${birthMonth} / ${birthDay}`;
    state.idCard.age = String(age);
    state.idCard.nationality = origins[Math.floor(Math.random() * origins.length)];
    state.idCard.species = speciesList[Math.floor(Math.random() * speciesList.length)];
    state.idCard.gender = selectedGender;
    state.idCard.height = `${feet}'${inches}" (${cm}cm)`;
    state.idCard.weight = `${weightLbs} lbs (${weightKg}kg)`;
    state.idCard.sexuality = sexualities[Math.floor(Math.random() * sexualities.length)];
    state.idCard.signature = `${firstName.split(' ')[0]}. ${lastName}`;
    state.idCard.photo = photo;

    // Sync in state.idCards list as well
    const cardInList = (state.idCards || []).find(c => c.id === state.idCard.id);
    if (cardInList) {
      Object.assign(cardInList, state.idCard);
    }

    updateIdCardDisplays();
    saveIdCard(state.idCard, false);
    playPinSound();
  }

  async function downloadIdCardPng() {
    if (!state.idCard) return;
    const card = state.idCard;

    const canvas = document.createElement('canvas');
    canvas.width = 705;
    canvas.height = 432;
    const ctx = canvas.getContext('2d');

    // 1. Load background template image
    const templateImg = new Image();
    templateImg.crossOrigin = 'anonymous';

    await new Promise((resolve) => {
      templateImg.onload = resolve;
      templateImg.onerror = () => {
        console.warn('Template failed to load for canvas');
        resolve();
      };
      templateImg.src = '/static/images/oc_id_template.png';
    });

    if (templateImg.complete && templateImg.naturalWidth > 0) {
      ctx.drawImage(templateImg, 0, 0, 705, 432);
    } else {
      ctx.fillStyle = '#e7dfd1';
      ctx.fillRect(0, 0, 705, 432);
    }

    // 2. Load and draw OC photo inside photo box [34, 55, 252, 256]
    if (card.photo) {
      const photoImg = new Image();
      photoImg.crossOrigin = 'anonymous';
      await new Promise((resolve) => {
        photoImg.onload = resolve;
        photoImg.onerror = resolve;
        photoImg.src = card.photo;
      });

      if (photoImg.complete && photoImg.naturalWidth > 0) {
        ctx.save();
        ctx.beginPath();
        ctx.rect(34, 55, 252, 256);
        ctx.clip();

        const pRatio = photoImg.naturalWidth / photoImg.naturalHeight;
        const boxRatio = 252 / 256;
        let dw, dh, dx, dy;
        if (pRatio > boxRatio) {
          dh = 256;
          dw = 256 * pRatio;
          dx = 34 - (dw - 252) / 2;
          dy = 55;
        } else {
          dw = 252;
          dh = 252 / pRatio;
          dx = 34;
          dy = 55 - (dh - 256) / 2;
        }
        ctx.drawImage(photoImg, dx, dy, dw, dh);
        ctx.restore();
      }
    }

    // 3. Render typed text fields
    ctx.fillStyle = '#1a1614';
    ctx.textBaseline = 'alphabetic';

    // Creator
    ctx.font = 'bold 12px "Courier Prime", monospace';
    ctx.fillText(card.creator || 'AGENT TIGER', 125, 44);

    // Name
    ctx.font = 'bold 16px "Courier Prime", monospace';
    ctx.fillText(card.name || '', 358, 133);

    // Birthdate & Age
    ctx.font = 'bold 14px "Courier Prime", monospace';
    ctx.fillText(card.birthdate || '', 405, 168);
    ctx.fillText(card.age || '', 578, 168);

    // Nationality
    ctx.fillText(card.nationality || '', 425, 203);

    // Species
    ctx.fillText(card.species || '', 380, 233);

    // Gender hand-drawn red ink circle
    ctx.save();
    ctx.strokeStyle = '#b91c1c';
    ctx.lineWidth = 2.4;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    let circleX = 533, circleY = 227, radiusX = 23, radiusY = 14;
    if (card.gender === 'mal') {
      circleX = 592;
      circleY = 227;
      radiusX = 23;
      radiusY = 14;
    } else if (card.gender === 'no.b' || card.gender === 'nob') {
      circleX = 648;
      circleY = 227;
      radiusX = 26;
      radiusY = 14;
    }
    ctx.beginPath();
    ctx.ellipse(circleX, circleY, radiusX, radiusY, -0.06, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.restore();

    // Height & Weight
    ctx.font = 'bold 14px "Courier Prime", monospace';
    ctx.fillText(card.height || '', 384, 266);
    ctx.fillText(card.weight || '', 578, 266);

    // Sexuality
    ctx.fillText(card.sexuality || '', 405, 303);

    // Signature (Caveat handwriting style)
    ctx.save();
    ctx.translate(145, 362);
    ctx.rotate(-0.06);
    ctx.font = 'bold 26px "Caveat", cursive, serif';
    ctx.fillStyle = '#0f172a';
    ctx.textAlign = 'center';
    ctx.fillText(card.signature || card.name || '', 0, 0);
    ctx.restore();

    // 4. Download file
    try {
      const dataUrl = canvas.toDataURL('image/png');
      const safeName = (card.name || 'OC').replace(/[^a-zA-Z0-9_-]/g, '_');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `CERTIFIED_OC_ID_${safeName}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      playPinSound();
    } catch (err) {
      console.error('PNG download error:', err);
    }
  }

  function setupIdMakerEvents() {
    // Desk "Make ID" button creates a new ID card directly or focuses first card if shift clicked
    if (dom.btnMakeId) {
      dom.btnMakeId.addEventListener('click', (e) => {
        if (state.idCards && state.idCards.length > 0 && e.shiftKey) {
          enterIdFocusMode(state.idCards[0].id);
        } else {
          createNewIdCard();
        }
      });
    }

    // New ID button inside focus toolbar
    if (dom.btnFocusNewId) {
      dom.btnFocusNewId.addEventListener('click', () => {
        createNewIdCard();
      });
    }

    // Delete ID button inside focus toolbar
    if (dom.btnFocusDeleteId) {
      dom.btnFocusDeleteId.addEventListener('click', () => {
        deleteActiveIdCard();
      });
    }

    // Prev / Next ID navigation in focus header
    if (dom.btnPrevId) {
      dom.btnPrevId.addEventListener('click', () => {
        navigateIdCard(-1);
      });
    }
    if (dom.btnNextId) {
      dom.btnNextId.addEventListener('click', () => {
        navigateIdCard(1);
      });
    }

    // Close Cinematic ID Focus Mode
    if (dom.btnFocusXClose) {
      dom.btnFocusXClose.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        exitIdFocusMode();
      });
    }
    if (dom.btnExitIdFocus) {
      dom.btnExitIdFocus.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        exitIdFocusMode();
      });
    }
    if (dom.idFocusBackdrop) {
      dom.idFocusBackdrop.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        exitIdFocusMode();
      });
    }
    if (dom.btnFocusDone) {
      dom.btnFocusDone.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        exitIdFocusMode();
      });
    }
    if (dom.idFocusStage) {
      dom.idFocusStage.addEventListener('click', (e) => {
        if (e.target === dom.idFocusStage || e.target === dom.idFocusBackdrop || e.target === dom.idCardViewport) {
          exitIdFocusMode();
        }
      });
    }

    // 3D Card Flip Controls
    if (dom.btnFlipCardTop) {
      dom.btnFlipCardTop.addEventListener('click', toggleIdCardFlip);
    }
    if (dom.btnFocusFlip) {
      dom.btnFocusFlip.addEventListener('click', toggleIdCardFlip);
    }

    // Biometric Thumbprint stamp on card back
    if (dom.cardThumbprintBox) {
      dom.cardThumbprintBox.addEventListener('click', () => {
        playStampSound();
        if (dom.cardThumbprintMark) {
          dom.cardThumbprintMark.classList.remove('stamp-anim');
          void dom.cardThumbprintMark.offsetWidth; // Force reflow
          dom.cardThumbprintMark.classList.add('stamp-anim');
        }
      });
    }

    // Avatar / Portrait Selection Popover
    const toggleAvatarPopover = (e) => {
      e?.stopPropagation();
      if (!dom.idAvatarPopover) return;
      const isHidden = dom.idAvatarPopover.classList.contains('hidden');
      if (isHidden) {
        dom.idAvatarPopover.classList.remove('hidden');
        playPaperThud();
      } else {
        dom.idAvatarPopover.classList.add('hidden');
      }
    };

    if (dom.btnFocusPhoto) {
      dom.btnFocusPhoto.addEventListener('click', toggleAvatarPopover);
    }
    if (dom.focusedPhotoBox) {
      dom.focusedPhotoBox.addEventListener('click', toggleAvatarPopover);
    }
    if (dom.btnCloseAvatarPopover) {
      dom.btnCloseAvatarPopover.addEventListener('click', (e) => {
        e.stopPropagation();
        dom.idAvatarPopover?.classList.add('hidden');
      });
    }

    // Avatar Presets inside Popover
    document.querySelectorAll('#id-avatar-popover .avatar-option').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (!state.idCard) state.idCard = {};
        state.idCard.photo = btn.dataset.src;
        const inList = (state.idCards || []).find(c => c.id === state.idCard.id);
        if (inList) inList.photo = btn.dataset.src;
        updateIdCardDisplays();
        saveIdCard(state.idCard, false);
        playCameraFocusSound();

        // Flash photo box feedback
        if (dom.focusedPhotoBox) {
          dom.focusedPhotoBox.style.filter = 'brightness(1.8)';
          setTimeout(() => {
            dom.focusedPhotoBox.style.filter = '';
          }, 180);
        }

        if (dom.idAvatarPopover) {
          dom.idAvatarPopover.classList.add('hidden');
        }
      });
    });

    // Custom Photo Upload from Focus Mode using resilient FileReader
    if (dom.btnFocusTriggerUpload && dom.focusOcPhotoFile) {
      dom.btnFocusTriggerUpload.addEventListener('click', (e) => {
        e.stopPropagation();
        dom.focusOcPhotoFile.click();
      });
    }

    if (dom.focusOcPhotoFile) {
      dom.focusOcPhotoFile.addEventListener('change', (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = async (ev) => {
          const dataUrl = ev.target.result;
          if (state.idCard) {
            state.idCard.photo = dataUrl;
            const inList = (state.idCards || []).find(c => c.id === state.idCard.id);
            if (inList) inList.photo = dataUrl;
            updateIdCardDisplays();
            syncBoardCardElement(state.idCard);
            await saveIdCard(state.idCard, false);
            playCameraFocusSound();
            if (dom.idAvatarPopover) dom.idAvatarPopover.classList.add('hidden');
          }
        };
        reader.readAsDataURL(file);
      });
    }

    // Gender Stamp Click Targets on Focused Card
    document.querySelectorAll('.gender-stamp-target').forEach(target => {
      target.addEventListener('click', (e) => {
        e.stopPropagation();
        const gender = target.dataset.gender;
        if (!state.idCard) state.idCard = {};
        state.idCard.gender = gender;
        const inList = (state.idCards || []).find(c => c.id === state.idCard.id);
        if (inList) inList.gender = gender;

        const gClass = (gender === 'no.b' || gender === 'nob') ? 'nob' : (gender === 'mal' ? 'mal' : 'fem');
        if (dom.focusedIdGenderCircle) {
          dom.focusedIdGenderCircle.className = `oc-id-gender-circle ${gClass} stamp-anim`;
        }

        playStampSound();
        updateIdCardDisplays();
        saveIdCard(state.idCard, false);
      });
    });

    // Direct In-Place Text Editing on the Focused Hero Card
    let isEditingInlineField = false;
    const editableCardFields = document.querySelectorAll('.card-inline-edit');

    editableCardFields.forEach(el => {
      el.addEventListener('focus', () => {
        isEditingInlineField = true;
        if (dom.idCardViewport) {
          dom.idCardViewport.style.transform = 'rotateX(0deg) rotateY(0deg)';
        }
      });

      el.addEventListener('blur', () => {
        isEditingInlineField = false;
        const field = el.dataset.field;
        if (field && state.idCard) {
          state.idCard[field] = el.textContent.trim();
          const inList = (state.idCards || []).find(c => c.id === state.idCard.id);
          if (inList) inList[field] = state.idCard[field];
          syncBoardCardElement(state.idCard);
          saveIdCard(state.idCard, false);
        }
      });

      el.addEventListener('keydown', (e) => {
        playTypewriterKey();
        if (e.key === 'Enter') {
          e.preventDefault();
          el.blur();
        } else if (e.key === 'Escape') {
          el.blur();
        }
      });

      el.addEventListener('input', () => {
        const field = el.dataset.field;
        if (field) {
          if (!state.idCard) state.idCard = {};
          state.idCard[field] = el.textContent;

          // If updating name, sync signature if not customized
          if (field === 'name' && (!state.idCard.signature || state.idCard.signature === 'Maria Tala Esperanza')) {
            state.idCard.signature = el.textContent;
            const sigEl = document.getElementById('focused-id-signature');
            if (sigEl && document.activeElement !== sigEl) {
              sigEl.textContent = el.textContent;
            }
          }

          const inList = (state.idCards || []).find(c => c.id === state.idCard.id);
          if (inList) {
            inList[field] = el.textContent;
            if (field === 'name') inList.signature = state.idCard.signature;
          }

          syncBoardCardElement(state.idCard);

          clearTimeout(state.idCardSaveTimer);
          state.idCardSaveTimer = setTimeout(() => {
            saveIdCard(state.idCard, false);
          }, 600);
        }
      });
    });

    // 3D Parallax Tilt & Specular Lamination Sheen Tracking (RAF throttled)
    if (dom.idFocusStage) {
      let tiltRafId = null;
      let lastX = 0, lastY = 0;

      dom.idFocusStage.addEventListener('mousemove', (e) => {
        if (isEditingInlineField) return;
        if (!dom.idCardViewport || !document.body.classList.contains('id-focus-active') || dom.idFocusStage.classList.contains('hidden')) return;

        lastX = e.clientX;
        lastY = e.clientY;

        if (tiltRafId) return;

        tiltRafId = requestAnimationFrame(() => {
          tiltRafId = null;
          if (!dom.idCardViewport || !document.body.classList.contains('id-focus-active')) return;

          const normX = (lastX / window.innerWidth) - 0.5;
          const normY = (lastY / window.innerHeight) - 0.5;
          const rotX = (-normY * 13).toFixed(1);
          const rotY = (normX * 15).toFixed(1);

          dom.idCardViewport.style.transition = 'none';
          dom.idCardViewport.style.transform = `rotateX(${rotX}deg) rotateY(${rotY}deg)`;

          if (dom.cardLaminateGlare) {
            const gx = (normX * 45).toFixed(1);
            const gy = (normY * 45).toFixed(1);
            dom.cardLaminateGlare.style.transform = `translate3d(${gx}px, ${gy}px, 0)`;
          }
        });
      }, { passive: true });

      dom.idFocusStage.addEventListener('mouseleave', () => {
        if (tiltRafId) {
          cancelAnimationFrame(tiltRafId);
          tiltRafId = null;
        }
        if (dom.idCardViewport) {
          dom.idCardViewport.style.transition = 'transform 0.4s cubic-bezier(0.16, 1, 0.3, 1)';
          dom.idCardViewport.style.transform = 'rotateX(0deg) rotateY(0deg)';
        }
        if (dom.cardLaminateGlare) {
          dom.cardLaminateGlare.style.transform = 'translate3d(0, 0, 0)';
        }
      });
    }

    // Focus Mode Escape Dismissal
    window.addEventListener('keydown', (e) => {
      if (dom.idFocusStage && !dom.idFocusStage.classList.contains('hidden')) {
        if (e.key === 'Escape') {
          e.preventDefault();
          exitIdFocusMode();
        }
      }
    });

    // Random OC button in Focus Mode
    if (dom.btnFocusRandom) {
      dom.btnFocusRandom.addEventListener('click', () => {
        generateRandomOc();
        playTypewriterKey();
      });
    }

    // Download PNG from Focus Mode
    if (dom.btnFocusDownload) {
      dom.btnFocusDownload.addEventListener('click', downloadIdCardPng);
    }

    // Fallback Modal Controls
    if (dom.idModalCloseBtn) {
      dom.idModalCloseBtn.addEventListener('click', closeIdMakerModal);
    }

    // Toggle Pin on desk
    if (dom.btnToggleIdPinned) {
      dom.btnToggleIdPinned.addEventListener('click', () => {
        if (!state.idCard) return;
        state.idCard.pinned = !state.idCard.pinned;
        updateIdCardDisplays();
        saveIdCard(false);
        playPinSound();
      });
    }

    if (dom.btnDownloadId) {
      dom.btnDownloadId.addEventListener('click', downloadIdCardPng);
    }

    if (dom.btnRandomOc) {
      dom.btnRandomOc.addEventListener('click', generateRandomOc);
    }

    if (dom.ocIdForm) {
      dom.ocIdForm.addEventListener('submit', (e) => {
        e.preventDefault();
        saveIdCard(true);
      });
    }

    if (dom.btnTriggerPhotoUpload && dom.inputOcPhotoFile) {
      dom.btnTriggerPhotoUpload.addEventListener('click', () => {
        dom.inputOcPhotoFile.click();
      });
    }
    if (dom.previewPhotoBox && dom.inputOcPhotoFile) {
      dom.previewPhotoBox.addEventListener('click', () => {
        dom.inputOcPhotoFile.click();
      });
    }

    if (dom.inputOcPhotoFile) {
      dom.inputOcPhotoFile.addEventListener('change', async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('image', file);

        try {
          const res = await fetch('/api/id_card', {
            method: 'POST',
            body: formData
          });
          const data = await res.json();
          if (data.success && data.idCard) {
            state.idCard = data.idCard;
            updateIdCardDisplays();
            playPaperThud();
          }
        } catch (err) {
          console.error('Failed to upload photo:', err);
        }
      });
    }

    document.querySelectorAll('.avatar-preset-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.avatar-preset-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        if (state.idCard) {
          state.idCard.photo = btn.dataset.src;
          updateIdCardDisplays();
          saveIdCard(false);
          playPaperThud();
        }
      });
    });

    const fieldMap = [
      { input: dom.inputOcCreator, field: 'creator' },
      { input: dom.inputOcName, field: 'name' },
      { input: dom.inputOcBirthdate, field: 'birthdate' },
      { input: dom.inputOcAge, field: 'age' },
      { input: dom.inputOcNationality, field: 'nationality' },
      { input: dom.inputOcSpecies, field: 'species' },
      { input: dom.inputOcHeight, field: 'height' },
      { input: dom.inputOcWeight, field: 'weight' },
      { input: dom.inputOcSexuality, field: 'sexuality' },
      { input: dom.inputOcSignature, field: 'signature' }
    ];

    fieldMap.forEach(({ input, field }) => {
      if (!input) return;
      input.addEventListener('input', (e) => {
        if (!state.idCard) state.idCard = {};
        state.idCard[field] = e.target.value;
        if (field === 'name' && (!state.idCard.signature || state.idCard.signature === dom.inputOcSignature.defaultValue)) {
          state.idCard.signature = e.target.value;
          if (dom.inputOcSignature) dom.inputOcSignature.value = e.target.value;
        }
        updateIdCardDisplays();
      });
    });

    if (dom.ocIdForm) {
      dom.ocIdForm.querySelectorAll('input[name="oc-gender"]').forEach(radio => {
        radio.addEventListener('change', (e) => {
          if (!state.idCard) state.idCard = {};
          state.idCard.gender = e.target.value;
          updateIdCardDisplays();
        });
      });
    }
  }

  // ================= VINTAGE PUSHPIN BASKET & EVIDENCE PINNING SYSTEM =================

  function setupPinBasket() {
    const basket = dom.boardPinBasket || document.getElementById('board-pin-basket');
    if (!basket) return;

    basket.addEventListener('pointerdown', (e) => {
      // Only initiate on primary left click
      if (e.button !== 0) return;
      e.preventDefault();
      e.stopPropagation();

      // Audio feedback: clink of pulling a pin from the brass basket
      playPinBasketPickupSound();

      // Create floating pin element under cursor
      const floatingPin = document.createElement('div');
      floatingPin.className = 'floating-drag-pin';
      floatingPin.id = 'active-floating-drag-pin';
      floatingPin.innerHTML = `
        <div class="floating-pin-head"></div>
        <div class="floating-pin-needle"></div>
        <div class="floating-pin-reticle"></div>
      `;
      floatingPin.style.left = `${e.clientX}px`;
      floatingPin.style.top = `${e.clientY}px`;
      document.body.appendChild(floatingPin);

      let currentHoveredCard = null;

      function updateCandidateHover(clientX, clientY) {
        // Find topmost targetable evidence under cursor
        const elements = document.elementsFromPoint(clientX, clientY);
        let candidate = elements.find(el => {
          if (!el) return false;
          if (el.classList.contains('floating-drag-pin') || el.closest('#active-floating-drag-pin')) return false;
          if (el.closest('#board-pin-basket') || el.closest('#board-trash-bin') || el.closest('#board-header')) return false;
          return el.classList.contains('clue-card') ||
                 el.classList.contains('folder-paper-item') ||
                 el.classList.contains('board-roaming-paper') ||
                 el.classList.contains('board-pinned-id-card') ||
                 el.classList.contains('extra-clue-item');
        });

        if (candidate !== currentHoveredCard) {
          if (currentHoveredCard) {
            currentHoveredCard.classList.remove('pin-target-hover');
          }
          currentHoveredCard = candidate || null;
          if (currentHoveredCard) {
            currentHoveredCard.classList.add('pin-target-hover');
            if (window.PaperAudio) window.PaperAudio.tap(0.45, 'subtle');
          }
        }
        return currentHoveredCard;
      }

      const onPointerMove = (ev) => {
        floatingPin.style.left = `${ev.clientX}px`;
        floatingPin.style.top = `${ev.clientY}px`;
        updateCandidateHover(ev.clientX, ev.clientY);
      };

      // RIGHT-CLICK: Pushes the pin into evidence to make it stay put!
      const onContextMenuOrRightDown = (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        cleanUpDrag();

        const targetCard = updateCandidateHover(ev.clientX, ev.clientY);
        if (targetCard) {
          drivePinIntoTarget(ev.clientX, ev.clientY, targetCard);
        } else {
          // If right-clicked on empty board surface
          drivePinIntoTarget(ev.clientX, ev.clientY, null);
        }
      };

      const onPointerUp = (ev) => {
        if (ev.button === 0) {
          // Left click released
          cleanUpDrag();
          const targetCard = updateCandidateHover(ev.clientX, ev.clientY);
          if (targetCard) {
            // Place pin into target card
            drivePinIntoTarget(ev.clientX, ev.clientY, targetCard);
          } else {
            // Released on empty desk or cancelled
            if (window.PaperAudio) window.PaperAudio.tap(0.6, 'card');
          }
        }
      };

      function cleanUpDrag() {
        window.removeEventListener('pointermove', onPointerMove);
        window.removeEventListener('pointerup', onPointerUp);
        window.removeEventListener('contextmenu', onContextMenuOrRightDown, true);
        window.removeEventListener('pointerdown', checkRightClickDown, true);
        if (floatingPin && floatingPin.parentNode) {
          floatingPin.remove();
        }
        if (currentHoveredCard) {
          currentHoveredCard.classList.remove('pin-target-hover');
          currentHoveredCard = null;
        }
      }

      function checkRightClickDown(ev) {
        if (ev.button === 2) {
          onContextMenuOrRightDown(ev);
        }
      }

      window.addEventListener('pointermove', onPointerMove);
      window.addEventListener('pointerup', onPointerUp);
      window.addEventListener('contextmenu', onContextMenuOrRightDown, { capture: true });
      window.addEventListener('pointerdown', checkRightClickDown, { capture: true });
    });
  }

  function drivePinIntoTarget(clientX, clientY, targetCard) {
    if (targetCard) {
      const rect = targetCard.getBoundingClientRect();
      const relX = Math.round(clientX - rect.left);
      const relY = Math.round(clientY - rect.top);

      const pinId = 'pin-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
      const pinEl = document.createElement('div');
      pinEl.className = 'placed-evidence-pin pin-impact';
      pinEl.dataset.pinId = pinId;
      pinEl.style.left = `${relX}px`;
      pinEl.style.top = `${relY}px`;
      pinEl.title = 'Pushpin (Secures evidence in place · Right-click to remove)';

      pinEl.addEventListener('contextmenu', (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        removePlacedPin(pinEl, targetCard);
      });
      pinEl.addEventListener('pointerdown', (ev) => {
        if (ev.button === 2) {
          ev.preventDefault();
          ev.stopPropagation();
          removePlacedPin(pinEl, targetCard);
        }
      });

      targetCard.appendChild(pinEl);
      targetCard.dataset.stayPut = 'true';
      targetCard.classList.add('pinned-stay-put');

      // Paper impact jolt
      targetCard.classList.remove('paper-pinned-impact');
      void targetCard.offsetWidth; // Force reflow
      targetCard.classList.add('paper-pinned-impact');
      setTimeout(() => targetCard.classList.remove('paper-pinned-impact'), 300);

      playPinDriveInSound();
      showDisposalToast('EVIDENCE PINNED', 'Document secured to corkboard · Stays put');
      savePlacedPinsState();
    } else {
      // Over corkboard surface
      const sRect = getSurfaceRect();
      if (sRect && clientX >= sRect.left && clientX <= sRect.right && clientY >= sRect.top && clientY <= sRect.bottom) {
        const boardX = Math.round(clientX - sRect.left);
        const boardY = Math.round(clientY - sRect.top);

        const pinEl = document.createElement('div');
        pinEl.className = 'placed-evidence-pin pin-impact';
        pinEl.style.left = `${boardX}px`;
        pinEl.style.top = `${boardY}px`;
        pinEl.title = 'Corkboard Pushpin (Right-click to remove)';

        pinEl.addEventListener('contextmenu', (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          pinEl.remove();
          playPinExtractionSound();
          savePlacedPinsState();
        });
        pinEl.addEventListener('pointerdown', (ev) => {
          if (ev.button === 2) {
            ev.preventDefault();
            ev.stopPropagation();
            pinEl.remove();
            playPinExtractionSound();
            savePlacedPinsState();
          }
        });

        dom.surface.appendChild(pinEl);
        playPinDriveInSound();
        savePlacedPinsState();
      }
    }
  }

  function removePlacedPin(pinEl, targetCard) {
    if (!pinEl) return;
    playPinExtractionSound();
    pinEl.remove();

    if (targetCard) {
      const remainingPins = targetCard.querySelectorAll('.placed-evidence-pin');
      if (remainingPins.length === 0) {
        targetCard.dataset.stayPut = 'false';
        targetCard.classList.remove('pinned-stay-put');
        showDisposalToast('PIN REMOVED', 'Document unpinned · Free to move');
      }
    }
    savePlacedPinsState();
  }

  function playPinTugFeedback(card) {
    if (!card) return;
    playPinTugSound();
    card.classList.remove('pin-tug-shake');
    void card.offsetWidth; // Force reflow
    card.classList.add('pin-tug-shake');
    setTimeout(() => card.classList.remove('pin-tug-shake'), 320);
    showDisposalToast('EVIDENCE PINNED', 'Document secured with pin · Right-click pin to release');
  }

  function savePlacedPinsState() {
    try {
      const pinElements = document.querySelectorAll('.placed-evidence-pin');
      const pinsData = [];
      pinElements.forEach(p => {
        const parent = p.parentElement;
        if (!parent) return;
        let targetSelector = null;
        if (parent === dom.surface) {
          targetSelector = '#board-surface';
        } else if (parent.id) {
          targetSelector = `#${parent.id}`;
        } else if (parent.dataset.id) {
          targetSelector = `[data-id="${parent.dataset.id}"]`;
        } else if (parent.dataset.cardId) {
          targetSelector = `[data-card-id="${parent.dataset.cardId}"]`;
        }
        if (targetSelector) {
          pinsData.push({
            targetSelector,
            left: p.style.left,
            top: p.style.top
          });
        }
      });
      localStorage.setItem('tigers_eye_placed_pins', JSON.stringify(pinsData));
    } catch (_) {}
  }

  function restorePlacedPinsState() {
    try {
      const raw = localStorage.getItem('tigers_eye_placed_pins');
      if (!raw) return;
      const pinsData = JSON.parse(raw);
      if (!Array.isArray(pinsData)) return;

      pinsData.forEach(item => {
        const target = document.querySelector(item.targetSelector);
        if (!target) return;
        // Check if pin already exists
        const exists = Array.from(target.querySelectorAll('.placed-evidence-pin')).some(
          p => p.style.left === item.left && p.style.top === item.top
        );
        if (exists) return;

        const pinEl = document.createElement('div');
        pinEl.className = 'placed-evidence-pin';
        pinEl.style.left = item.left;
        pinEl.style.top = item.top;
        pinEl.title = 'Pushpin (Secures evidence in place · Right-click to remove)';

        pinEl.addEventListener('contextmenu', (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          removePlacedPin(pinEl, target);
        });
        pinEl.addEventListener('pointerdown', (ev) => {
          if (ev.button === 2) {
            ev.preventDefault();
            ev.stopPropagation();
            removePlacedPin(pinEl, target);
          }
        });

        target.appendChild(pinEl);
        if (target !== dom.surface) {
          target.dataset.stayPut = 'true';
          target.classList.add('pinned-stay-put');
        }
      });
    } catch (_) {}
  }

  // --- Event Listeners Setup ---
  function setupEventListeners() {
    // Vintage Desk Pushpin Basket & Pinning
    setupPinBasket();

    // String Tool Mode Toggle
    if (dom.btnStringTool) {
      dom.btnStringTool.addEventListener('click', () => {
        state.isStringToolActive = !state.isStringToolActive;
        dom.btnStringTool.classList.toggle('active', state.isStringToolActive);
        dom.surface.classList.toggle('string-mode', state.isStringToolActive);
        
        // Auto-open folder if minimized so evidence pins are accessible
        if (state.isStringToolActive && !state.isFolderOpen) {
          openFolder();
        }

        if (!state.isStringToolActive) {
          clearSelectedPin();
        }
      });
    }

    // Audio Toggle
    if (dom.btnAudioToggle) {
      dom.btnAudioToggle.addEventListener('click', toggleAtmosphericAudio);
    }

    // Tactile Paper SFX Toggle
    if (dom.btnSfxToggle) {
      dom.btnSfxToggle.addEventListener('click', () => {
        if (window.PaperAudio) {
          window.PaperAudio.toggleSfx();
        }
      });
    }

    // Make ID Studio Events
    setupIdMakerEvents();

    // Streamlined Evidence Creator Studio
    setupEvidenceCreator();

    // Deductions Modal
    if (dom.btnDeductions) {
      dom.btnDeductions.addEventListener('click', openDeductionsModal);
    }
    if (dom.deductionsModalCloseBtn) {
      dom.deductionsModalCloseBtn.addEventListener('click', closeDeductionsModal);
    }
    if (dom.btnCloseDeductions) {
      dom.btnCloseDeductions.addEventListener('click', closeDeductionsModal);
    }

    // Dossier Modal
    if (dom.modalCloseBtn) {
      dom.modalCloseBtn.addEventListener('click', closeDossierModal);
    }
    if (dom.dossierModal) {
      dom.dossierModal.addEventListener('click', (e) => {
        if (e.target === dom.dossierModal) {
          closeDossierModal();
        }
      });
    }

    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (dom.dossierModal && !dom.dossierModal.classList.contains('hidden')) {
          closeDossierModal();
        }
      }
    });

    if (dom.btnToggleUv) {
      dom.btnToggleUv.addEventListener('click', () => {
        state.isUvActive = !state.isUvActive;
        if (dom.modalMediaFrame) dom.modalMediaFrame.classList.toggle('uv-active', state.isUvActive);
        if (dom.modalUvOverlay) dom.modalUvOverlay.classList.toggle('hidden', !state.isUvActive);
        dom.btnToggleUv.classList.toggle('active', state.isUvActive);
        playPinSound();
      });
    }

    if (dom.btnPlayIntercept) {
      dom.btnPlayIntercept.addEventListener('click', playInterceptAudio);
    }
    if (dom.btnDeleteClue) {
      dom.btnDeleteClue.addEventListener('click', deleteCurrentClue);
    }

    // Full Original Dossier Scan Lightbox
    if (dom.btnViewFullScan && dom.scanModal) {
      dom.btnViewFullScan.addEventListener('click', () => {
        playPaperThud();
        dom.scanModal.classList.remove('hidden');
      });
      if (dom.scanModalCloseBtn) {
        dom.scanModalCloseBtn.addEventListener('click', () => {
          dom.scanModal.classList.add('hidden');
        });
      }
    }

    // Archival Disposal Receptacle Click Helper
    if (dom.boardTrashBin) {
      dom.boardTrashBin.addEventListener('click', () => {
        showDisposalToast('DISPOSAL CHUTE', 'Drag any evidence card or operative ID here to incinerate it');
        if (window.PaperAudio) window.PaperAudio.crumple('light');
      });
    }

    // Connect from Modal
    if (dom.btnModalConnect) {
      dom.btnModalConnect.addEventListener('click', () => {
        if (state.currentModalClueId) {
          const clue = state.caseData.clues.find(c => c.id === state.currentModalClueId);
          const card = dom.cluesContainer.querySelector(`[data-id="${clue.id}"]`);
          if (card) {
            const pin = card.querySelector('.clue-pin');
            closeDossierModal();
            handlePinClick(clue, pin);
          }
        }
      });
    }

    // Reset & Export
    dom.btnResetBoard.addEventListener('click', resetBoard);
    dom.btnExportDossier.addEventListener('click', exportDossier);

    // Era Select (if element present)
    if (dom.eraSelect) {
      dom.eraSelect.addEventListener('change', (e) => switchEra(e.target.value));
    }

    // Loupe Magnifier Toggle
    if (dom.btnToggleLoupe) {
      dom.btnToggleLoupe.addEventListener('click', () => {
        state.isLoupeActive = !state.isLoupeActive;
        dom.btnToggleLoupe.classList.toggle('active', state.isLoupeActive);
        if (!state.isLoupeActive && dom.modalLoupe) {
          dom.modalLoupe.classList.add('hidden');
        }
        playPinSound();
      });
    }

    // Loupe Mouse Movement on Evidence Image
    if (dom.modalMediaFrame) {
      dom.modalMediaFrame.addEventListener('mousemove', (e) => {
        if (!state.isLoupeActive || !dom.modalLoupe) return;
        const rect = dom.modalMediaFrame.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        if (x < 0 || x > rect.width || y < 0 || y > rect.height) {
          dom.modalLoupe.classList.add('hidden');
          return;
        }

        dom.modalLoupe.classList.remove('hidden');
        const r = 70; // 140px diameter
        dom.modalLoupe.style.left = `${x - r}px`;
        dom.modalLoupe.style.top = `${y - r}px`;

        const bgX = (x / rect.width) * 100;
        const bgY = (y / rect.height) * 100;
        dom.modalLoupe.style.backgroundImage = `url('${dom.modalImage.src}')`;
        dom.modalLoupe.style.backgroundPosition = `${bgX}% ${bgY}%`;
        dom.modalLoupe.style.backgroundSize = `${rect.width * 2.5}px ${rect.height * 2.5}px`;
      });

      dom.modalMediaFrame.addEventListener('mouseleave', () => {
        if (dom.modalLoupe) dom.modalLoupe.classList.add('hidden');
      });
    }

    // Report Modal
    if (dom.reportModalCloseBtn) {
      dom.reportModalCloseBtn.addEventListener('click', closeReportModal);
    }
    if (dom.btnReportPrint) {
      dom.btnReportPrint.addEventListener('click', () => {
        window.print();
      });
    }
    if (dom.btnReportDownloadJson) {
      dom.btnReportDownloadJson.addEventListener('click', async () => {
        const res = await fetch('/api/export');
        const data = await res.json();
        downloadReportJson(data);
      });
    }

    // Modal Dismissal on Escape
    window.addEventListener('keydown', (e) => {
      // Ignore if typing inside input or textarea
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) return;

      if (e.key === 'Escape') {
        const anyModalOpen = (dom.dossierModal && !dom.dossierModal.classList.contains('hidden')) ||
                             (dom.deductionsModal && !dom.deductionsModal.classList.contains('hidden')) ||
                             (dom.addModal && !dom.addModal.classList.contains('hidden')) ||
                             (dom.scanModal && !dom.scanModal.classList.contains('hidden')) ||
                             (dom.reportModal && !dom.reportModal.classList.contains('hidden')) ||
                             (dom.idMakerModal && !dom.idMakerModal.classList.contains('hidden')) ||
                             document.body.classList.contains('id-focus-active');
        exitIdFocusMode();
        closeDossierModal();
        closeDeductionsModal();
        closeReportModal();
        closeIdMakerModal();
        if (dom.addModal) dom.addModal.classList.add('hidden');
        if (dom.scanModal) dom.scanModal.classList.add('hidden');
        clearSelectedPin();

        // If no modal was open, and the folder is open, Escape minimizes/closes the folder
        if (!anyModalOpen && state.isFolderOpen) {
          closeFolder();
        }
      }
    });

    [dom.dossierModal, dom.deductionsModal, dom.addModal, dom.scanModal, dom.reportModal, dom.idMakerModal].forEach(modal => {
      if (!modal) return;
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.add('hidden');
          clearSelectedPin();
        }
      });
    });

    // Mouse movement on board surface for live rubber-band red line
    dom.surface.addEventListener('mousemove', (e) => {
      if (state.selectedPin) {
        const surfaceRect = getSurfaceRect();
        state.activeMousePos = {
          x: e.clientX - surfaceRect.left,
          y: e.clientY - surfaceRect.top
        };
        updateActiveDrawLine();
      }
    });

    // Right-click or board click to cancel string tying
    dom.surface.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      clearSelectedPin();
      updateActiveDrawLine();
    });

    // Window resize recalculates dynamic yarn strings across the board
    window.addEventListener('resize', () => {
      invalidatePinCache();
      requestRenderStrings();
    });
  }

  // Run on DOM load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
