/**
 * Tiger's Eye · Supernatural Bureau Investigation Board
 * Procedural Paper Audio Engine (Web Audio API)
 * 
 * Synthesizes ultra-tactile paper sound effects with zero external audio assets:
 * - Paper Tapping (crisp button clicks, card taps, stamp impacts, typewriter strikes)
 * - Paper Moving & Sliding (friction rustle tracking drag speed and travel distance)
 * - Paper Crumpling (stochastic micro-crackle cascade for delete, reset, folder unfold)
 * - Paper Settle & Drop (two-stage acoustic flutter when releasing cards onto corkboard)
 * - Paper Flip (aerodynamic air whoosh + snappy card turn)
 * - Manila Folder Flap (heavy dossier opening / closing)
 */

(function (window) {
  'use strict';

  let audioCtx = null;
  let sfxEnabled = true;
  let masterVolume = 0.85;

  // Drag motion tracking state
  let accumulatedDist = 0;
  let lastMoveSoundTime = 0;
  let lastHoverSoundTime = 0;
  let lastKeySoundTime = 0;

  // Restore user preference if saved
  try {
    const saved = localStorage.getItem('tigers_eye_paper_sfx');
    if (saved !== null) {
      sfxEnabled = saved === 'true';
    }
  } catch (_) {}

  /**
   * Safe AudioContext getter with gesture unlock
   */
  function getAudioContext() {
    if (!audioCtx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        audioCtx = new AudioCtx();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume().catch(() => {});
    }
    return audioCtx;
  }

  // Pre-warm audio context on any user gesture
  ['pointerdown', 'keydown', 'touchstart'].forEach(type => {
    window.addEventListener(type, () => {
      getAudioContext();
    }, { once: false, passive: true });
  });

  /**
   * Helper: Generate a short white/pink noise buffer
   */
  function createNoiseBuffer(ctx, durationSeconds, decayExp = 0) {
    const bufferSize = Math.max(1, Math.floor(ctx.sampleRate * durationSeconds));
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      let sample = Math.random() * 2 - 1;
      if (decayExp > 0) {
        sample *= Math.exp(-i / (ctx.sampleRate * decayExp));
      }
      data[i] = sample;
    }
    return buffer;
  }

  /**
   * 1. PAPER TAP: Crisp, tactile impact
   * Used for button clicks, card taps, pushpins, and general UI interactions.
   *
   * @param {number} intensity Scale factor (0.1 - 2.0)
   * @param {string} type 'button' | 'card' | 'heavy' | 'subtle' | 'type'
   */
  function playPaperTap(intensity = 1.0, type = 'button') {
    if (!sfxEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const pitchDetune = 1 + (Math.random() - 0.5) * 0.16; // Organic variety

      // --- Layer 1: High transient paper fiber snap (high-pass & bandpass noise) ---
      const noiseDur = type === 'subtle' ? 0.02 : (type === 'card' ? 0.038 : 0.032);
      const noiseBuf = createNoiseBuffer(ctx, noiseDur, noiseDur * 0.28);
      const noiseSrc = ctx.createBufferSource();
      noiseSrc.buffer = noiseBuf;

      const noiseFilter = ctx.createBiquadFilter();
      noiseFilter.type = 'bandpass';
      let centerFreq = 2400;
      if (type === 'subtle') centerFreq = 3200;
      else if (type === 'heavy') centerFreq = 1600;
      else if (type === 'card') centerFreq = 2100;
      else if (type === 'type') centerFreq = 2800;

      noiseFilter.frequency.setValueAtTime(centerFreq * pitchDetune, now);
      noiseFilter.Q.setValueAtTime(2.4, now);

      const noiseGain = ctx.createGain();
      let nVol = (type === 'subtle' ? 0.06 : (type === 'heavy' ? 0.18 : 0.14)) * intensity * masterVolume;
      noiseGain.gain.setValueAtTime(Math.max(0.0001, nVol), now);
      noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + noiseDur);

      noiseSrc.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(ctx.destination);
      noiseSrc.start(now);

      // --- Layer 2: Damped Body Resonance (gives the card or document thickness/mass) ---
      if (type !== 'subtle') {
        const bodyOsc = ctx.createOscillator();
        const bodyGain = ctx.createGain();
        bodyOsc.type = 'triangle';

        let bodyFreq = 340;
        if (type === 'heavy') bodyFreq = 220;
        else if (type === 'card') bodyFreq = 300;
        else if (type === 'type') bodyFreq = 420;

        bodyFreq *= pitchDetune;
        bodyOsc.frequency.setValueAtTime(bodyFreq, now);
        bodyOsc.frequency.exponentialRampToValueAtTime(bodyFreq * 0.45, now + 0.045);

        let bVol = (type === 'heavy' ? 0.15 : (type === 'card' ? 0.11 : 0.08)) * intensity * masterVolume;
        bodyGain.gain.setValueAtTime(Math.max(0.0001, bVol), now);
        bodyGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.05);

        bodyOsc.connect(bodyGain);
        bodyGain.connect(ctx.destination);
        bodyOsc.start(now);
        bodyOsc.stop(now + 0.055);
      }
    } catch (e) {
      console.warn('[PaperAudio] Tap error:', e);
    }
  }

  /**
   * 2. PAPER CRUMPLE: Realistic stochastic crackle cascade
   * Synthesizes 8 to 28 sharp micro-creasing impulses across a duration.
   * Used for deleting evidence, discarding ID badges, resetting board, unfolding folders.
   *
   * @param {string} intensity 'light' | 'medium' | 'heavy'
   */
  function playPaperCrumple(intensity = 'medium') {
    if (!sfxEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;

      let numGrains = 16;
      let duration = 0.28;
      let masterVol = 0.22;

      if (intensity === 'light' || intensity === 'crinkle') {
        numGrains = 9;
        duration = 0.18;
        masterVol = 0.13;
      } else if (intensity === 'heavy') {
        numGrains = 28;
        duration = 0.45;
        masterVol = 0.32;
      }

      // Air cavity flutter (the hollow whoosh of the crumpling parchment)
      const bodyOsc = ctx.createOscillator();
      const bodyGain = ctx.createGain();
      bodyOsc.type = 'sine';
      bodyOsc.frequency.setValueAtTime(280, now);
      bodyOsc.frequency.exponentialRampToValueAtTime(75, now + duration * 0.75);
      bodyGain.gain.setValueAtTime(Math.max(0.0001, masterVol * 0.28 * masterVolume), now);
      bodyGain.gain.exponentialRampToValueAtTime(0.0001, now + duration * 0.85);

      bodyOsc.connect(bodyGain);
      bodyGain.connect(ctx.destination);
      bodyOsc.start(now);
      bodyOsc.stop(now + duration * 0.9);

      // Crease popping cascade: random burst distribution
      for (let g = 0; g < numGrains; g++) {
        // Denser grouping toward mid-stroke
        const offset = Math.pow(Math.random(), 1.35) * (duration - 0.035);
        const grainTime = now + offset;
        const grainDur = 0.008 + Math.random() * 0.016; // 8ms - 24ms
        const grainFreq = 1600 + Math.random() * 4400;  // 1.6kHz - 6kHz sharp crackle
        const grainVol = masterVol * (0.35 + Math.random() * 0.65) * masterVolume;

        const grainBuf = createNoiseBuffer(ctx, grainDur, grainDur * 0.35);
        const grainSrc = ctx.createBufferSource();
        grainSrc.buffer = grainBuf;

        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(grainFreq, grainTime);
        filter.Q.setValueAtTime(4.2 + Math.random() * 3.5, grainTime);

        const grainGain = ctx.createGain();
        grainGain.gain.setValueAtTime(Math.max(0.0001, grainVol), grainTime);
        grainGain.gain.exponentialRampToValueAtTime(0.0001, grainTime + grainDur);

        grainSrc.connect(filter);
        filter.connect(grainGain);
        grainGain.connect(ctx.destination);

        grainSrc.start(grainTime);
      }
    } catch (e) {
      console.warn('[PaperAudio] Crumple error:', e);
    }
  }

  /**
   * 3. PAPER MOVE / SLIDING GRAIN: Soft, velvety friction rustle
   * Emitted subtly when dragging cards or folders across the corkboard.
   * Tuned to be gentle, warm, and non-fatiguing.
   *
   * @param {number} speed Relative dragging velocity (0.5 - 2.5)
   */
  function playPaperSlideGrain(speed = 1.0) {
    if (!sfxEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;

      // Soft, brief whisper duration (35ms - 60ms)
      const dur = 0.035 + Math.min(0.025, speed * 0.01);
      const buf = createNoiseBuffer(ctx, dur, dur * 0.4);
      const src = ctx.createBufferSource();
      src.buffer = buf;

      // Warm bandpass filter - mellow parchment texture instead of harsh sandpaper
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      const center = 750 + Math.min(450, speed * 220); // Warm 750Hz - 1200Hz
      bp.frequency.setValueAtTime(center, now);
      bp.Q.setValueAtTime(1.4, now); // Gentle Q for a soft, natural acoustic rustle

      // Gentle gain: soft velvety rustle, comfortable and non-overwhelming
      const gain = ctx.createGain();
      const vol = Math.min(0.038, 0.015 + speed * 0.009) * masterVolume;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(vol, now + 0.008);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

      src.connect(bp);
      bp.connect(gain);
      gain.connect(ctx.destination);

      src.start(now);
    } catch (e) {}
  }

  /**
   * Handles dragging motion: accumulates distance and triggers friction grains
   * Calibrated to trigger only on meaningful distance without overwhelming the user.
   */
  function handleDragMotion(dx, dy) {
    const dist = Math.hypot(dx, dy);
    accumulatedDist += dist;
    const now = performance.now();

    // Trigger only every ~75px of travel, throttled to minimum 160ms
    if (accumulatedDist >= 75 && now - lastMoveSoundTime > 160) {
      const speed = Math.min(2.0, Math.max(0.6, dist / 8));
      playPaperSlideGrain(speed);
      accumulatedDist = 0;
      lastMoveSoundTime = now;
    }
  }

  /**
   * PAPER UNCRUMPLE / SMOOTHING:
   * Staged acoustic simulation of unfolding and flattening creased paper:
   * - Stage 1: Soft paper spread tension & air expansion (0 - 100ms)
   * - Stage 2: Staggered sequence of 10-14 crisp micro-crease release pops (100 - 380ms)
   * - Stage 3: Smooth page settle & desk contact whisper (360 - 520ms)
   */
  function playPaperUncrumple() {
    if (!sfxEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const volScale = masterVolume * 0.85;

      // 1. Initial unfolding tension / gentle air cavity swoosh
      const swooshDur = 0.28;
      const swooshBuf = createNoiseBuffer(ctx, swooshDur, swooshDur * 0.4);
      const swooshSrc = ctx.createBufferSource();
      swooshSrc.buffer = swooshBuf;

      const swooshBp = ctx.createBiquadFilter();
      swooshBp.type = 'bandpass';
      swooshBp.frequency.setValueAtTime(450, now);
      swooshBp.frequency.exponentialRampToValueAtTime(1150, now + 0.14);
      swooshBp.frequency.exponentialRampToValueAtTime(340, now + swooshDur);
      swooshBp.Q.setValueAtTime(1.8, now);

      const swooshGain = ctx.createGain();
      swooshGain.gain.setValueAtTime(0.0001, now);
      swooshGain.gain.linearRampToValueAtTime(0.065 * volScale, now + 0.06);
      swooshGain.gain.exponentialRampToValueAtTime(0.0001, now + swooshDur);

      swooshSrc.connect(swooshBp);
      swooshBp.connect(swooshGain);
      swooshGain.connect(ctx.destination);
      swooshSrc.start(now);

      // 2. Cascade of uncrumpling crease releases (micro-creases popping open)
      const numCreases = 12;
      for (let i = 0; i < numCreases; i++) {
        // Staggered timing mimicking physical fold relaxations
        const offset = 0.035 + Math.pow((i / numCreases), 1.15) * 0.30 + (Math.random() - 0.5) * 0.03;
        const popTime = now + Math.max(0.02, offset);
        const popDur = 0.012 + Math.random() * 0.018; // 12ms - 30ms
        const popFreq = 1400 + Math.random() * 3200; // 1.4kHz - 4.6kHz crisp fiber snaps

        const popBuf = createNoiseBuffer(ctx, popDur, popDur * 0.32);
        const popSrc = ctx.createBufferSource();
        popSrc.buffer = popBuf;

        const popFilter = ctx.createBiquadFilter();
        popFilter.type = 'bandpass';
        popFilter.frequency.setValueAtTime(popFreq, popTime);
        popFilter.Q.setValueAtTime(3.6 + Math.random() * 2.2, popTime);

        const popGain = ctx.createGain();
        const pVol = (0.045 + Math.random() * 0.06) * volScale;
        popGain.gain.setValueAtTime(0.0001, popTime);
        popGain.gain.linearRampToValueAtTime(pVol, popTime + 0.002);
        popGain.gain.exponentialRampToValueAtTime(0.0001, popTime + popDur);

        popSrc.connect(popFilter);
        popFilter.connect(popGain);
        popGain.connect(ctx.destination);
        popSrc.start(popTime);
      }

      // 3. Trailing page settle & smoothing flutter (paper resting flat)
      setTimeout(() => {
        if (!sfxEnabled) return;
        try {
          const sCtx = getAudioContext();
          if (!sCtx) return;
          const sNow = sCtx.currentTime;
          const setDur = 0.16;
          const setBuf = createNoiseBuffer(sCtx, setDur, setDur * 0.4);
          const setSrc = sCtx.createBufferSource();
          setSrc.buffer = setBuf;

          const setLp = sCtx.createBiquadFilter();
          setLp.type = 'lowpass';
          setLp.frequency.setValueAtTime(900, sNow);

          const setGain = sCtx.createGain();
          setGain.gain.setValueAtTime(0.032 * volScale, sNow);
          setGain.gain.exponentialRampToValueAtTime(0.0001, sNow + setDur);

          setSrc.connect(setLp);
          setLp.connect(setGain);
          setGain.connect(sCtx.destination);
          setSrc.start(sNow);
        } catch (_) {}
      }, 320);

    } catch (e) {
      console.warn('[PaperAudio] Uncrumple error:', e);
    }
  }

  /**
   * 4. PAPER DROP / SETTLE: Dual-stage impact & edge flutter
   * Used when dropping a clue, ID card, or folder after dragging.
   */
  function playPaperDrop(opts = {}) {
    if (!sfxEnabled) return;
    try {
      const isHeavy = opts.type === 'folder';
      // Stage 1: Card / folder contact slap
      playPaperTap(isHeavy ? 1.25 : 1.0, isHeavy ? 'heavy' : 'card');

      // Stage 2: Trailing paper edge flutter (35ms - 50ms later)
      setTimeout(() => {
        if (!sfxEnabled) return;
        playPaperSlideGrain(0.75);
      }, 42);
    } catch (e) {}
  }

  /**
   * 5. PAPER FLIP / TURN: Aerodynamic whoosh + card snap
   * Used for 3D ID card flip and switching tabs.
   */
  function playPaperFlip() {
    if (!sfxEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;

      // 1. Aerodynamic whoosh
      const dur = 0.16;
      const buf = createNoiseBuffer(ctx, dur);
      const src = ctx.createBufferSource();
      src.buffer = buf;

      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(380, now);
      bp.frequency.exponentialRampToValueAtTime(1700, now + 0.08);
      bp.frequency.exponentialRampToValueAtTime(260, now + dur);
      bp.Q.setValueAtTime(2.0, now);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.linearRampToValueAtTime(0.18 * masterVolume, now + 0.06);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

      src.connect(bp);
      bp.connect(gain);
      gain.connect(ctx.destination);
      src.start(now);

      // 2. Crisp card snap at apex
      setTimeout(() => {
        playPaperTap(0.9, 'card');
      }, 65);
    } catch (e) {}
  }

  /**
   * 6. MANILA FOLDER FLAP: Heavy folder unfold & flap slap
   * Used for opening and closing the Manila Case File Folder.
   *
   * @param {string} direction 'open' | 'close'
   */
  function playFolderFlap(direction = 'open') {
    if (!sfxEnabled) return;
    if (direction === 'open') {
      // Unfold: realistic paper uncrumple sequence + heavy folder thud
      playPaperUncrumple();
      playPaperTap(0.65, 'heavy');
    } else {
      // Close: thick cardboard thud + crisp flap snap
      playPaperTap(1.2, 'heavy');
      setTimeout(() => {
        playPaperSlideGrain(1.1);
      }, 35);
    }
  }

  /**
   * 7. PAPER RUSTLE / MICRO-TICK: Subtle ambient interaction
   * Used for gentle hover effects or subtle adjustments.
   */
  function playPaperRustle(intensity = 1.0) {
    if (!sfxEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;

      const dur = 0.035;
      const buf = createNoiseBuffer(ctx, dur, dur * 0.3);
      const src = ctx.createBufferSource();
      src.buffer = buf;

      const hp = ctx.createBiquadFilter();
      hp.type = 'highpass';
      hp.frequency.setValueAtTime(2200, now);

      const gain = ctx.createGain();
      const vol = 0.045 * intensity * masterVolume;
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);

      src.connect(hp);
      hp.connect(gain);
      gain.connect(ctx.destination);
      src.start(now);
    } catch (e) {}
  }

  /**
   * Toggle SFX on / off
   */
  function toggleSfx() {
    sfxEnabled = !sfxEnabled;
    try {
      localStorage.setItem('tigers_eye_paper_sfx', sfxEnabled);
    } catch (_) {}
    if (sfxEnabled) {
      playPaperTap(1.0, 'button');
    }
    updateSfxUi();
    return sfxEnabled;
  }

  function setSfxEnabled(val) {
    sfxEnabled = !!val;
    try {
      localStorage.setItem('tigers_eye_paper_sfx', sfxEnabled);
    } catch (_) {}
    updateSfxUi();
  }

  function isSfxEnabled() {
    return sfxEnabled;
  }

  function updateSfxUi() {
    const sfxBtn = document.getElementById('btn-sfx-toggle');
    if (sfxBtn) {
      sfxBtn.classList.toggle('active', sfxEnabled);
      const icon = sfxBtn.querySelector('i') || sfxBtn.querySelector('svg');
      if (icon) {
        if (sfxEnabled) {
          icon.setAttribute('data-lucide', 'scroll');
          sfxBtn.title = 'Paper SFX: ACTIVE (Click to Mute)';
        } else {
          icon.setAttribute('data-lucide', 'scroll');
          sfxBtn.title = 'Paper SFX: MUTED (Click to Enable)';
        }
      }
      if (window.lucide && typeof window.lucide.createIcons === 'function') {
        window.lucide.createIcons();
      }
    }
  }

  /**
   * Global Universal Event Delegation:
   * Attaches to buttons, tabs, tools, inputs across the investigation board
   */
  function attachGlobalListeners() {
    // 1. Delegated Button Click Handler (Universal coverage)
    document.addEventListener('click', (e) => {
      // Find closest interactive button or trigger
      const btn = e.target.closest(
        'button, .hud-btn, .hud-btn-icon, .desk-tool-btn, .folder-action-btn, ' +
        '.tab-btn, .modal-tab, .id-tab-btn, .preset-pill, .filter-btn, ' +
        '.folder-tab-badge, .btn-audio-play, [role="button"]'
      );
      if (!btn) return;

      const id = btn.id || '';
      const cls = btn.className || '';

      // Check if button has a specialized sound
      if (id === 'btn-delete-clue' || id === 'btn-focus-delete-id' || id === 'btn-reset-board' || cls.includes('btn-danger') || cls.includes('btn-delete')) {
        playPaperCrumple('heavy');
      } else if (id === 'btn-flip-card-top' || id === 'btn-focus-flip' || cls.includes('btn-flip')) {
        playPaperFlip();
      } else if (id === 'btn-focus-random' || id === 'btn-random-oc' || cls.includes('btn-random')) {
        playPaperCrumple('light');
      } else if (id === 'btn-sfx-toggle') {
        // Toggled by its own handler
      } else if (id === 'btn-hud-folder-toggle' || id === 'btn-toggle-folder' || id === 'btn-minimize-folder') {
        // Handled in folder toggle
      } else if (id === 'btn-play-intercept') {
        playPaperTap(1.0, 'heavy');
      } else if (cls.includes('modal-tab') || cls.includes('id-tab-btn') || cls.includes('tab-btn')) {
        playPaperTap(0.85, 'card');
      } else {
        playPaperTap(0.9, 'button');
      }
    }, true);

    // 2. Tactile typing sound on form inputs and textareas
    document.addEventListener('keydown', (e) => {
      const target = e.target;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        // Ignore modifier keys alone
        if (['Shift', 'Control', 'Alt', 'Meta', 'CapsLock'].includes(e.key)) return;
        const now = performance.now();
        if (now - lastKeySoundTime > 45) {
          lastKeySoundTime = now;
          if (e.key === 'Backspace' || e.key === 'Delete') {
            playPaperTap(0.65, 'card');
          } else if (e.key === 'Enter') {
            playPaperTap(0.8, 'heavy');
          } else {
            playPaperTap(0.45, 'type');
          }
        }
      }
    });

    // 3. Subtle paper rustle on hover (delicate tactile presence)
    document.addEventListener('mouseover', (e) => {
      const item = e.target.closest('.clue-card, .folder-paper-item, .folder-closed-cover, .desk-tool-btn, .hud-btn');
      if (!item) return;
      const now = performance.now();
      if (now - lastHoverSoundTime > 120) {
        lastHoverSoundTime = now;
        playPaperRustle(0.25);
      }
    });
  }

  // Initialize once DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      attachGlobalListeners();
      updateSfxUi();
    });
  } else {
    attachGlobalListeners();
    updateSfxUi();
  }

  // Public API exposed on window.PaperAudio
  window.PaperAudio = {
    tap: playPaperTap,
    crumple: playPaperCrumple,
    uncrumple: playPaperUncrumple,
    move: playPaperSlideGrain,
    handleDragMotion: handleDragMotion,
    drop: playPaperDrop,
    flip: playPaperFlip,
    folderFlap: playFolderFlap,
    rustle: playPaperRustle,
    thud: function() { playPaperTap(1.1, 'heavy'); },
    toggleSfx: toggleSfx,
    setSfxEnabled: setSfxEnabled,
    isSfxEnabled: isSfxEnabled,
    updateSfxUi: updateSfxUi,
    getAudioContext: getAudioContext
  };

})(window);
