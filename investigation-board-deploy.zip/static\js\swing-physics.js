/**
 * Tiger's Eye · Supernatural Bureau Investigation Board
 * Dynamic Swing Physics Engine
 * 
 * Provides tactile inertial pendulum physics when picking up and dragging:
 * - Pinned clue files & documents
 * - Certified OC identification cards
 * - Loose folder paperwork
 * - Manila case file dossiers
 */

(function (window) {
  'use strict';

  /**
   * Clamps a value between min and max
   */
  function clamp(val, min, max) {
    return Math.max(min, Math.min(max, val));
  }

  /**
   * Swing Physics Instance Factory
   */
  function createSwingPhysics(options) {
    const el = options.element;
    if (!el) throw new Error('[SwingPhysics] element is required');

    let baseRotation = Number.isFinite(options.baseRotation) ? options.baseRotation : 0;
    const pivotX = options.pivotX !== undefined ? options.pivotX : '50%';
    const pivotY = options.pivotY !== undefined ? options.pivotY : '18px';
    const maxAngle = Number.isFinite(options.maxAngle) ? options.maxAngle : 18;
    const sensitivity = Number.isFinite(options.sensitivity) ? options.sensitivity : 0.012;
    const liftScale = Number.isFinite(options.liftScale) ? options.liftScale : 1.05;
    const onSettle = typeof options.onSettle === 'function' ? options.onSettle : null;
    let getTransformPrefix = typeof options.getTransformPrefix === 'function' ? options.getTransformPrefix : null;

    let isDragging = false;
    let isSettling = false;
    let rafId = null;

    // Physics State
    let currentRotation = baseRotation;
    let targetRotation = baseRotation;
    let angularVelocity = 0;

    let currentTiltX = 0;
    let targetTiltX = 0;

    let currentScale = 1.0;
    let targetScale = 1.0;

    let lastX = 0;
    let lastY = 0;
    let lastTime = 0;

    let smoothedVx = 0;
    let smoothedVy = 0;

    /**
     * Set the transform-origin based on top pin/clip
     */
    function applyPivot() {
      el.style.transformOrigin = `${pivotX} ${pivotY}`;
    }

    /**
     * Stop active RAF loop
     */
    function stopLoop() {
      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
    }

    /**
     * Main Animation Frame Step
     */
    function step() {
      const prefix = getTransformPrefix ? (getTransformPrefix() + ' ') : '';

      if (isDragging) {
        // Dragging phase: chase targetRotation & targetTilt with spring responsiveness
        const rotDiff = targetRotation - currentRotation;
        angularVelocity = (angularVelocity + rotDiff * 0.24) * 0.75;
        currentRotation += angularVelocity;

        currentTiltX += (targetTiltX - currentTiltX) * 0.22;
        currentScale += (targetScale - currentScale) * 0.25;

        el.style.transform = `${prefix}perspective(850px) rotate(${currentRotation.toFixed(2)}deg) rotateX(${currentTiltX.toFixed(2)}deg) scale(${currentScale.toFixed(3)})`;

        // Decay velocity if pointer has stopped moving
        const now = performance.now();
        if (now - lastTime > 65) {
          smoothedVx *= 0.82;
          smoothedVy *= 0.82;
          targetRotation = baseRotation + clamp(smoothedVx * sensitivity, -maxAngle, maxAngle);
          targetTiltX = clamp(-smoothedVy * 0.008, -10, 10);
        }

        rafId = requestAnimationFrame(step);
      } else if (isSettling) {
        // Drop / Release phase: free damped harmonic oscillator settling back to baseRotation
        const springForce = (baseRotation - currentRotation) * 0.22;
        angularVelocity = (angularVelocity + springForce) * 0.78;
        currentRotation += angularVelocity;

        currentTiltX += (0 - currentTiltX) * 0.22;
        currentScale += (1.0 - currentScale) * 0.26;

        el.style.transform = `${prefix}perspective(850px) rotate(${currentRotation.toFixed(2)}deg) rotateX(${currentTiltX.toFixed(2)}deg) scale(${currentScale.toFixed(3)})`;

        const rotDelta = Math.abs(currentRotation - baseRotation);
        const velDelta = Math.abs(angularVelocity);
        const scaleDelta = Math.abs(currentScale - 1.0);
        const tiltDelta = Math.abs(currentTiltX);

        if (rotDelta > 0.04 || velDelta > 0.04 || scaleDelta > 0.004 || tiltDelta > 0.04) {
          rafId = requestAnimationFrame(step);
        } else {
          // Settled! Clean up exactly to resting angle
          isSettling = false;
          currentRotation = baseRotation;
          currentTiltX = 0;
          currentScale = 1.0;
          angularVelocity = 0;
          el.style.transform = `${prefix}rotate(${baseRotation}deg)`;
          el.classList.remove('is-picked-up');
          el.classList.remove('dragging');
          if (onSettle) onSettle();
        }
      }
    }

    /**
     * 1. Pickup: User presses down to pick up the file or ID card
     */
    function pickup(clientX, clientY) {
      stopLoop();
      isDragging = true;
      isSettling = false;

      applyPivot();
      el.classList.add('is-picked-up');
      el.classList.add('dragging');

      lastX = clientX;
      lastY = clientY;
      lastTime = performance.now();
      smoothedVx = 0;
      smoothedVy = 0;

      // Calculate tactile grab torque impulse:
      // If user grabs to the left or right of center, an initial torque occurs
      const rect = el.getBoundingClientRect();
      const relX = clientX - rect.left;
      const cardW = rect.width || 220;
      const offCenter = (relX - cardW / 2) / (cardW / 2); // -1.0 to +1.0
      const initialTorque = clamp(offCenter * 3.8, -4, 4);

      angularVelocity = initialTorque;
      targetScale = liftScale;
      targetTiltX = -2.5; // Slight initial lift tilt
      targetRotation = baseRotation + initialTorque;

      rafId = requestAnimationFrame(step);
    }

    /**
     * 2. Move: User drags the file or ID card across the board
     */
    function move(clientX, clientY) {
      if (!isDragging) return;

      const now = performance.now();
      const dt = Math.min(0.05, Math.max(0.008, (now - lastTime) / 1000));

      const rawVx = (clientX - lastX) / dt;
      const rawVy = (clientY - lastY) / dt;

      lastX = clientX;
      lastY = clientY;
      lastTime = now;

      // Exponential smoothing for buttery motion without jitter
      smoothedVx += (rawVx - smoothedVx) * 0.38;
      smoothedVy += (rawVy - smoothedVy) * 0.38;

      // Physical swing calculation:
      // Moving right (+smoothedVx) -> bottom lags left (clockwise rotation +)
      // Moving left (-smoothedVx) -> bottom lags right (counter-clockwise rotation -)
      const swingAngle = clamp(smoothedVx * sensitivity, -maxAngle, maxAngle);
      targetRotation = baseRotation + swingAngle;

      // Aerodynamic pitch tilt (faster vertical movement tilts the card in 3D)
      targetTiltX = clamp(-smoothedVy * 0.008, -11, 11);
    }

    /**
     * 3. Drop: User releases pointer, card settles with spring oscillation
     */
    function drop() {
      if (!isDragging && !isSettling) return;

      isDragging = false;
      isSettling = true;
      targetScale = 1.0;
      targetTiltX = 0;
      targetRotation = baseRotation;

      // If loop is not active, start it for settle
      if (!rafId) {
        rafId = requestAnimationFrame(step);
      }
    }

    /**
     * 4. Cancel: abort immediately
     */
    function cancel() {
      isDragging = false;
      isSettling = false;
      stopLoop();
      currentRotation = baseRotation;
      currentTiltX = 0;
      currentScale = 1.0;
      angularVelocity = 0;
      const prefix = getTransformPrefix ? (getTransformPrefix() + ' ') : '';
      el.style.transform = `${prefix}rotate(${baseRotation}deg)`;
      el.classList.remove('is-picked-up');
      el.classList.remove('dragging');
    }

    /**
     * Update resting rotation
     */
    function setBaseRotation(newRot) {
      baseRotation = Number.isFinite(newRot) ? newRot : 0;
      if (!isDragging && !isSettling) {
        currentRotation = baseRotation;
        const prefix = getTransformPrefix ? (getTransformPrefix() + ' ') : '';
        el.style.transform = `${prefix}rotate(${baseRotation}deg)`;
      }
    }

    function setTransformPrefix(fn) {
      getTransformPrefix = fn;
    }

    return {
      pickup: pickup,
      move: move,
      drop: drop,
      cancel: cancel,
      setBaseRotation: setBaseRotation,
      setTransformPrefix: setTransformPrefix,
      isDragging: function () { return isDragging; },
      isSettling: function () { return isSettling; }
    };
  }

  // Public API exposed on window.SwingPhysics
  window.SwingPhysics = {
    create: createSwingPhysics
  };

})(window);
